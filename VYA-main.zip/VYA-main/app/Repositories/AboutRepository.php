<?php

namespace App\Repositories;

use App\Helper\StoreFile;
use App\Http\Resources\AboutResource;
use App\Interfaces\AboutRepositoryInterface;
use App\Models\AboutUs;

class AboutRepository implements AboutRepositoryInterface
{

    public function show($request)
    {
        $about = AboutUs::first();
        return new AboutResource($about);
    }

    public function update($request)
    {

        $about = AboutUs::first();

        if (isset($request->image)) {
            StoreFile::delete($about->image);
            $fileName = StoreFile::store($request->image, 'abouts');
            $about->update([
                'image' => $fileName,
            ]);
        }
        $about->update([
            'en_caption' => $request->en_caption,
            'ar_caption' => $request->ar_caption,
            'en_content' => $request->en_content,
            'ar_content' => $request->ar_content,
        ]);

        return new AboutResource($about);
    }
}
