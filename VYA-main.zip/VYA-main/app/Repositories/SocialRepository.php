<?php

namespace App\Repositories;

use App\Helper\StoreFile;
use App\Http\Resources\SocialResource;
use App\Interfaces\SocialRepositoryInterface;
use App\Models\Social;

class SocialRepository implements SocialRepositoryInterface
{

    public function show()
    {
        return new SocialResource(Social::first());
    }

    /**
     * @param $request
     * @return SocialResource
     */
    public function update($request)
    {
        $social = Social::first();
        if (isset($request->color_logo)) {
            $fileName = StoreFile::store($request->color_logo, 'logo');
            $social->update([
                'color_logo' => $fileName
            ]);
        }

        if (isset($request->white_logo)) {
            $fileName = StoreFile::store($request->white_logo, 'logo');
            $social->update([
                'white_logo' => $fileName
            ]);
        }

        if ($request->mobile){
            $social->update([
                'mobile' => $request->mobile
            ]);
        }
        if ($request->map){
            $social->update([
                'map' => $request->map
            ]);
        }
        if ($request->linkedin){
            $social->update([
                'linkedin' => $request->linkedin
            ]);
        }
        if ($request->facebook){
            $social->update([
                'facebook' => $request->facebook
            ]);
        }
        if ($request->twitter){
            $social->update([
                'twitter' => $request->twitter
            ]);
        }
        if ($request->youtube){
            $social->update([
                'youtube' => $request->youtube
            ]);
        }
        if ($request->vat_amount){
            $social->update([
                'vat_amount' => $request->vat_amount
            ]);
        }
        if ($request->deal_days){
            $social->update([
                'deal_days' => $request->deal_days
            ]);
        }
        if ($request->shipment_amount){
            $social->update([
                'shipment_amount' => $request->shipment_amount
            ]);
        }
        return new SocialResource($social);
    }
}
