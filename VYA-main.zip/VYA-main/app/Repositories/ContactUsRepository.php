<?php

namespace App\Repositories;

use App\Http\Resources\ContactUsResource;
use App\Interfaces\ContactUsRepositoryInterface;
use App\Mail\ContactUsMail;
use App\Models\Contact;
use Illuminate\Support\Facades\Mail;

class ContactUsRepository implements ContactUsRepositoryInterface{

    /**
     * @return mixed
     */
    public function index()
    {
        $data = Contact::paginate(15);
        return ContactUsResource::collection($data);
    }

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        Contact::create($request->all());
        Mail::to(env('MAIL_CONTACT_ADDRESS'))->send(new ContactUsMail($request));

        return response()->json([
            'status' => 201,
            'message' => 'Message Sent successfully'
        ], 201);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function delete($contact)
    {
        $contact->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Contact us form deleted',
        ], 200);
    }
}
