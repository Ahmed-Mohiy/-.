<?php
namespace App\Repositories;

use App\Http\Resources\StaticResource;
use App\Interfaces\StaticRepositoryInterface;
use App\Models\Term;

class StaticRepository implements StaticRepositoryInterface{

    /**
     * @param $type
     * @return mixed
     */
    public function index($type)
    {
        return new StaticResource(Term::where('type', $type)->firstOrFail());
    }

    /**
     * @param $request
     * @param $type
     * @return mixed
     */
    public function update($request, $type)
    {
        $term = Term::updateOrCreate(['type' => $type], ['en_content'=>$request->en_content, 'ar_content'=>$request->ar_content]);
        return  $term;
        return response()->json(['msg' => 'Content updated successfully'], 201);
    }
}
