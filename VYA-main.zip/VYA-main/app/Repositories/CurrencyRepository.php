<?php

namespace App\Repositories;

use App\Http\Resources\CurrencyResource;
use App\Interfaces\CurrencyRepositoryInterface;
use App\Models\Currency;
use Illuminate\Support\Facades\Validator;

class CurrencyRepository implements CurrencyRepositoryInterface
{

    /**
     * @param $product
     * @param $request
     * @return mixed
     */
    public function index($currency, $request)
    {
        $perPage = $request->get('per_page', 15);
        return CurrencyResource::collection($currency->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'en_name'              => 'required|max:255|string|unique:currencies,en_name',
            'ar_name'              => 'required|max:255|string|unique:currencies,ar_name',
            'symbolic'             => 'required|max:255|string|unique:currencies,symbolic',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $currency = Currency::create($request->all());

        return new CurrencyResource($currency);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function show($id)
    {
        return new CurrencyResource(Currency::findOrFail($id));
    }

    /**
     * @param $request
     * @param $id
     * @return mixed
     */
    public function update($request, $id)
    {
        $currency = Currency::find($id);

        if (!$currency){
            return response()->json([
                'status' => 404,
                'error' => 'Currency dos not exist',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'en_name'              => 'required|max:255|string|unique:currencies,en_name'.($id ? ",$id" : ''),
            'ar_name'              => 'required|max:255|string|unique:currencies,ar_name'.($id ? ",$id" : ''),
            'symbolic'             => 'required|max:255|string|unique:currencies,symbolic'.($id ? ",$id" : ''),
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $currency->update($request->all());

        return new CurrencyResource($currency);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id)
    {
        // TODO: Implement destroy() method.
    }
}
