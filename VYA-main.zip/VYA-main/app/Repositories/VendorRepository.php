<?php

namespace App\Repositories;

use App\Interfaces\VendorRepositoryInterface;
use App\Models\AccountType;
use App\Models\Company;
use Illuminate\Support\Facades\Storage;

class VendorRepository implements VendorRepositoryInterface
{

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index($request)
    {
        $data = [];
        $perPage = $request->get('per_page', 17);

        $vendors = Company::where('status', true)->where('account_type_id', AccountType::TYPE['SELLER'])->paginate($perPage)->appends([
            'per_page' => $perPage
        ])->shuffle();

        foreach ($vendors as $vendor){
            $data[] = [
                'name' => $vendor->name,
                'logo' => asset(Storage::url($vendor->logo)),
            ];
        }

        return response()->json([
            'status' => 200,
            'data' => $data,
        ], 200);
    }
}
