<?php

namespace App\Repositories;

use App\Helper\StoreFile;
use App\Http\Resources\ProductIndexResource;
use App\Http\Resources\ProductResource;
use App\Interfaces\ProductRepositoryInterface;
use App\Models\Category;
use App\Models\CompanyProduct;
use App\Models\Product;
use App\Models\ProductImages;
use App\Models\Specification;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Validator;

class ProductRepository implements ProductRepositoryInterface
{

    /**
     * @param $product
     * @param $request
     * @return mixed
     */
    public function index($product, $request)
    {
        $perPage = $request->get('per_page', 15);
        $product = $product->with(['category','deals']);
//        if (isset($request->category_ids)){
//            $product = $product->whereHas('category', function ($query) use ($request){
//                $query->whereIn('id', $request->category_ids)->orWhereIn('parent_id', $request->category_ids);
//            });
//        }


        if (isset($request->category_id)) {
            if (is_array($request->category_id)) {
                $product = $product->whereHas('category', function ($query) use ($request) {
                    $query->whereIn('id', $request->category_id)->orWhereIn('parent_id', $request->category_id);
                });
            } else {
                $product = $product->where('category_id', $request->category_id);
            }
        }

        if (isset($request->search)) {
            $search = $request->search;
            $product = $product->whereLike(['sku', 'en_name', 'ar_name'], $search);
        }


        if (!$request->all) {
            if (Auth()->guard('api')->check()) {
                if (Auth()->guard('api')->user()->hasRole(['Seller', 'Seller-Finance', 'Seller-Logistics'])) {
                    if (Auth()->guard('api')->user()->company->has('products')) {
                        $product = $product->whereIn('id', Auth()->guard('api')->user()->company->products->pluck('id'));
                    }
                }
            }
        } else {
            if (isset($request->category_id)) {
                $category = Category::where('id', $request->category_id)->first();
                $categories = self::flattenChilds($category);
                $categories = $categories->pluck('id')->toArray();
                array_push($categories, $category->id);
            }
        }


        $product = $product->where('status', true)->paginate($perPage)->appends([
            'per_page' => $perPage
        ]);

        return ProductIndexResource::collection($product);
    }

    public static function flattenChilds($parent)
    {
        $result = collect([]);
        foreach ($parent->recursiveChilds as $child) {
            $result->push($child);
            $result = $result->merge(static::flattenChilds($child));
        }

        return $result->filter();
    }

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'en_name' => 'required|max:255|string',
            'ar_name' => 'required|max:255|string',
            'sku' => 'required|max:255|string|unique:products,sku',
            'category_id' => 'required|max:255|string|exists:categories,id',
            'en_description' => 'nullable',
            'ar_description' => 'nullable',
            'shipment_type' => 'required|numeric',
            'type' => 'required|string',
            'sku_identifier' => 'required|string',
            'additional_information' => 'nullable|string',
            'specifications' => 'nullable|array',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        if (auth()->user()->hasRole('Admin')) {
            $request->request->add(['status' => 1]);
        } else {
            $request->request->add(['status' => 0]);
        }

        $product = Product::create([
            'sku' => $request->sku,
            'ar_name' => $request->ar_name,
            'en_name' => $request->ar_name,
            'ar_description' => $request->ar_description,
            'en_description' => $request->ar_description,
            'category_id' => $request->category_id,
            'shipment_type' => $request->shipment_type,
            'status' => $request->status,
            'sku_identifier' => $request->sku_identifier,
            'additional_information' => $request->additional_information,
            'type' => $request->type,
            'created_by' => auth()->id(),
        ]);

        if (!auth()->user()->hasRole('Admin')) {
            CompanyProduct::firstOrcreate([
                'company_id' => auth()->user()->company_id,
                'product_id' => $product->id
            ]);
        }

        foreach ($request->specifications as $value) {
            Specification::create([
                'product_id' => $product->id,
                'key' => $value['key'],
                'value' => $value['value']
            ]);
        }

        return new ProductResource($product);

    }

    /**
     * @param $id
     * @return mixed
     */
    public function show($id)
    {
        $product = Product::with(['category','deals','specifications','files','rate'])->where('id', $id)->where('status', true)->first();
        if (!$product) {
            return response()->json([
                'status' => 404,
                'error' => 'Product dos not exist',
            ], 404);
        }
        return new ProductResource($product);
    }

    /**
     * @param $request
     * @return mixed
     */
    public function update($request, $id)
    {
        $validator = Validator::make($request->all(), [
            'en_name' => 'required|max:255|string',
            'ar_name' => 'required|max:255|string',
            'sku' => 'required|max:255|string|unique:products,sku' . ($id ? ",$id" : ''),
            'category_id' => 'required|max:255|string|exists:categories,id',
            'en_description' => 'nullable',
            'ar_description' => 'nullable',
            'status' => 'required',
            'shipment_type' => 'required|numeric',
            'specifications' => 'nullable|array',
            'type' => 'required|string',
            'sku_identifier' => 'required|string',
            'additional_information' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $product = Product::find($id);

        $product->update([
            'sku' => $request->sku,
            'ar_name' => $request->ar_name,
            'en_name' => $request->ar_name,
            'ar_description' => $request->ar_description,
            'en_description' => $request->ar_description,
            'category_id' => $request->category_id,
            'shipment_type' => $request->shipment_type,
            'status' => $request->status,
            'sku_identifier' => $request->sku_identifier,
            'additional_information' => $request->additional_information,
            'type' => $request->type,
            'created_by' => auth()->id(),
        ]);

        foreach ($request->specifications as $value) {
            if ($value['id']){
                Specification::find($value['id'])->update([
                    'key' => $value['key'],
                    'product_id' => $product->id,
                    'value' => $value['value'],
                ]);
            } else {
                Specification::create([
                    'key' => $value['key'],
                    'product_id' => $product->id,
                    'value' => $value['value'],
                ]);
            }
        }

        return new ProductResource($product);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id)
    {
        $product = Product::find($id);
        if (!$product) {
            return response()->json([
                'status' => 404,
                'message' => 'Product does not exist',
            ], 404);
        }
        $product->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Product deleted',
        ], 200);
    }

    public function storeAttach($request)
    {
        $validator = Validator::make($request->all(), [
            'image' => 'required|max:10240',
            'thumbnail' => 'nullable|image',
            'product_id' => 'required|string|exists:products,id',
            'is_main' => 'required',
            'sort' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $fileName = StoreFile::store($request->image, 'products');

        $thumbnailName = null;
        if ($request->thumbnail) {
            $thumbnailName = StoreFile::store($request->thumbnail, 'products');

        }
        ProductImages::create([
            'product_id' => $request->product_id,
            'file' => $fileName,
            'thumbnail' => $thumbnailName,
            'is_main' => $request->is_main,
            'sort' => $request->sort
        ]);

        return response()->json([
            'status' => 201,
            'message' => 'Attaches file Store Successfully',
        ], 201);
    }

    public function updateAttach($request)
    {
        $validator = Validator::make($request->all(), [
            'image' => 'nullable|max:10240',
            'thumbnail' => 'nullable|image',
            'image_id' => 'required|string|exists:product_images,id',
            'is_main' => 'required',
            'sort' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $productImage = ProductImages::find($request->image_id);

        if ($request->image) {
            $fileName = StoreFile::store($request->image, 'products');
            $productImage->update([
                'image' => $fileName,
            ]);
        }


        if ($request->thumbnail) {
            $thumbnailName = StoreFile::store($request->thumbnail, 'products');
            $productImage->update([
                'thumbnail' => $thumbnailName,
            ]);
        }

        $productImage->update([
            'is_main' => $request->is_main,
            'sort' => $request->sort
        ]);

        return response()->json([
            'status' => 201,
            'message' => 'Attaches file Store Successfully',
        ], 201);
    }

    public function destroyAttach($id)
    {
        $image = ProductImages::find($id);

        if (!$image) {
            return response()->json([
                'status' => 404,
                'message' => 'Image dos not exist',
            ], 404);
        }

        $image->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Attaches file Deleted Successfully',
        ], 200);
    }

    public function status($request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|string|exists:products,id',
            'status' => 'required|boolean'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        Product::find($request->product_id)->update([
            'status' => $request->status
        ]);

        $message = $request->status == 0 ? 'Product Deactivated successfully' : 'Product Activated successfully';
        return response()->json([
            'status' => 200,
            'message' => $message,
        ], 200);
    }
}
