<?php

namespace App\Repositories;

use App\Events\PrivateMessageEvent;
use App\Helper\ContentType;
use App\Helper\StoreFile;
use App\Interfaces\ChatRepositoryInterface;
use App\Models\Message;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use LRedis;

class ChatRepository implements ChatRepositoryInterface
{
    /**
     * @param $userID
     * @return mixed
     */
    public function conversation($userID)
    {
        //
    }

    /**
     * @param $request
     * @return mixed
     */
    public function sendMessage($request)
    {

    }


    /**
     * @param $request
     * @return mixed
     */
    public function updateOnline($request)
    {

    }

    /**
     * @param $request
     * @return mixed
     */
    public function updateOffline($request)
    {

    }

    /**
     * @param $request
     * @return mixed
     */
    public function seen($request)
    {

    }

    /**
     * @param $userID
     * @param $myID
     * @return mixed
     */
    public function updateSeen($userID, $myID)
    {

    }
}
