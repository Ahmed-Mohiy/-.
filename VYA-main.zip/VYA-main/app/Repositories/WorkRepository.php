<?php
namespace App\Repositories;

use App\Helper\StoreFile;
use App\Http\Resources\WorkResource;
use App\Interfaces\WorkRepositoryInterface;
use App\Models\Work;

class WorkRepository implements WorkRepositoryInterface {

    /**
     * @param $type
     * @param $request
     * @param $works
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index($type, $request, $works)
    {
        $perPage = $request->get('per_page', 15);
        return WorkResource::collection($works->where('type', $type)->orderBY('sort', 'asc')->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store($request): \Illuminate\Http\JsonResponse
    {
        $fileName = StoreFile::store($request->image, 'works');
        $slide = Work::create([
            'image'=> $fileName,
            'ar_title'=>$request->ar_title,
            'en_title'=>$request->en_title,
            'ar_caption'=>$request->ar_caption,
            'en_caption'=>$request->en_caption,
            'sort'=>$request->sort,
            'type'=>$request->type,
        ]);
        return response()->json(['msg' => $slide->en_title. ' ' . __('messages.Created Successfully')], 201);
    }

    public function update($request, $id)
    {
        $slider = Work::find($id);
        $inputs = $request->all();
        if ($request->hasFile('image')) {

            if (isset($slider->image)) {
                StoreFile::delete($slider->image);
            }
            $fileName = StoreFile::store($request->image, 'works');
            $inputs['image'] = $fileName;
        }

        $slider->fill($inputs);
        $slider->save();

        return response()->json(['msg' => $slider->en_title. ' ' . __('messages.Updated Successfully')], 201);
    }

    public function show($id)
    {
        return new WorkResource(Work::findOrFail($id));
    }

    public function destroy($id)
    {
        $slider = Work::findOrFail($id);
        if (isset($slider->image)) {
            StoreFile::delete($slider->image);
        }
        $slider->delete();

        return response()->json(['msg' => $slider->en_title. ' ' . __('messages.Deleted Successfully')], 200);
    }
}
