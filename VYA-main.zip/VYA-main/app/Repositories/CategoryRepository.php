<?php

namespace App\Repositories;

use App\Helper\StoreFile;
use App\Http\Resources\CategoryResource;
use App\Interfaces\CategoryRepositoryInterface;
use App\Models\Category;
use App\Models\UserCategoryMostUsed;
use Illuminate\Support\Facades\Validator;

class CategoryRepository implements CategoryRepositoryInterface
{

    public function index($categories, $request)
    {
        $categories = $categories->with('categories');
        $perPage = $request->get('per_page', 20);
        if ($request->quantity != 'all') {
            if (Auth()->guard('api')->check()) {
                if (Auth()->guard('api')->user()->hasRole(['Buyer', 'Buyer-logistics', 'Buyer-Finance'])) {
                    if (Auth()->guard('api')->user()->company->has('categories')) {
                        $categories = $categories->whereIn('id', Auth()->guard('api')->user()->company->categories->pluck('id'));
                    }
                }
                $categories = $categories->withCount(['userCategoryMostUsed as mostUsed' => function($query){
                    return $query->where('user_category_most_useds.user_id', Auth()->guard('api')->user()->id);
                }])->orderBy('mostUsed', 'desc');
            }
        }

        return CategoryResource::collection($categories->where('status', true)->whereNull('parent_id')->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'en_name' => 'required|max:255|string|unique:categories,en_name',
            'ar_name' => 'required|max:255|string|unique:categories,ar_name',
            'parent_id' => 'sometimes|nullable|exists:categories,id',
            'image' => 'required|max:10240|image',
            'deposit_amount' => 'sometimes|required',
            'deposit_type' => 'sometimes|required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $fileName = null;
        if ($request->image) {
            $fileName = StoreFile::store($request->image, 'categories');
        }

        $category = Category::create([
            "en_name" => $request->en_name,
            "ar_name" => $request->ar_name,
            "parent_id" => $request->parent_id,
            "image" => $fileName,
            "deposit_amount" => $request->deposit_amount,
            "deposit_type" => $request->deposit_type,
        ]);

        return new CategoryResource($category);
    }

    public function show($id)
    {
        $category = Category::with('categories')->find($id);
        if (!$category) {
            return response()->json([
                'status' => 404,
                'message' => 'Category dos not exist',
            ], 404);
        }
        if (Auth()->guard('api')->check()) {
            UserCategoryMostUsed::create([
                'category_id' => $category->id,
                'user_id' => Auth()->guard('api')->user()->id
            ]);
        }
        return new CategoryResource($category);
    }

    public function update($request, $id)
    {
        $category = Category::find($id);

        if (!$category) {
            return response()->json([
                'status' => 404,
                'message' => 'Category dos not exist',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'en_name' => 'required|string|unique:categories,en_name' . ($id ? ",$id" : ''),
            'ar_name' => 'required|string|unique:categories,ar_name' . ($id ? ",$id" : ''),
            'deposit_amount' => 'sometimes|required',
            'deposit_type' => 'sometimes|required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        if (isset($request->image)) {
            StoreFile::delete($category->image);
            $fileName = StoreFile::store($request->image, 'categories');
            $category->update([
                'en_name' => $request->en_name,
                'ar_name' => $request->ar_name,
                'parent_id' => $request->parent_id,
                'image' => $fileName,
                'deposit_amount' => $request->deposit_amount,
                'deposit_type' => $request->deposit_type,
            ]);
        } else {
            $category->update($request->all());
        }

        return new CategoryResource($category);
    }

    public function destroy($id)
    {
        $category = Category::find($id);
        if (!$category) {
            return response()->json([
                'status' => 404,
                'message' => 'Category dos not exist',
            ], 404);
        }
        $category->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Category deleted',
        ], 200);
    }
}
