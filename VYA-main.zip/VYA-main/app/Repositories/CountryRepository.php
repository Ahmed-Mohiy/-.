<?php

namespace App\Repositories;

use App\Http\Resources\CountryResource;
use App\Interfaces\CountryRepositoryInterface;
use App\Models\Country;
use Illuminate\Support\Facades\Validator;

class CountryRepository implements CountryRepositoryInterface
{

    public function index($countries, $request)
    {
        $perPage = $request->get('per_page', 15);
        if ($request->country_id){
            $countries = $countries->where('country_id', $request->country_id)->whereNotNull('country_id');
        } else {
            $countries = $countries->whereNull('country_id')->with('children');
        }
        return CountryResource::collection($countries->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'en_name'   => 'required|max:255|string|unique:countries,en_name',
            'ar_name'   => 'required|max:255|string|unique:countries,ar_name',
            'country_id' => 'sometimes|nullable|exists:countries,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $country = Country::create($request->all());

        return new CountryResource(Country::findOrFail($country->id));
    }

    public function show($id)
    {
        $country = Country::with('children')->where('id', $id)->first();
        return CountryResource::make($country);
    }

    public function update($request, $id)
    {
        $country = Country::find($id);

        if (!$country) {
            return response()->json([
                'status' => 404,
                'error' => 'Country doesn\'t exist',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'en_name' => 'required|string|unique:countries,en_name' . ($id ? ",$id" : ''),
            'ar_name' => 'required|string|unique:countries,ar_name' . ($id ? ",$id" : ''),
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $country->update($request->all());

        return new CountryResource($country);
    }

    public function destroy()
    {
        // TODO: Implement destroy() method.
    }
}
