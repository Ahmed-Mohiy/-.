<?php

namespace App\Repositories;

use App\Http\Resources\InviteResource;
use App\Interfaces\InviteRepositoryInterface;
use App\Mail\SendInvitesMail;
use App\Models\Invite;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class InviteRepository implements InviteRepositoryInterface
{
    /**
     * @param $invite
     * @param $request
     * @return mixed
     */
    public function index($invite, $request)
    {
        $perPage = $request->get('per_page', 15);
        return InviteResource::collection($invite->where('status', true)->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'email'          => 'required|email'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        if (!auth()->user()->company()->exists()){
            return response()->json([
                'status' => 404,
                'message' => 'Something warning!',
            ], 404);
        }

        $privet_key = Str::random(40);
        Invite::create([
            'company_id' => auth()->user()->company->id,
            'email' => $request->email,
            'privet_key' => $privet_key,
            'status' => false,
            'expiry_at' => Carbon::today()->addDays(7),
        ]);

        $name = auth()->user()->name;
        $email = $request->email;
        $company_name = auth()->user()->company->name;
        $url = '/'. $privet_key;

        Mail::to($email)->send(new SendInvitesMail($name, $company_name, $url));

        return response()->json([
            'status' => 201,
            'message' => 'Invitation sent successfully'
        ], 201);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function show($id)
    {
        // TODO: Implement show() method.
    }

    /**
     * @param $request
     * @param $id
     * @return mixed
     */
    public function update($request, $id)
    {
        // TODO: Implement update() method.
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id)
    {
        $invite = Invite::find($id);
        if (!$invite) {
            return response()->json([
                'status' => 404,
                'message' => 'Invite dos not exist',
            ], 404);
        }
        $invite->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Invite deleted',
        ], 200);
    }
}
