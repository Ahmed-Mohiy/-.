<?php

namespace App\Repositories;

use App\Http\Resources\UserResource;
use App\Interfaces\AuthRepositoryInterface;
use Tymon\JWTAuth\Token;
use JWTAuth;

class AuthRepository implements AuthRepositoryInterface {
    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function login($request)
    {
        $credentials = $request->only('email', 'password');

        if ($token = $this->guard()->attempt($credentials)) {
            return $this->respondWithToken($token);
        }

        return response()->json(['error' => 'Unauthorized'], 401);
    }

    /**
     * @return \Illuminate\Contracts\Auth\Guard|\Illuminate\Contracts\Auth\StatefulGuard
     */
    public function guard()
    {
        return auth()->guard('api');
    }

    /**
     * @return void
     */
    public function logout()
    {
        $this->guard()->logout();
        return response()->json(['message' => 'Successfully logged out']);
    }

    /**
     * @return UserResource
     */
    public function me()
    {
        return new UserResource($this->guard()->user());
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken($this->guard()->refresh());
    }

    /**
     * @param $token
     * @return \Illuminate\Http\JsonResponse
     */
    public function respondWithToken($token)
    {
        $data = JWTAuth::decode(new Token($token))->toArray();
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => $this->guard()->factory()->getTTL() * 60,
            'expires_at' => $data['exp'],
            'me' => $this->me()
        ]);
    }

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function token($request)
    {
        auth()->user()->update([
            'device_token' => $request->device_token
        ]);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://iid.googleapis.com/iid/v1:batchAdd',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{
               "to": "'.$request->topic.'",
               "registration_tokens": ["'.$request->device_token.'"]
            }',
            CURLOPT_HTTPHEADER => array(
                'Authorization: key='.config('notification.FCM_SERVER_KEY'),
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return response()->json([
            'message' => 'Device Token Updated Successfully',
            'response' => $response
        ], 200);
    }

}
