<?php
namespace App\Repositories;

use App\Http\Resources\FAQResource;
use App\Interfaces\FAQRepositoryInterface;
use App\Models\FAQ;
use Illuminate\Support\Facades\Validator;

class FAQRepository implements FAQRepositoryInterface{

    /**
     * @return mixed
     */
    public function index()
    {

        return FAQResource::collection(FAQ::paginate(15)->appends([
            'per_page' => 15
        ])
        );
    }

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'en_question'   => 'required|unique:f_a_q_s,en_question',
            'ar_question'   => 'required|string|unique:f_a_q_s,ar_question',
            'en_answer'     => 'required',
            'ar_answer'     => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $faq = FAQ::create($request->all());

        return new FAQResource(FAQ::findOrFail($faq->id));
    }

    /**
     * @param $id
     * @return mixed
     */
    public function show($id)
    {
        $faq = FAQ::findOrFail($id);
        return FAQResource::make($faq);
    }

    /**
     * @param $request
     * @param $id
     * @return mixed
     */
    public function update($request, $id)
    {
        $faq = FAQ::find($id);

        if (!$faq) {
            return response()->json([
                'status' => 404,
                'message' => 'FAQ does not exist',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'en_question' => 'required|unique:f_a_q_s,en_question' . ($id ? ",$id" : ''),
            'ar_question' => 'required|unique:f_a_q_s,ar_question' . ($id ? ",$id" : ''),
            'en_answer'     => 'required',
            'ar_answer'     => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $faq->update($request->all());

        return new FAQResource($faq);
    }

    /**
     * @return mixed
     */
    public function destroy($id)
    {
        $faq = FAQ::find($id);

        if (!$faq) {
            return response()->json([
                'status' => 404,
                'message' => 'FAQ does not exist',
            ], 404);
        }

        $faq->delete();

        return response()->json([
            'status' => 200,
            'message' => 'FAQ Deleted',
        ], 200);
    }
}
