<?php

namespace App\Repositories;

use App\Http\Resources\TypeOfContactResource;
use App\Interfaces\TypeOfContactInterface;
use App\Models\TypeOfContact;
use Illuminate\Support\Facades\Validator;

class TypeOfContactRepositories implements TypeOfContactInterface
{

    /**
     * @param $request
     * @return mixed
     */
    public function index($request)
    {
        $types = TypeOfContact::where('status', true)->get();
        return TypeOfContactResource::collection($types);
    }

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'en_name'   => 'required|max:255|string|unique:type_of_contacts,en_name',
            'ar_name'   => 'required|max:255|string|unique:type_of_contacts,ar_name',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $category = TypeOfContact::create($request->all());

        return new TypeOfContactResource($category);
    }

    /**
     * @param $request
     * @param $id
     * @return mixed
     */
    public function update($request, $id)
    {
        $type = TypeOfContact::find($id);

        if (!$type) {
            return response()->json([
                'status' => 404,
                'message' => 'Type dos not exist',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'en_name' => 'required|string|unique:type_of_contacts,en_name' . ($id ? ",$id" : ''),
            'ar_name' => 'required|string|unique:type_of_contacts,ar_name' . ($id ? ",$id" : ''),
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $type->update($request->all());

        return new TypeOfContactResource($type);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function destroy($id)
    {
        $type = TypeOfContact::find($id);
        if (!$type) {
            return response()->json([
                'status' => 404,
                'message' => 'This Type dos not exist',
            ], 404);
        }
        $type->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Type id deleted',
        ], 200);
    }
}
