<?php

namespace App\Repositories;

use App\Http\Resources\WishlistResource;
use App\Models\Wishlist;
use Illuminate\Support\Facades\Validator;

class WishlistRepository implements \App\Interfaces\WishlistRepositoryInterface
{

    public function index($request)
    {
        $perPage = $request->get('per_page', 15);

        return WishlistResource::collection(auth()->user()->wishlists()->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    public function store($request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $wishlist = Wishlist::where('product_id', $request->product_id)->where('user_id', auth()->id())->first();

        if ($wishlist){
            $wishlist->delete();
            return response()->json([
                'status' => 200,
                'message' => __('messages.Product Removed Successfully')
            ]);
        } else {
            Wishlist::create([
                'user_id' => auth()->id(),
                'product_id' => $request->product_id
            ]);
            return response()->json([
                'status' => 200,
                'message' => __('messages.Product Added Successfully')
            ]);
        }

    }

    public function show($id)
    {
        //
    }

    public function update($request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
