<?php
namespace App\Repositories;

use App\Helper\StoreFile;
use App\Http\Resources\SliderResource;
use App\Interfaces\SliderRepositoryInterface;
use App\Models\Slider;

class SliderRepository implements SliderRepositoryInterface {

    /**
     * @param $sliders
     * @param $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index($sliders, $request)
    {
        $perPage = $request->get('per_page', 15);
        return SliderResource::collection($sliders->orderBY('sort', 'asc')->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store($request): \Illuminate\Http\JsonResponse
    {
        $fileName = StoreFile::store($request->image, 'slider');
        $slide = Slider::create([
            'image'=> $fileName,
            'ar_title'=>$request->ar_title,
            'en_title'=>$request->en_title,
            'ar_caption'=>$request->ar_caption,
            'en_caption'=>$request->en_caption,
            'sort'=>$request->sort,
        ]);
        return response()->json(['message' => 'Slide created successfully'], 201);
    }

    public function update($request, $id)
    {
        $slider = Slider::find($id);
        $inputs = $request->all();
        if ($request->hasFile('image')) {

            if (isset($slider->image)) {
                StoreFile::delete($slider->image);
            }
            $fileName = StoreFile::store($request->image, 'slider');
            $inputs['image'] = $fileName;
        }

        $slider->fill($inputs);
        $slider->save();

        return response()->json(['message' => 'Slide updated successfully'], 201);
    }

    public function show($slider)
    {
        return new SliderResource(Slider::findOrFail($slider));
    }

    public function destroy($id)
    {
        $slider = Slider::findOrFail($id);
        if (isset($slider->image)) {
            StoreFile::delete($slider->image);
        }
        $slider->delete();

        return response()->json(['message' => 'Slide deleted successfully'], 200);
    }
}
