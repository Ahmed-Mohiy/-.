<?php
namespace App\Repositories;

use App\Http\Resources\RateResource;
use App\Interfaces\RateRepositoryInterface;
use Illuminate\Support\Facades\Validator;

class RateRepository implements RateRepositoryInterface{

    /**
     * @param $request
     * @return mixed
     */
    public function store($request)
    {
        $validator = Validator::make($request->all(),
            [
                'type' => 'required',
                'product_id' => 'required|exists:products,id',
                'order_id' => 'required_if:type,==,0|exists:orders,id',
                'product' => 'required_if:type,==,1',
                'packaging' => 'required_if:type,==,0',
                'delivery' => 'required_if:type,==,0',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $user = auth()->user();
        if($request->type == 1){
            $user->rate()->where('product_id', $request->product_id)->updateOrCreate(['product_id' => $request->product_id],$request->all());
        }else{
            $user->rate()->where('order_id', $request->order_id)->updateOrCreate(['order_id' => $request->order_id],$request->all());
        }

        return response()->json([
            'message' => 'Rate added successfully'],
            201
        );


    }

    /**
     * @param $request
     * @return mixed
     */
    public function destroy($request)
    {
        // TODO: Implement destroy() method.
    }

    /**
     * @param $product
     * @return mixed
     */
    public function productIndex($product)
    {
        $product_total = ($product->rate->count() === 0) ? 0 : round($product->rate->sum('product') / $product->rate->count(), 2);
        return ['product_total'=> $product_total, 'data'=> RateResource::collection($product->rate()->get())];
    }


    public function OrderIndex($order)
    {
        $packaging_total = round($order->rate->sum('packaging') / $order->rate->count(), 2);
        $delivery_total = round($order->rate->sum('delivery') / $order->rate->count(), 2);
        return [
            'packaging_total'=> $packaging_total,
            'delivery_total' => $delivery_total,
            'data'=> RateResource::collection($order->rate()->get())
        ];
    }
}
