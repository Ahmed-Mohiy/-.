<?php

namespace App\Repositories;

use App\Helper\SendNotificationHelper;
use App\Helper\StoreFile;
use App\Http\Resources\UserResource;
use App\Interfaces\UserRepositoryInterface;
use App\Models\AccountType;
use App\Models\Address;
use App\Models\Company;
use App\Models\CompanyCategory;
use App\Models\CompanyProduct;
use App\Models\LegalPaper;
use App\Models\User;
use App\Models\UserCategoryMostUsed;
use App\Notifications\AccountCreated;
use App\Notifications\WelcomeEmail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Tymon\JWTAuth\Token;

class UserRepository implements UserRepositoryInterface
{

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function addPermission($request): \Illuminate\Http\JsonResponse
    {
        Permission::create(['name' => $request->name]);
        return response()->json(['msg' => __('messages.Permission added successfully')], 201);
    }

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function addRoles($request): \Illuminate\Http\JsonResponse
    {
        Role::create(['name' => $request->name]);
        return response()->json(['msg' => __('messages.Role added successfully')], 201);
    }

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function givePermissions($request): \Illuminate\Http\JsonResponse
    {
        $role = Role::findById($request->role_id);
        $role->givePermissionTo($request->permission_id);
        return response()->json(['msg' => __('messages.Permission assigned successfully')], 201);
    }

    /**
     * @param $request
     * assign role to specific user
     */
    public function assignRole($request): \Illuminate\Http\JsonResponse
    {
        $role = Role::findById($request->role_id);
        $user = User::whereId($request->user_id)->first();
        $user->assignRole($role);
        return response()->json(['msg' => __('messages.Role added successfully')], 201);
    }

    /**
     * @param $request
     * sync permissions to role
     * @return \Illuminate\Http\JsonResponse
     */
    public function syncRole($request): \Illuminate\Http\JsonResponse
    {
        $role = Role::findById($request->role_id);
        $role->permissions()->sync($request->permission_id);
        return response()->json(['msg' => __('messages.Permission synced successfully')], 201);
    }

    public function addUser($request)
    {
        $type = $request->type;
        switch ($type) {
            case 'admin':
                return $this->addAdmin($request);
                break;
            case 'seller':
                return $this->store($request, AccountType::TYPE['SELLER']);
                break;
            case 'buyer':
                return $this->store($request, AccountType::TYPE['BUYER']);
                break;
            default:
                return response()->json([
                    'message' => __('messages.Invalid request type'),
                ], 400);
        }


    }

    public function updateUser($request, $id)
    {
        $user = User::find($id);

        if (!$user) {
            return response()->json([
                'status' => 404,
                'message' => __('messages.User does not exist'),
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'email' => 'required|string|unique:users,email' . ($id ? ",$id" : ''),
            'name' => 'required|string',
            'mobile' => 'required|string',
            'role_id' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $user = $user->update([
            'email' => $request->email,
            'name' => $request->name,
            'mobile' => $request->mobile,
        ]);

        return new UserResource($user);
    }

    public function index($type)
    {
        $users = User::query();
        $users = $users->with(['company','company.orders','company.submissions']);
        switch ($type) {
            case 'vendor':
                $users = $users->role('Seller');
                break;
            case 'buyer':
                $users = $users->role('Buyer');
                break;
            case 'admin':
                $users = $users->role('Admin');
                break;
            default:
                return response()->json([
                    'status' => 404,
                    'error' => __('messages.Undefined type please select Admins, vendors or buyers'),
                ], 404);
        }
        return UserResource::collection($users->paginate(15)->appends([
            'per_page' => 15
        ]));

    }

    private function addAdmin($request)
    {

        $validator = Validator::make($request->all(),
            [
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users,email',
                'password' => [
                    'required',
                    'string',
                    'confirmed',
                    'min:8',             // must be at least 10 characters in length
                    'regex:/[a-z]/',      // must contain at least one lowercase letter
                    'regex:/[A-Z]/',      // must contain at least one uppercase letter
                    'regex:/[0-9]/',      // must contain at least one digit
                ],
                'role_id' => 'required|in:8,9,10,11,12',
            ], [
                'password.regex' => __('messages.Password must contain at least one lowercase letter, one uppercase letter and at least one digit'),
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $hash_password = Hash::make($request->password);
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $hash_password,
        ]);

        //Get Role
        $role = Role::findById($request->role_id);
        //assign role to user
        $user->assignRole($role);

        $user->notify(new AccountCreated($request->email, $hash_password));

        return response()->json([
            'status' => 201,
            'message' => $request->name . ' ' . __('messages.Account created successfully')
        ], 201);
    }

    /**
     * @param $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    private function store($request, $userType)
    {
        $inputs = $request->all();
        $addresses = array();
        foreach ($inputs['addresses'] as $address) {
            $address = json_decode($address, true);
            array_push($addresses, $address);
        }
        $inputs['addresses'] = $addresses;

        $validator = Validator::make($inputs,
            [
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users',
                'logo' => 'required|file',
                'password' => [
                    'required',
                    'string',
                    'confirmed',
                    'min:8',             // must be at least 10 characters in length
                    'regex:/[a-z]/',      // must contain at least one lowercase letter
                    'regex:/[A-Z]/',      // must contain at least one uppercase letter
                    'regex:/[0-9]/',      // must contain at least one digit
                ],
                'identification_type_id' => 'required|exists:identification_types,id',
                'identification_type_number' => 'required|unique:companies,identification_type_number',
                'company_name' => 'required|string|max:255',
                'tax_number' => 'required|numeric|min:3',
                'mobile' => 'required|numeric|min:3',
                'companyType' => 'required|min:1|string',
                'companyIdType' => 'required|min:1|string',
                'contractNumber' => 'required|min:1|string',
                'companyIdNumber' => 'required|min:1|string',
                'legal_papers' => 'present|array',
                'legal_papers.*' => 'required|file',
                'addresses' => 'present|array',
                'addresses.*.address_name' => 'required|max:255',
                'addresses.*.country_id' => 'required|exists:countries,id',
                'addresses.*.mobile' => 'required|numeric|min:9',
                'addresses.*.building_number' => 'required|min:1',
                'addresses.*.postcode' => 'required|string',
                'addresses.*.street_name' => 'required|string',
                'addresses.*.lat' => 'required|numeric',
                'addresses.*.lon' => 'required|numeric',
                'addresses.*.unit_number' => 'required|numeric',
                'addresses.*.nearest_landmark' => 'nullable|string',
                'addresses.*.is_default' => 'nullable',
                'categories' => 'present|array',
                'products' => 'sometimes|array',
                'website' => 'sometimes|nullable',
                'categories.*' => 'required|exists:categories,id',
                'products.*' => 'nullable|exists:products,id',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        DB::transaction(function ($message) use ($userType,$inputs,$request) {
            $logo = StoreFile::store($request->logo, 'logos');
            $company = Company::create([
                'name' => $request->company_name,
                'tax_number' => $request->tax_number,
                'logo' => $logo,
                'owner_name' => $request->name,
                'website' => $request->website,
                'account_type_id' => $userType,
                'identification_type_id' => $request->identification_type_id,
                'identification_type_number' => $request->identification_type_number,
                'mobile' => $request->mobile,
                'email' => $request->email,
                'companyType' => $request->companyType,
                'companyIdType' => $request->companyIdType,
                'companyIdNumber' => $request->companyIdNumber,
                'contractNumber' => $request->contractNumber
            ]);

            $user = $company->users()->create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);

            //Get Role
            $role = Role::findByName($userType == 2 ? 'Buyer' : 'Seller');

            //assign role to user
            $user->assignRole($role);
            //add legal papers
            $this->addLegalPapers($company->id, $request->legal_papers);
            // add addresses
            $this->addAddresses($company->id, $inputs['addresses']);

            // add Company Categories
            $this->addCompanyCategories($company->id, $request->categories);

            if ($userType == AccountType::TYPE['SELLER']){
                $this->addCompanyProducts($company->id, $request->products);
            }

            // send notification to admin
            $company_name = $request->company_name;
            $message = $request->name . ' Create New Company: ' . $company_name;
            $action_type = 'company';
            $action_id = $company->id;
            $users = User::role('Admin')->get();
            $click_action = 'RESULT';

            SendNotificationHelper::notify($users, $message, $company_name, $click_action, $action_type, $action_id);


            $user->notify(new WelcomeEmail($company_name));

        });

        return response()->json([
            'status' => 201,
            'message' => $request->company_name . ' - ' . $request->type . ' ' . __('messages.Account created successfully')
        ], 201);
    }

    /**
     * @param $company_id
     * @param $legal_papers
     * @return void
     */
    private function addLegalPapers($company_id, $legal_papers)
    {
        DB::transaction(function () use ($legal_papers, $company_id) {
            foreach ($legal_papers as $paper) {
                $fileName = StoreFile::store($paper, 'legal_papers');
                LegalPaper::create([
                    "company_id" => $company_id,
                    "file" => $fileName
                ]);
            }
        });
    }

    /**
     * @param $company_id
     * @param $addresses
     * @return void
     */
    private function addAddresses($company_id, $addresses)
    {
        DB::transaction(function () use ($addresses, $company_id) {
            foreach ($addresses as $address) {
                Address::create([
                    'company_id' => $company_id,
                    'country_id' => $address['country_id'],
                    'address_name' => $address['address_name'],
                    'mobile' => $address['mobile'],
                    'building_number' => $address['building_number'],
                    'street_name' => $address['street_name'],
                    'unit_number' => $address['unit_number'],
                    'nearest_landmark' => $address['nearest_landmark'],
                    'district' => $address['district'],
                    'lat' => $address['lat'],
                    'lon' => $address['lon'],
                    'postcode' => $address['postcode'],
                    'name' => $address['name'],
                ]);
            }
        });
    }

    /**
     * @param $company_id
     * @param $categories
     * @return void
     */
    private function addCompanyCategories($company_id, $categories)
    {
        DB::transaction(function () use ($categories, $company_id) {
            foreach ($categories as $category) {
                CompanyCategory::create([
                    "company_id" => $company_id,
                    "category_id" => $category
                ]);
            }
        });
    }
    /**
     * @param $company_id
     * @param $categories
     * @return void
     */
    private function addCompanyProducts($company_id, $products)
    {
        DB::transaction(function () use ($products, $company_id) {
            foreach ($products as $product) {
                CompanyProduct::create([
                    "company_id" => $company_id,
                    "product_id" => $product['product_id'],
                    "unit_price" => $product['unit_price'] ?? 0,
                ]);
            }
        });
    }


    /**
     * @return mixed
     */
    public function listRoles($type)
    {
        if($type !== null){
            $role_permissions = Role::where('name', 'LIKE', $type.'%')->with('permissions')->get();
        }else{
            $role_permissions = Role::with('permissions')->get();

        }

        return response()->json([
            'status' => 200,
            'data' => $role_permissions
        ], 201);
    }

    /**
     * @param $request
     * @return mixed
     */
    public function addEmployee($request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|unique:users,email',
            'name' => 'required|string',
            'role_id' => 'required|string',
            'password' => [
                'required',
                'string',
                'confirmed',
                'min:8',             // must be at least 10 characters in length
                'regex:/[a-z]/',      // must contain at least one lowercase letter
                'regex:/[A-Z]/',      // must contain at least one uppercase letter
                'regex:/[0-9]/',      // must contain at least one digit
            ],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $company = Company::find(auth()->user()->company->id);

        $user = $company->users()->create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        //Get Role
        $role = Role::find($request->role_id);

        //assign role to user
        $user->assignRole($role);

        return response()->json([
            'status' => 201,
            'message' => $user->name . ' ' . __('messages.Account created successfully')
        ], 201);
    }

    /**
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function listEmployee()
    {
        $company = auth()->user()->company;
        if ($company)
            return  (UserResource::collection($company->users()->where('id','!=', auth()->id())->paginate(15)))->response()->setStatusCode(200);
    }

    public function editEmployee($request, $user)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|unique:users,email' . ($user->id ? ",$user->id" : ''),
            'name' => 'required|string',
            'role_id' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $user->syncRoles([$request->role_id]);
        $user2 = $user->update([
            'email' => $request->email,
            'name' => $request->name,
        ]);
        return UserResource::make($user);
    }
}
