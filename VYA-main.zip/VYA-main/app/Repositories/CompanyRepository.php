<?php

namespace App\Repositories;

use App\Helper\EFAA;
use App\Helper\OTO;
use App\Helper\StoreFile;
use App\Http\Resources\CompanyRequestResource;
use App\Http\Resources\CompanyResource;
use App\Imports\SyncProductForSellerImport;
use App\Interfaces\CompanyRepositoryInterface;
use App\Models\AccountType;
use App\Models\Address;
use App\Models\Company;
use App\Models\CompanyRequest;
use App\Models\LegalPaper;
use App\Notifications\ApprovalEmail;
use App\Notifications\RejectEmail;
use App\Notifications\SentDealsLink;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use mysql_xdevapi\Exception;

class CompanyRepository implements CompanyRepositoryInterface
{

    public function syncCategories($request)
    {
        $validator = Validator::make($request->all(),
            [
                'categories' => 'present|array',
                'categories.*' => 'required|exists:categories,id',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $company = auth()->user()->company;

        $categories = $company->categories()->sync($request->categories);

        return response()->json(['data' => $company->categories, 'message' => 'success'], 201);
    }

    public function showCategories($id)
    {
        $company = Company::findOrFail($id);

        return response()->json(['data' => $company->categories, 'message' => 'success'], 200);
    }

    public function syncProducts($request)
    {
        $validator = Validator::make($request->all(),
            [
                'products' => 'present|array',
                'products.*.product_id' => 'required|exists:products,id',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        if (auth()->user()->company->account_type_id != AccountType::TYPE['SELLER']) {
            return response()->json([
                'status' => 401,
                'message' => 'This feature is not available to you'
            ], 401);
        }

        auth()->user()->company->products()->sync($request->products);

        return response()->json([
            'status' => 201,
            'message' => 'success'
        ], 201);
    }

    public function showProducts($request, $id)
    {
        $perPage = $request->get('per_page', 20);

        $company = Company::where('id', $id)->first();

        $data = [];

        foreach ($company->products as $product) {
            $data[] = [
                'id' => $product->id,
                'name' => $product->en_name,
                'unit_price' => $product->unit_price ?? 0
            ];
        }

        return response()->json([
            'status' => 200,
            'data' => $data
        ], 200);
    }

    public function AddAddresses($request, $id)
    {
        $company = Company::findOrFail($id);
        $validator = Validator::make($request->all(),
            [
                'addresses' => 'present|array',
                'addresses.*.address_name' => 'required|max:255',
                'addresses.*.country_id' => 'required|exists:countries,id',
                'addresses.*.mobile' => 'required|string|min:9',
                'addresses.*.name' => 'required|string|min:1',
                'addresses.*.building_number' => 'required|min:1',
                'addresses.*.street_name' => 'required|string',
                'addresses.*.unit_number' => 'required|numeric',
                'addresses.*.nearest_landmark' => 'nullable|string',
                'addresses.*.is_default' => 'nullable',
                'addresses.*.lat' => 'required',
                'addresses.*.lon' => 'required',
                'addresses.*.postcode' => 'required',
                'addresses.*.district' => 'required',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $company_id = $company->id;
        $addresses = $request->addresses;
        DB::transaction(function () use ($addresses, $company_id) {
            foreach ($addresses as $address) {
                Address::create([
                    'company_id' => $company_id,
                    'country_id' => $address['country_id'],
                    'address_name' => $address['address_name'],
                    'mobile' => $address['mobile'],
                    'name' => $address['name'],
                    'building_number' => $address['building_number'],
                    'street_name' => $address['street_name'],
                    'unit_number' => $address['unit_number'],
                    'nearest_landmark' => $address['nearest_landmark'],
                    'lat' => $address['lat'],
                    'lon' => $address['lon'],
                    'postcode' => $address['postcode'],
                    'district' => $address['district'],
                ]);
            }
        });

        return response()->json(['status' => 201, 'data' => $company->addresses], 201);
    }

    public function showAddresses($id)
    {
        $company = Company::findOrFail($id);
        $addresses = $company->addresses()->orderBy('is_default', 'desc')->get();
        return response()->json(['data' => $addresses, 'message' => 'success'], 200);
    }

    public function AddLegalPapers($request, $id)
    {
        $company = Company::findOrFail($id);
        $validator = Validator::make($request->all(),
            [
                'legal_papers' => 'present|array',
                'legal_papers.*' => 'required|file',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $company_id = $company->id;
        $legal_papers = $request->legal_papers;
        DB::transaction(function () use ($legal_papers, $company_id) {
            foreach ($legal_papers as $paper) {
                $fileName = StoreFile::store($paper, 'legal_papers');
                LegalPaper::create([
                    "company_id" => $company_id,
                    "file" => $fileName
                ]);
            }
        });

        return response()->json(['data' => $company->legalPapers, 'message' => 'success'], 201);
    }

    public function showLegalPapers($id)
    {
        $company = Company::findOrFail($id);

        return response()->json(['data' => $company->legalpapers, 'message' => 'success'], 200);
    }

    public function deleteLegalPapers($legalPaper)
    {
        $user = auth()->user();
        if ($user->company->id !== $legalPaper->company_id) {
            return response()->json([
                'status' => 403,
                'error' => 'Unfortunately, you\'ll not be able to do that!',
            ], 403);
        }
        if (isset($legalPaper->file)) {
            StoreFile::delete($legalPaper->file);
        }
        $legalPaper->forceDelete();

        return response()->json(['message' => 'Legal Paper deleted successfully'], 200);
    }

    public function profile($id)
    {
        if (!auth()->user()->hasRole('Admin')) {
            $company = Company::where('id', auth()->user()->company_id)->with(['addresses','categories'])->first();
        } else {
            $company = Company::with(['addresses','categories'])->where('id', $id)->first();
        }
        return new CompanyResource($company);
    }

    public function editAddress($request, $address)
    {
        $user = auth()->user();
        if ($user->company->id !== $address->company_id) {
            return response()->json([
                'status' => 403,
                'error' => 'Unfortunately, you\'ll not be able to do that!',
            ], 403);
        }
        $validator = Validator::make($request->all(),
            [
                'address_name' => 'required|max:255',
                'country_id' => 'required|exists:countries,id',
                'mobile' => 'required|string|min:9',
                'name' => 'required|string|min:1',
                'building_number' => 'required|min:1',
                'street_name' => 'required|string',
                'unit_number' => 'required|numeric',
                'nearest_landmark' => 'required|string',
                'is_default' => 'nullable',
                'lat' => 'required',
                'lon' => 'required',
                'postcode' => 'required',
                'district' => 'required',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        if ($request->is_default == 1) {
            Address::where('company_id', $address->company_id)->update(['is_default' => 0]);
        }

        $address->update($request->all());

        return response()->json(['data' => $address, 'message' => 'Success'], 200);
    }

    public function deleteAddress($address)
    {
        $user = auth()->user();
        if ($user->company->id !== $address->company_id) {
            return response()->json([
                'status' => 403,
                'error' => 'Unfortunately, you\'ll not be able to do that!',
            ], 403);
        }

        $address->delete();

        return response()->json(['message' => 'Address deleted successfully'], 200);

    }

    public function listCompanies($type)
    {
        $company = new Company();
        if (!empty($type)) {
            $company = Company::where('account_type_id', $type);
        }
        return CompanyResource::collection($company->orderBy('status', 'desc')->paginate(15)->appends([
            'per_page' => 15
        ])
        );
    }

    /**
     * @param $request
     * @param $id
     * @return mixed
     */
    public function approveCompany($request, $company)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|boolean',
            'reason' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        if ($request->status) {
            if ($company->account_number == null) {
                if ($company->account_type_id == AccountType::TYPE['BUYER']){
                    $activity = EFAA::get('activity');
                    $activity_id = $activity['data'][0]['id'];

                    $data = [
                        "method" => "BUSINESS",
                        "type" => "SADAD",
                        "activityId" => $activity_id,
                        "companyName" => $company->name,
                        "companyType" => $company->companyType,
                        "companyIdType" => $company->companyIdType,
                        "companyIdNumber" => $company->companyIdNumber,
                        "contractNumber" => $company->contractNumber,
                        "vatNumber" => $company->tax_number,
                        "primaryContactPersonName" => $company->owner_name,
                        "primaryContactPersonNumber" => $company->mobile,
                        "primarycontactpersonemail" => $company->email
                    ];

                    $eResponse = EFAA::post('account/upload/onetime', $data);

                    if ($eResponse['status'] != '200') {
                        return response()->json([
                            'status' => 400,
                            'message' => $eResponse['data']
                        ], 400);
                    }

                    Log::info($eResponse);
                }


                $company->update([
                    'account_number' => $eResponse['data']['accountName'] ?? null,
                    'sadad_number' => $eResponse['data']['accountName'] ?? null,
                    'status' => true
                ]);
            }

            foreach ($company->addresses as $address) {
                $addressData = [
                    "name" => $address->address_name,
                    "code" => Str::random(30),
                    "mobile" => $address->mobile,
                    "lat" => $address->lat,
                    "lon" => $address->lon,
                    "city" => $address->country->en_name,
                    "postcode" => $address->postcode,
                    "address" => $address->building_number . ', ' . $address->unit_number . ', ' . $address->street_name,
                    "contactName" => $address->name,
                    "contactEmail" => $address->email
                ];
                $response = OTO::createPickupLocation($addressData);
                Log::info($response);
                $response = json_decode($response, true);
                $address->update([
                    'oto_code' => $response['pickupLocationCode']
                ]);
            }

                $users = $company->users;
                Notification::send($users, new ApprovalEmail());
                Notification::send($users, new SentDealsLink());

            return response()->json([
                'status' => 200,
                'message' => 'Company Approve'
            ], 200);

        } else {
            Notification::send($company->users, new RejectEmail($request->reason));

            return response()->json([
                'status' => 200,
                'message' => 'Company Reject'
            ], 200);
        }


    }

    public function createEfaaAccount()
    {
        // TODO end point to create efaa account without approve endpoint
    }

    /**
     * @param $request
     * @param $company
     * @return \Illuminate\Http\JsonResponse
     */
    public function changeRequest($request, $company): \Illuminate\Http\JsonResponse
    {
        $auth_company = auth()->user()->company;
        if ($company->id !== $auth_company->id) {
            return response()->json([
                'status' => 403,
                'error' => 'Unfortunately, you\'ll not be able to do that!',
            ], 403);
        }
        $validator = Validator::make($request->all(),
            [
                'name' => 'required|string',
                'tax_number' => 'required|min:15|max:15',
            ]
        );

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $auth_company->requests()->create($request->all());

        return response()->json(['message' => 'Request sent successfully'], 201);
    }

    /**
     * @return mixed
     */
    public function listRequests($request)
    {
        $perPage = $request->get('per_page', 20);

        $company = Company::query();

        if (auth()->user()->getRoleNames()[0] === 'Seller' || auth()->user()->getRoleNames()[0] === 'Buyer') {
            $company = $company->where('company_id', auth()->user()->company->id);
        }

        if ($request->type) {
            $company = $company->where('account_type_id', $request->type == 'buyer' ? '2' : '1');
        }

        $company = $company->orderBY('status', 'asc')->paginate($perPage)->appends([
            'per_page' => $perPage
        ]);

        return CompanyRequestResource::collection($company);
    }

    /**
     * @param $request
     * @param $companyRequest
     */
    public function approveCompanyRequest($request, $companyRequest): \Illuminate\Http\JsonResponse
    {
        $validator = Validator::make($request->all(),
            [
                'status' => 'required|boolean',
            ]
        );
        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        if ($request->status == 1) {
            $type = 'approved';
            $companyRequest->update($request->all());
            $companyRequest->company()->update([
                'name' => $companyRequest->name,
                'tax_number' => $companyRequest->tax_number,
            ]);
        } elseif ($request->status == 2) {
            $type = 'rejected';
            $companyRequest->update($request->all());
        } else {
            return response()->json(['message' => 'Invalid Request status'], 422);
        }
        return response()->json(['message' => 'Company request ' . $type], 201);
    }

    /**
     * @param $data
     * @return \Illuminate\Http\JsonResponse|mixed
     */
    private function efaaStore($data)
    {
        try {

            $eResponse = EFAA::post('account/upload/onetime', $data);

            if ($eResponse['status'] != '200') {
                return response()->json([
                    'status' => 400,
                    'message' => $eResponse['data']
                ], 400);
            }

            return $eResponse;

        } catch (\Exception $e) {
            report($e);
            return response()->json([
                'status' => 400,
                'message' => $e->getMessage()
            ], 400);
        }
    }

    public function syncImport($request)
    {
        $validator = Validator::make($request->all(), [
            'file' => 'required|file',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        Excel::import(new SyncProductForSellerImport(), $request->file);

        return response()->json([
            'status' => 201,
            'message' => 'Product Synced'
        ], 201);
    }
}

