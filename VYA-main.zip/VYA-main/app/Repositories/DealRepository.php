<?php

namespace App\Repositories;

use App\Http\Resources\DealResource;
use App\Interfaces\DealRepositoryInterface;
use App\Models\Category;
use App\Models\CompanyProduct;
use App\Models\Deal;
use App\Models\Product;
use App\Models\UserCategoryMostUsed;
use Illuminate\Support\Facades\Validator;

class DealRepository implements DealRepositoryInterface
{

    public function index($deal, $request)
    {
        $deal = $deal->with(['submissions', 'bids', 'submissionsAddresses', 'product', 'submissions']);
        $perPage = $request->get('per_page', 15);
        $categories = [];
        if (isset($request->category_id)) {
            $category = Category::where('id', $request->category_id)->first();
            if (Auth()->guard('api')->check()) {
                UserCategoryMostUsed::create([
                    'category_id' => $category->id,
                    'user_id' => Auth()->guard('api')->user()->id
                ]);
            }
            $categories = self::flattenChilds($category);
            $categories = $categories->pluck('id')->toArray();
            array_push($categories, $category->id);
        }

        $deal = $deal->running()->whereHas('product', function ($query) use ($request, $categories) {
            if (isset($request->category_id)) {
                $query = $query->whereIn('category_id', $categories);
            }
            if (isset($request->search)) {
                $search = $request->search;
                $query = $query->whereLike(['sku', 'en_name', 'ar_name'], $search);
            }

            if (Auth()->guard('api')->check()) {
                if (Auth()->guard('api')->user()->hasRole(['Buyer', 'Buyer-Finance', 'Buyer-Logistics'])) {
                    if (Auth()->guard('api')->user()->company->has('categories')) {
                        $query = $query->whereIn('category_id', Auth()->guard('api')->user()->company->categories->pluck('id'));
                    }
                } elseif (Auth()->guard('api')->user()->hasRole(['Seller', 'Seller-Finance', 'Seller-Logistics'])) {
                    $query = $query->whereIn('id', CompanyProduct::where('company_id', Auth()->guard('api')->user()->company_id)->pluck('product_id'));
                }
            }

            $query = $query->where('status', true);
            return $query;
        })->latest()->paginate($perPage)->appends([
            'per_page' => $perPage
        ]);

        return DealResource::collection($deal);
    }

    public static function flattenChilds($parent)
    {
        $result = collect([]);
        foreach ($parent->recursiveChilds as $child) {
            $result->push($child);
            $result = $result->merge(static::flattenChilds($child));
        }

        return $result->filter();
    }

    public function show($id)
    {
        $deal = Deal::find($id);
        if (!$deal) {
            return response()->json([
                'status' => 404,
                'message' => 'Deal does not exist',
            ], 404);
        }
        return new DealResource($deal);
    }

    public function update($request, $id)
    {
        $deal = Deal::find($id);

        if (!$deal) {
            return response()->json([
                'status' => 404,
                'message' => 'Deal dos not exist',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'code' => 'required|string|unique:categories,en_name' . ($id ? ",$id" : ''),
            'date_from' => 'required|date|after:today',
            'date_to' => 'required|date|after:date_from',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $deal->code = $request->code;
        $deal->date_from = $request->date_from;
        $deal->date_to = $request->date_to;
        $deal->status = $request->status;

        if ($deal->isDirty('date_from') || $deal->isDirty('date_to')) {

            $product = Product::where('id', $deal->product_id)->whereHas('deals', function ($query) use ($request, $deal) {
                return $query->where('id', '!=', $deal->id)->whereBetween('date_from', [$request->date_from, $request->date_to])->orWhereBetween('date_to', [$request->date_from, $request->date_to]);
            })->first();

            if ($product) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Product already have a deal in this date!',
                ], 400);
            }

        }
        $deal->save();

        return new DealResource($deal);
    }

    public function status($request)
    {
        $deal = Deal::find($request->deal_id);

        if (!$deal) {
            return response()->json([
                'status' => 404,
                'message' => 'Deal dos not exist',
            ], 404);
        }
        $deal->update([
            'status' => $request->status
        ]);
        return response()->json([
            'status' => 200,
            'message' => 'Deal status updated!',
        ], 200);
    }

    public function destroy($id)
    {
        $deal = Deal::find($id);
        if (!$deal) {
            return response()->json([
                'status' => 404,
                'message' => 'Deal dos not exist',
            ], 404);
        }
        $deal->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Deal deleted',
        ], 200);
    }
}
