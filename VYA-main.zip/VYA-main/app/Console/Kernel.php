<?php

namespace App\Console;

use App\Console\Commands\ConvertDealsToClose;
use App\Console\Commands\ConvertDealsToWaiting;
use App\Console\Commands\EmailBeforeClosingDeal;
use App\Console\Commands\FortnightlyCreateDeals;
use App\Console\Commands\PaymentPindingSubmissions;
use App\Console\Commands\PushNotification;
use App\Console\Commands\RemoveSubmissionsAwaitingPaymentExpired;
use App\Console\Commands\SendPriceListToSellers;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        PushNotification::class,
        FortnightlyCreateDeals::class,
        ConvertDealsToClose::class,
        ConvertDealsToWaiting::class,
        EmailBeforeClosingDeal::class,
        PaymentPindingSubmissions::class,
        SendPriceListToSellers::class,
        RemoveSubmissionsAwaitingPaymentExpired::class
    ];

    protected function scheduleTimezone()
    {
        return 'Asia/Riyadh';
    }

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('notification:push')->everyMinute();
        $schedule->command('remove:submissions')->everyTwoMinutes();
        $schedule->command('deals:create')->everyThreeMinutes();
        $schedule->command('deals:waiting')->everyFourMinutes();
        $schedule->command('deals:close')->everyFiveMinutes();
        $schedule->command('deals:message')->everyFiveMinutes();
        $schedule->command('deals:price_list')->everyFourMinutes();
        $schedule->command('deals:payment_pending')->dailyAt('23:30');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
