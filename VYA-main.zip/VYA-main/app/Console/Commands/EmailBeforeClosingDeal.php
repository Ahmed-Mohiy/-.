<?php

namespace App\Console\Commands;

use App\Models\Deal;
use App\Notifications\BeforeCloseDealEmail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

class EmailBeforeClosingDeal extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deals:message';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Message Before Closing the Deals To Buyers';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $deals = Deal::running()->where('is_notify', false)->limit(50)->get();

        if ($deals->isEmpty()){
            Log::info('No Deals Found to Send an Email Before Closing.');
            return $this->info('No Deals Found to Send an Email Before Closing.');
        }

        foreach ($deals as $deal){
            if ($deal->days_left <= 2){
                $deal->update([
                    'is_notify' => true,
                ]);
                $bids = $deal->bids;
                $max_price_arr = [];
                foreach ($bids as $bid){
                    $max_price_arr[] = $bid->prices->max('price');
                }

                $max_price = $max_price_arr ? max($max_price_arr) : 1;
                foreach ($deal->buyers as $company) {
                    $submission = $company->submission($deal->id)->first();
                    $name = $company->name;
                    $price = ($max_price > 1) ? $submission->total_quantity * $max_price : $submission->hits;
                    $shipment = $price * 10 / 100;
                    $vat = ($price + $shipment) * 15 / 100;
                    $total = $price + $vat + $shipment;
                    $message = 'Your minimum price is: ' . $price . ', and your min shipment price is: ' . $shipment . ', and VAT is: ' . $vat . ', Finally your total price is: ' . $total;
                    $url = 'https://vya-frontend.cat-sw.com/deals/'.$deal->product->id;
                    $action_id = $deal->product->id;
                    $action_type = 'product';
                    Notification::send($company->users, new BeforeCloseDealEmail($name, $message, $url, $action_id, $action_type));
                }
                Log::info('Email Sent successfully');
                return $this->info('Email Sent successfully');
            }
        }

        Log::info('No Time of Deals Found to Send an Email Before Closing');
        return $this->info('No Time of Deals Found to Send an Email Before Closing');
    }
}
