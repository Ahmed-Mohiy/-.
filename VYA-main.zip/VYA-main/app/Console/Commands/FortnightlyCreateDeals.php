<?php

namespace App\Console\Commands;

use App\Models\Product;
use App\Models\Social;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class FortnightlyCreateDeals extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deals:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fortnightly create deals automated';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $today = Carbon::today();
        $next = Carbon::today()->addDays(Social::first()->deal_days);

        $products = Product::where('status', true)->whereDoesntHave('deals', function ($query){
            $query->running();
        })->limit(200)->get();

        if ($products->isEmpty()){
            Log::info('No Products without running deals');
            return $this->info('No Products without running deals');
        }

        foreach ($products as $product){
            $code = Str::random(40);
            $product->deals()->create([
                'code' => $code,
                'date_from' => $today,
                'date_to' => $next,
                'status' => 1,
            ]);
        }
        Log::info('Deals Created successfully');
        return $this->info('Deals Created successfully');
    }
}
