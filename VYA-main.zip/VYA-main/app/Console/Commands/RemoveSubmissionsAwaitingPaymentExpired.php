<?php

namespace App\Console\Commands;

use App\Models\Submission;
use Illuminate\Console\Command;

class RemoveSubmissionsAwaitingPaymentExpired extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'remove:submissions';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove Submissions Awaiting Payment Expired';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $submissions = Submission::where('status', Submission::STATUS['CANCELED'])->where('updated_at', '<', today())->get();
        if (!$submissions){
            $this->info('Submissions Empty');
            return Command::INVALID;
        }
        foreach ($submissions as $submission){
            $submission->delete();
        }

        $this->info('Submissions Deleted');
        return Command::SUCCESS;
    }
}
