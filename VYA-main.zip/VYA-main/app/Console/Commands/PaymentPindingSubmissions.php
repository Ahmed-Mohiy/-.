<?php

namespace App\Console\Commands;

use App\Models\Submission;
use App\Notifications\CancelDealEmail;
use App\Notifications\JoiningDealEmail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

class PaymentPindingSubmissions extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deals:payment_pending';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Checking the balance charge to deduct the amount of join to the Deal';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {

        $submissions = Submission::where('status', Submission::STATUS['AWAITING PAYMENT'])->get();

        foreach ($submissions as $submission) {
            if (!in_array(Carbon::today()->toDateString(), Carbon::getWeekendDays()) || Carbon::today() != Carbon::FRIDAY || Carbon::today() != Carbon::SATURDAY || Carbon::parse($submission->created_at)->toDateTimeString() < Carbon::parse('today 9pm')) {

                if ($submission->company->balance >= $submission->deposit_amount) {
                    $submission->update([
                        'status' => Submission::STATUS['JOINED']
                    ]);
                    $submission->company->forceWithdraw($submission->deposit_amount, ['description' => 'Deposit Amount Deduction for Deal Code:' . $submission->deal->code]);
                    $url = 'https://vya-frontend.cat-sw.com/en/deals/' . $submission->deal->product->id;
                    $action_id = $submission->id;
                    $action_type = 'submission';
                    Notification::send($submission->company->users, new JoiningDealEmail($submission->company->name, $url, $action_id, $action_type));
                    return $this->info('Submissions Joined');

                } else {
                    $submission->update([
                        'status' => Submission::STATUS['CANCELED']
                    ]);
                    $url = 'https://vya-frontend.cat-sw.com/en/deals/' . $submission->deal->product->id;
                    $action_id = $submission->deal->product->id;
                    $action_type = 'product';
                    Notification::send($submission->company->users, new CancelDealEmail($submission->company->name, $url, $action_id, $action_type));

                    return $this->info('Submissions Canceled');
                }

            }
        }
        return $this->info('No Submissions Yet');

    }
}
