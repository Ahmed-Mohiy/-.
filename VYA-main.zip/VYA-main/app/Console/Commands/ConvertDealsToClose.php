<?php

namespace App\Console\Commands;

use App\Models\Deal;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class ConvertDealsToClose extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deals:close';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Convert deals automated from Running to close';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $deals = Deal::where('status', 2)->whereHas('product', function ($query){
            $query->where('status', true);
        })->limit(200)->get();

        if ($deals->isEmpty()){
            Log::info('No Deals Waiting to Close');
            return $this->info('No Deals Waiting to Close');
        }

        foreach ($deals as $deal){
            $today = Carbon::today();
            $date_to_plus = Carbon::parse($deal->date_to)->addDays(2);
            if ($today >= $date_to_plus){
                $deal->update([
                    'status' => 3,
                ]);
            }
        }

        Log::info('Deals Updated successfully');
        return $this->info('Deals Updated successfully');
    }
}
