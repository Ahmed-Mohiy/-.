<?php

namespace App\Console\Commands;

use App\Models\AccountType;
use App\Models\Deal;
use App\Notifications\SendPriceListToSellersEmail;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

class SendPriceListToSellers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deals:price_list';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sent Notification to Sellers on Day 15 to Add Price List';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $today = Carbon::today()->toDateString();
        $deals = Deal::whereIn('status', [1,2])->where('date_to', '<', $today)->whereHas('product', function ($query){
            $query->where('status', true);
        })->limit(200)->get();

        if ($deals->isEmpty()){
            Log::info('No Deals Found');
            return $this->info('No Deals Found');
        }

        foreach ($deals as $deal){
            $url = 'https://vya-frontend.cat-sw.com/deals-vendor/'.$deal->id;
            $action_id = $deal->id;
            $action_type = 'deal-vendor';
            foreach ($deal->product->company()->where('account_type_id', AccountType::TYPE['SELLER'])->get() as $company){
                Notification::send($company->users, new SendPriceListToSellersEmail($url, $company->name, $action_id, $action_type));
            }
        }

        Log::info('Price list sent');
        return $this->info('Price list sent');
    }
}
