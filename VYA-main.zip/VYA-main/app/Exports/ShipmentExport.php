<?php

namespace App\Exports;

use App\Models\Shipment;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class ShipmentExport implements FromView
{
    protected $shipments;

    public function __construct($shipments)
    {
        $this->shipments = $shipments;
    }

//    /**
//    * @return \Illuminate\Support\Collection
//    */
//    public function collection()
//    {
//        return $this->shipments;
//    }
    public function view(): View
    {
        return view('exports.shipments', [
            'shipments' => $this->shipments
        ]);
    }
}
