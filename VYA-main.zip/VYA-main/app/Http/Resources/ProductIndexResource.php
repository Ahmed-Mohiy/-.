<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class ProductIndexResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $lang_data = [];

        if ($request->lang == 'ar') {
            $lang_data = [
                'name' => $this->ar_name,
            ];
        } elseif ($request->lang == 'en') {
            $lang_data = [
                'name' => $this->en_name,
            ];
        } else {
            $lang_data = [
                'ar_name' => $this->ar_name,
                'en_name' => $this->en_name,
            ];
        }

        $data = [
            'id' => $this->id,
            'sku' => $this->sku,
            'category_id' => $this->category_id,
            'category' => new CategoryResource($this->category),
            'status' => $this->status,
            'file' => $this->defaultImage ? asset(Storage::url($this->defaultImage->file)) : asset('images/logo-menu.svg'),
            'is_wishlist' => Auth()->guard('api')->check() ? Auth()->guard('api')->user()->wished($this->id) : false,
            'deal' => new DealResource($this->deals()->running()->first())
        ];
        return array_merge($data, $lang_data);
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
