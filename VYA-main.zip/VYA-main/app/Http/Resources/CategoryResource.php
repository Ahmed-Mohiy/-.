<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $lang_data = [];
        if ($request->lang == 'ar'){
            $lang_data = [
                'name' => $this->ar_name,
            ];
        } elseif($request->lang == 'en') {
            $lang_data = [
                'name' => $this->en_name,
            ];
        } else {
            $lang_data = [
                'en_name' => $this->en_name,
                'ar_name' => $this->ar_name,
            ];
        }

        $data = [
            'id' => $this->id,
            'image' => $this->image ? (Storage::exists($this->image) ? asset(Storage::url($this->image)) : asset('images/logo-menu.svg')) : asset('images/logo-menu.svg'),
            'status' => $this->status,
            'parent_id' => $this->parent_id,
            'product_number' => $this->products->count(),
            'categories' => self::collection($this->whenLoaded('categories')),
            'deposit_amount' => $this->deposit_amount,
            'deposit_type' => $this->deposit_type,
            'mostUsed' => $this->mostUsed
        ];

        return array_merge($lang_data, $data);
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
