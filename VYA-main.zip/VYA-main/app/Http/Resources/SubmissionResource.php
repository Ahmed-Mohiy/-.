<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class SubmissionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $created = $this->created_at;
        $now = now();
        if ($this->created_at->format('l') == "Friday") {
            $endDay = Carbon::today()->addDays(2)->endOfDay();
            $difference = [
                'now' => $now,
                'created' => $created,
                'end' => $endDay,
                'diffInHours' => $endDay->diff($now)->format('%H:%i:%s'),
                'diffInHumans' => $endDay->diffForHumans($now),
                'IN' => 'FRIDAY'
            ];
        } elseif ($this->created_at->format('l') == "Saturday" || in_array(Carbon::today()->toDateString(), Carbon::getWeekendDays())) {
            $endDay = Carbon::today()->addDays(1)->endOfDay();
            $difference = [
                'now' => $now,
                'created' => $created,
                'end' => $endDay,
                'diffInHours' => $endDay->diff($now)->format('%H:%i:%s'),
                'diffInHumans' => $endDay->diffForHumans($now),
                'IN' => 'SATURDAY'
            ];
        } else {
            $endDay = Carbon::today()->endOfDay();
            $difference = [
                'now' => $now,
                'created' => $created,
                'end' => $endDay,
                'diffInHours' => $endDay->diff($now)->format('%H:%i:%s'),
                'diffInHumans' => $endDay->diffForHumans($now),
                'IN' => 'Today'
            ];
        }

        return [
            'id' => $this->id,
            'max_price' => $this->max_price,
            'specific_price' => $this->specific_price,
            'quantity' => $this->submissionAddresses()->sum('quantity'),
            'company' => [
                'id' => $this->company->id,
                'name' => $this->company->name,
                'logo' => asset(Storage::url($this->company->logo)),
            ],
            'status' => $this->status,
            'message' => $this->message,
            'deal' => [
                'deal_id' => $this->deal->id,
                'code' => $this->deal->code,
                'status' => $this->deal->status,
                'message' => $this->deal->message,
                'days_left' => $this->deal->days_left,
                'total_days' => Carbon::parse($this->deal->date_from)->diffInDays(Carbon::parse($this->deal->date_to)),
                'file' => $this->deal->product->defaultImage ? asset(Storage::url($this->deal->product->defaultImage->file)) : asset('images/logo-menu.svg'),

            ],
            'product' => new ProductResource($this->deal->product),
//            'product' => [
//                'id' => $this->deal->product->id,
//                'sku' => $this->deal->product->sku,
//                'name' => $request->lang == "ar" ? $this->deal->product->ar_name : $this->deal->product->en_name,
//                'file' => $this->deal->product->defaultImage ? asset(Storage::url($this->deal->product->defaultImage->file)) : asset('images/logo-menu.svg'),
//            ],
            'addresses' => submissionAddressResource::collection($this->whenLoaded('submissionAddresses')),
            'addresses_count' => $this->submissionAddresses->count(),
            'created_at' => new DateTimeResource($this->created_at),
            'down_payment_count_down' => $difference
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
