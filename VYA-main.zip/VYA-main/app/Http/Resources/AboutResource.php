<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class AboutResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if ($request->lang == 'ar'){
            return [
                'caption' => $this->ar_caption,
                'content' => $this->ar_content,
                'image'   => asset(Storage::url($this->image))
            ];
        } elseif($request->lang == 'en') {
            return [
                'caption' => $this->en_caption,
                'content' => $this->en_content,
                'image'   => asset(Storage::url($this->image))
            ];
        } else {
            return [
                'ar_caption' => $this->ar_caption,
                'ar_content' => $this->ar_content,
                'en_caption' => $this->en_caption,
                'en_content' => $this->en_content,
                'image'   => asset(Storage::url($this->image))
            ];
        }
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
