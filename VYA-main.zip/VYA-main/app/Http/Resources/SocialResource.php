<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class SocialResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $color_logo = asset(Storage::url($this->color_logo));
        $white_logo = asset(Storage::url($this->white_logo));

        return [
            "color_logo" => $color_logo,
            "white_logo" => $white_logo,
            "mobile" => $this->mobile,
            "map" => $this->mobile,
            "linkedin" => $this->linkedin,
            "facebook" => $this->facebook,
            "twitter" => $this->twitter,
            "youtube" => $this->youtube,
            "vat_amount" => $this->vat_amount,
            "shipment_amount" => $this->shipment_amount,
            "deal_days" => $this->deal_days,
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
