<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class DealAdminResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'code' => $this->code,
            'product' => [
                'id' => $this->product->id ?? null,
                'sku' => $this->product->sku ?? null,
                'name' => $this->product->en_name ?? null,
                'file' => $this->product->defaultImage ? asset(Storage::url($this->product->defaultImage->file)) : asset('images/logo-menu.svg'),
            ],
            'date_from' => $this->date_from,
            'date_to' => $this->date_to,
            'buyers_count' => $this->submissions_count,
            'suppliers_count' => $this->bids_count,
            'orders_count' => $this->orders_count,
            'total_quantity' => $this->submissionsAddresses->sum('quantity'),
            'total_price' => $this->submissions->sum('max_price'),
            'bids'  => PriceListResource::collection($this->whenLoaded('bids')),
            'submissions'  => SubmissionResource::collection($this->whenLoaded('submissions')),
            'orders'  => OrderResource::collection($this->whenLoaded('orders')),
            'days_left' => $this->days_left,
            'total_days' => Carbon::parse($this->date_from)->diffInDays(Carbon::parse($this->date_to)),
            'is_notify' => $this->is_notify,
            'status' => $this->status,
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
