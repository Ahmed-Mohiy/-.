<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ShipmentSellerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'buyer' => new CompanyResource($this->buyer),
            'seller' => new CompanyResource($this->seller),
            'order_id' => $this->order_id,
            'oto_order_id' => $this->oto_order_id,
            'shipment_number' => $this->shipment_number,
            'shipment_price' => $this->shipment_price,
            'quantity' => $this->quantity,
            'status' => $this->status,
            'message' => $this->message,
            'feedbackLink' => $this->feedbackLink,
            'printAWBURL' => $this->printAWBURL,
            'trackingURL' => $this->trackingURL,
            'addresses' => new AddressResource($this->addressTo),
            'created_at' => new DateTimeResource($this->created_at),
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
