<?php

namespace App\Http\Resources;

use App\Models\Country;
use Illuminate\Http\Resources\Json\JsonResource;

class AddressResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $shipments = [];
        if ($this->buyerShipment){
            foreach ($this->buyerShipment as $shipment){
                $shipments[] = [
                    'id' => $shipment->id,
                    'shipment_number' => $shipment->shipment_number,
                    'oto_order_id' => $shipment->oto_order_id,
                    'created_at' => new DateTimeResource($shipment->created_at),
                ];
            }
        }
        $city = Country::find($this->country_id);
        return [
            'address_name' => $this->address_name,
            'building_number' => $this->building_number,
            'company_id' => $this->company_id,
            'country' => [
                'city_name' => $city->en_name,
                'country_id' => $city->country_id,
                'city_id' => $this->country_id,
                'country_name' => $city->country->en_name,
            ],
            'created_at' => $this->created_at,
            'district' => $this->district,
            'id' => $this->id,
            'is_default' => $this->is_default,
            'lat' => $this->lat,
            'lon' => $this->lon,
            'mobile' => $this->mobile,
            'name' => $this->name,
            'nearest_landmark' => $this->nearest_landmark,
            'oto_code' => $this->oto_code,
            'postcode' => $this->postcode,
            'status' => $this->status,
            'street_name' => $this->street_name,
            'unit_number' => $this->unit_number,
            'updated_at' => $this->updated_at,
            'deleted_at' => $this->deleted_at,
            'shipments' => $shipments
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
