<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class BidResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $today = Carbon::today();
        $finish_time = Carbon::parse($this->deal->date_to);
        $daysLeft = ($today->diffInDays($finish_time, false) < 0)? 0 : $today->diffInDays($finish_time, false);

        $is_joind = true;
        $orders = [];

        return [
            'deal' => [
                'deal_id' => $this->deal->id,
                'deal_code' => $this->deal->code,
                'status' => $this->deal->status,
                'message' => $this->deal->message,
            ],
            'product' => [
                'id' => $this->deal->product->id,
                'sku' => $this->deal->product->sku,
                'name' => $request->lang == "ar" ? $this->deal->product->ar_name : $this->deal->product->en_name,
                'file' =>  $this->deal->product->defaultImage ? asset(Storage::url($this->deal->product->defaultImage->file )) : asset('images/logo-menu.svg'),
                'is_wishlist' => Auth()->guard('api')->check() ? Auth()->guard('api')->user()->wished($this->deal->product->id) : false
            ],
            'shipments' => ShipmentSellerResource::collection($this->whenLoaded('shipments')),
            'date_from' => $this->deal->date_from,
            'date_to' => $this->deal->date_to,
            'buyers_count' => $this->deal->submissions->count(),
            'suppliers_count' => $this->deal->bids->count(),
            'total_quantity' => $this->deal->submissionsAddresses->sum('quantity'),
            'total_price' => $this->deal->submissions->sum('max_price'),
            'days_left' => $daysLeft,
            'status' => $this->status,
            'message' => $this->message,
            'id' => $this->id,
            'is_joind' => $is_joind,
            'product_number' => $this->product_number,
            'price_list_id' => $this->priceList->id,
            'prices' => PriceResource::collection($this->priceList->prices),
            'created_at' => new DateTimeResource($this->created_at)
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
