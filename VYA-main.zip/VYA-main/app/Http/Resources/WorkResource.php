<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class WorkResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $image = asset(Storage::url($this->image));

        if ($request->lang == 'ar'){
            $lang_data = [
                'title' => $this->ar_title,
                'caption' => $this->ar_caption,
            ];
        } elseif($request->lang == 'en') {
            $lang_data = [
                'title' => $this->en_title,
                'caption' => $this->en_caption,
            ];
        } else {
            $lang_data = [
                'en_title' => $this->en_title,
                'en_caption' => $this->en_caption,
                'ar_title' => $this->ar_title,
                'ar_caption' => $this->ar_caption,
            ];
        }

        $data = [
            'id' => $this->id,
            'image' => $image,
            'type' => $this->type,
            'sort' => $this->sort,
        ];

        return array_merge($lang_data, $data);
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
