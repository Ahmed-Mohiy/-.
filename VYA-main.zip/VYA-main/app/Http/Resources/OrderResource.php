<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if ($request->lang == 'ar') {
            $lang_data = [
                'product' => [
                    'product_id' => $this->deal->product->id,
                    'product_name' => $this->deal->product->ar_name,
                    'file' =>  $this->deal->product->defaultImage ? asset(Storage::url($this->deal->product->defaultImage->file )) : asset('images/logo-menu.svg'),
                ]
            ];
        } else {
            $lang_data = [
                'product' => [
                    'product_id' => $this->deal->product->id,
                    'product_name' => $this->deal->product->en_name,
                    'file' =>  $this->deal->product->defaultImage ? asset(Storage::url($this->deal->product->defaultImage->file )) : asset('images/logo-menu.svg'),
                ]
            ];
        }
//        $quantity = 0;
//        $item_price = 0;
//
//        if (!auth()->user()->hasRole('Admin')){
//            if (auth()->user()->company->submission($this->deal_id)->exists()){
//                $quantity = auth()->user()->company->submissionAddress($this->deal_id)->get()->sum('quantity');
//                $item_price = auth()->user()->company->submission($this->deal_id)->first()->max_price;
//            }
//        }


        $addresses = [];

        $submissionAddresses = auth()->user()->hasRole('Admin') ? null : auth()->user()->company->submission($this->deal_id)->first()->submissionAddresses;


        //$this->buyer->submission($this->deal_id)->first()->submissionAddresses


        if ($submissionAddresses){
            foreach ($submissionAddresses as $address){
                $addresses[] = [
                    'id' => $address->id,
                    'quantity' => $address->quantity,
                    'address' => new AddressResource($address->address),
                    'created_at' => $address->created_at,
                ];
            }
        }

        $data = [
            'order_id' => $this->id,
            'deal_id' => $this->deal_id,
            'offer' => $this->offer,
            'deal' => new DealResource($this->whenLoaded('deal')),
            'shipments' => ShipmentSellerResource::collection($this->whenLoaded('shipments')),
            'shipments_count' => $this->shipments->count() ?? null,
            'buyer_id' => $this->buyer_id,
            'buyer' => new CompanyResource($this->whenLoaded('buyer')),
            'seller_id' => $this->seller_id,
            'sellers' => CompanyResource::collection($this->whenLoaded('sellers')),
            'total_quantity' => $this->total_quantity,
            'shipment_price' => $this->shipment_price,
            'status' => $this->status,
            'message' => $this->message,
            'total_price' => $this->total_price,
            'currency_id' => $this->currency->symbolic,
            'addresses' => $addresses,
            'created_at' => new DateTimeResource($this->created_at)
        ];
        return array_merge($data,$lang_data);
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
