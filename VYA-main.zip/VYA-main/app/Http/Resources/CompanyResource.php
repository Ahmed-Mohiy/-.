<?php

namespace App\Http\Resources;

use App\Models\AccountType;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class CompanyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $image = asset(Storage::url($this->logo));

        $papers = [];

        foreach ($this->legalPapers as $paper){
            $papers[] = [
                'file' => asset(Storage::url($paper->file)) ?? null
            ];
        }

        $data = [
            'id' => $this->id,
            'name' => $this->name,
            'logo' => $image,
            'account_type' => (string) array_keys(AccountType::TYPE, $this->account_type_id)[0],
            'address' => AddressResource::collection($this->whenLoaded('addresses')),
            'categories' => CategoryResource::collection($this->whenLoaded('categories')),
            'sadad_number' => $this->sadad_number,
            'account_number' => $this->account_number,
            'legal_paper' => $papers,
            'billing_number' => $this->billing_number,
            'status' => $this->status,
            'tax_number' => $this->tax_number,
        ];

        return $data;
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
