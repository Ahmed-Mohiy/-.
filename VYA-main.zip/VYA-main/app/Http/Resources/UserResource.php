<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use \DB;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $count = [];
        if ($this->hasRole('Seller')) {
            $count = $this->company->bids()->where(DB::raw('date(created_at)'), '>=', Carbon::today()->format('Y') . "-01-01")
                ->get()->groupBy(function ($date) {
                    return Carbon::parse($date->created_at)->format('m'); // grouping by months
                });
        }

        $usermcount = [];
        $userStats = [];

        foreach ($count as $key => $value) {
            $usermcount[(int)$key] = count($value);
        }

        for ($i = 1; $i <= 12; $i++) {
            if (!empty($usermcount[$i])) {
                $userStats[$i] = $usermcount[$i];
            } else {
                $userStats[$i] = 0;
            }
        }

        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'device_token' => $this->device_token,
            'created_at' => new DateTimeResource($this->created_at),
            'updated_at' => $this->updated_at,
            'company_id' => $this->company_id,
            'total_joined_deals' => $this->hasRole('Buyer') ? ($this->company->submissions()->exists() ? $this->company->submissions()->count() : 0) : ($this->hasRole('Seller') ? $this->company->bids()->count() : 0),
            'total_completed_orders' => $this->hasRole('Buyer') ? $this->company->orders()->where('status', '4')->count() : 0,
            'total_uncompleted_orders' => $this->hasRole('Buyer') ? $this->company->orders()->whereIn('status', [0,1,2,3])->count() : 0,
            'total_running_deals' => $this->hasRole('Seller') ? $this->company->bids()->where('status', 1)->count() : 0,
            'total_completed_deals' => $this->hasRole('Seller') ? $this->company->bids()->where('status', 2)->count() : 0,
            'role_id' => $this->roles->first()->id ?? null,
            'role' => $this->getRoleNames(),
            'permissions' => $this->getPermissionsViaRoles()->pluck('name'),
            'company' => [
                'id' => $this->company->id ?? null,
                'name' => $this->company->name ?? null,
            ],
            'chart' => $userStats,
            'socket_id' => $this->socket_id,
            'is_online' => $this->is_online,
            'is_available' => $this->is_available,
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
