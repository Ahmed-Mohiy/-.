<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CourierResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'                =>  $this->id,
            'shipment_number'   =>  $this->shipment_number,
            'oto_order_id'      =>  $this->oto_order_id,
            'buyer'             =>  [
                'buyer_id'      =>  $this->buyer->id,
                'buyer_name'    =>  $this->buyer->name,
            ],

            'seller'             =>  [
                'seller_id'      =>  $this->seller->id,
                'seller_name'    =>  $this->seller->name,
            ],
            'created_at'        =>  $this->created_at,
            'quantity'          =>  $this->quantity,
            'shipment_price'    =>  $this->shipment_price,
            'status'            =>  $this->status,
            'status_message'    =>  $this->message
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
