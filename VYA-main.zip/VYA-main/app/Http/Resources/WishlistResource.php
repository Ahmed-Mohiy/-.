<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class WishlistResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        if ($request->lang == 'ar') {
            $lang_data = [
                'id' => $this->product_id,
                'name' => $this->product->ar_name,
                'description' => $this->product->ar_description,
                'file' =>  ($this->product->defaultImage) ? asset(Storage::url($this->product->defaultImage->file)) : asset('images/logo-menu.svg')

            ];
        } else {
            $lang_data = [
                'id' => $this->product_id,
                'name' => $this->product->en_name,
                'description' => $this->product->en_description,
                'file' =>  ($this->product->defaultImage) ? asset(Storage::url($this->product->defaultImage->file)) : asset('images/logo-menu.svg')
            ];
        }
        $start_time = Carbon::parse($this->product->deals->first()->date_from);
        $finish_time = Carbon::parse($this->product->deals->first()->date_to);
        $daysLeft = $start_time->diffInDays($finish_time, false);
        return $data = [
            'id' => $this->id,
            'product' => $lang_data,
            'days_left' => $daysLeft,
            'code' => $this->product->deals->first()->code,
            'create_at' => new DateTimeResource($this->created_at)
        ];

    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
