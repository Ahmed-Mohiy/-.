<?php

namespace App\Http\Resources;

use App\Models\AccountType;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class CompanyRequestResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */

    public function toArray($request)
    {
        if($this->status == 0) {
        $status = 'Waiting for admin confirmation';
        } elseif ($this->status == 1){
            $status = 'approved';
        }else{
            $status = 'rejected';
        }

        $data = [
            'id' => $this->id,
            'name' => $this->name,
            'tax_number' => $this->tax_number,
            'status' => $status,
            'comment' => $this->comment && $this->status == 2 ? $this->comment : 'no comment',
            'old_data' => [
                'id' => $this->company->id,
                'account_type' => (string) array_keys(AccountType::TYPE, $this->company->account_type_id)[0],
                'name' => $this->company->name,
                'tax_number' => $this->company->tax_number,
            ]
        ];

        return array_merge($data);
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
