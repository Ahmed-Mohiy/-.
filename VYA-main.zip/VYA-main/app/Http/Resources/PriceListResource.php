<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class PriceListResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'available_quantity' => $this->product_number ?? null,
            'currency_symbolic' => $this->pricelist->currency->symbolic,
            'last_updated' => Carbon::parse($this->pricelist->updated_at)->isoFormat('MMM Do YYYY'),
            'is_automated' => $this->is_automated($this->pricelist->id, $this->company_id),
            'price_list_id' => $this->pricelist->id,
            'company' => [
                'id' => $this->company->id,
                'name' => $this->company->name,
                'logo' => asset(Storage::url($this->company->logo)),
            ],
            'prices' => PriceResource::collection($this->priceList->prices),
        ];
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
