<?php

namespace App\Http\Resources;

use App\Helper\FileType;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class ProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $images = [];

        if ($this->files()->exists()) {
            foreach ($this->files->sortBy('sort') as $file) {
                $images[] = [
                    'id' => $file->id,
                    'src' => asset(Storage::url($file->file)),
                    'thumbnail' => $file->thumbnail ? (Storage::exists($file->thumbnail) ? asset(Storage::url($file->thumbnail)) : asset(Storage::url($file->file))) : asset(Storage::url($file->file)),
                    'is_main' => $file->is_main,
                    'sort' => $file->sort,
                    'type' => FileType::get($file->file)
                ];
            }
        } else {
            $images[] = [
                'src' => asset('images/logo-menu.svg'),
                'thumbnail' => asset('images/logo-menu.svg'),
                'is_main' => true,
                'sort' => 0,
                'type' => 'image'
            ];
        }

        $lang_data = [];

        if ($request->lang == 'ar') {
            $lang_data = [
                'name' => $this->ar_name,
                'description' => $this->ar_description,
                'category' => [
                    "name" => $this->category->ar_name,
                    "id" => $this->category->id,
                    "image" => asset(Storage::url($this->category->image)),
                ],
            ];
        } elseif ($request->lang == 'en') {
            $lang_data = [
                'name' => $this->en_name,
                'description' => $this->en_description,
                'category' => [
                    "name" => $this->category->en_name,
                    "id" => $this->category->id,
                    "image" => asset(Storage::url($this->category->image)),
                ],
            ];
        } else {
            $lang_data = [
                'ar_name' => $this->ar_name,
                'en_name' => $this->en_name,
                'ar_description' => $this->ar_description,
                'en_description' => $this->en_description,
                'category' => [
                    "en_name" => $this->category->en_name,
                    "ar_name" => $this->category->ar_name,
                    "id" => $this->category->id,
                    "image" => asset(Storage::url($this->category->image)),
                ],
            ];
        }

        $data = [
            'id' => $this->id,
            'sku' => $this->sku,
            'sku_identifier' => $this->sku_identifier,
            'additional_information' => $this->additional_information,
            'type' => $this->type,
            'category_id' => $this->category_id,
            'status' => $this->status,
            'deposit_type_name' => $this->deposit_type == '1' ? 'Unit' : 'Total',
            'shipment_type' => $this->shipment_type,
            'shipment_type_name' => $this->shipment_type == '1' ? config('app.name') : 'Vendor',
            'images' => $images,
            'specifications' => $this->specifications,
            'created_by' => $this->created_by,
            'created_by_data' => [
                'id' => $this->user->id,
                'name' => $this->user->name,
            ],
            'is_wishlist' => Auth()->guard('api')->check() ? Auth()->guard('api')->user()->wished($this->id) : false,
            'deal' => new DealResource($this->deals()->running()->first()),
            'rate' => RateResource::collection($this->whenLoaded('rate'))
        ];
        return array_merge($data, $lang_data);
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
