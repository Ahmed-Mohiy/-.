<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class RateResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $image = $this->user->company->logo ? asset(Storage::url($this->user->company->logo)) : null;
        if($this->type == 1){
            $data = [
                'id'=>$this->id,
                'rate'=>$this->product,
                'user_id'=>$this->user->id,
                'user'=>$this->user->name,
                'company'=>$this->user->company->name,
                'company_logo'=>$image,
                'comment'=>$this->comment,
            ];
        }else{

            $data = [
                'id'=>$this->id,
                'package_rate'=>$this->packaging,
                'shipping_rate'=>$this->delivery,
                'user_id'=>$this->user->id,
                'user'=>$this->user->name,
                'company'=>$this->user->company->name,
                'company_logo'=>$image,
                'comment'=>$this->comment,
            ];

        }

        return $data;
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
