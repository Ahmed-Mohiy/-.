<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TypeOfContactResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $lang_data = [];
        if ($request->lang == 'ar'){
            $lang_data = [
                'id' => $this->id,
                'name' => $this->ar_name,
            ];
        } else {
            $lang_data = [
                'id' => $this->id,
                'name' => $this->en_name,
            ];
        }

        return $lang_data;
    }

    /**
     * @param $request
     * @param $response
     * @return void
     */
    public function withResponse($request, $response)
    {
        $response->header('status', '200');
    }
}
