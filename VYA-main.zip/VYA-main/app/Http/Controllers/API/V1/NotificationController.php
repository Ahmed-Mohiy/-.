<?php

namespace App\Http\Controllers\API\V1;

use App\Events\Notifications;
use App\Http\Controllers\Controller;
use App\Http\Resources\NotificationResource;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function unreadNotificationsNumber(){
        $unreadNotificationsNumber = isset(auth()->user()->unreadNotifications) ? auth()->user()->unreadNotifications->count() : 0;
        return response()->json([
            'unreadNotificationsNumber' => $unreadNotificationsNumber,
        ], 200);
    }
    public function notifications(){
        return  NotificationResource::collection(auth()->user()->notifications()->paginate(15));
    }
    public function markAsRead(Request $request){

        if (isset($request->notification_id)){
            auth()->user()->unreadNotifications->where('id', $request->notification_id)->markAsRead();
        }else {
            auth()->user()->unreadNotifications->markAsRead();
        }

        event(new Notifications());
        return response()->json([
            'status' => 200,
            'message' => 'Notification Mark as Read'
        ], 200);
    }
}
