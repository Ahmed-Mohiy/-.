<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\StaticRequest;
use App\Repositories\StaticRepository;
use Illuminate\Http\Request;

class StaticController extends Controller
{
    public function __construct(StaticRepository $staticRepository)
    {
        $this->staticRepository = $staticRepository;
        $this->middleware(['role:Admin'], ['except' => ['index']]);
    }

    /**
     * list page
     *
     */
    public function index($type){
        if($type === 'terms'){
            $type = 0;
        }elseif($type === 'privacy'){
            $type = 1;
        }
        return $this->staticRepository->index($type);
    }

    /**
     * @param StaticRequest $request
     * @param $type
     * @return mixed
     */
    public function update(StaticRequest $request, $type)
    {
        if($type === 'terms'){
            $type = 0;
        }elseif($type === 'privacy'){
            $type = 1;
        }
        return $this->staticRepository->update($request, $type);
    }
}
