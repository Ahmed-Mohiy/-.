<?php

namespace App\Http\Controllers\API\V1;

use App\Events\PrivateMessageEvent;
use App\Helper\ContentType;
use App\Helper\StoreFile;
use App\Http\Controllers\Controller;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ChatController extends Controller
{
    public function __construct()
    {
//        $this->middleware(['role:Admin|Buyer|Seller|Admin-Customer-Service|Admin-Procurement']);
    }

    public function conversation($receiver_id) {
        $users = User::where('id', '<>', auth()->id())->whereHas('messages', function ($query){
            return $query->where('receiver_id', auth()->id());
        })->orderBy('id', 'desc')->get();

        $adminInfo = User::findOrFail($receiver_id);

        $myInfo = \auth()->user();

        $myInfo->update([
            'is_available' => $adminInfo->is_online == '0' ? '1' : '0'
        ]);

        $messages = Message::with(['users', 'user_messages'])->whereHas('user_messages', function ($query) use($receiver_id) {
            $query->where(function ($q) use($receiver_id) {
                $q->where('sender_id', auth()->id());
                $q->where('receiver_id', $receiver_id);
            })->orWhere(function ($q) use($receiver_id) {
                $q->where('sender_id', $receiver_id);
                $q->where('receiver_id', auth()->id());
            });
        })->get();

        $chat = [];
        foreach ($messages as $msgs){
            foreach ($msgs->user_messages as $message){
                $chat[] = [ //$messages
                    'message' => $message->message->message,
                    'receiver_id' => $message->receiver_id,
                    'sender_id' => auth()->id(),
                    'created_at' => $message->created_at,
                    'seen_status' => $message->seen_status,
                    'is_file' => $message->message->type
                ];
            }
        }

        $this->updateSeen($adminInfo->id ,$myInfo->id);

        $this->data['adminInfo'] = $adminInfo;
        $this->data['myInfo'] = $myInfo;
        $this->data['users'] = $users;
        $this->data['data'] = $chat;
        $this->data['receiver_id'] = $receiver_id;
        $this->data['is_online'] = $receiver_id;
        $this->data['sender_id'] = auth()->id();
        return response()->json([
            'status' => 200,
            'data' => $this->data
        ]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function sendMessage(Request $request) {
        $validator = Validator::make($request->all(), [
            'message'       => 'nullable|min:1',
            'receiver_id'   => 'required|required|max:255|exists:users,id',
            'sender_id'     => 'nullable|max:255|exists:users,id',
            'file'          => 'nullable|mimes:pdf,doc,docx,csv,xlsx,png,gif,jpg,jpeg|max:204800'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $sender_id      = $request->sender_id ?? auth()->id();
        $receiver_id    = $request->receiver_id;
        $message = new Message();
        $message->message = $request->message;

        if ($request->hasFile('file')) {
            unset($message->message);
            Log::info($request->file);
            $fileName = StoreFile::store($request->file, 'chat');
            $request->merge(['message' => $fileName]);
            $message->message = $request->message;
            $message->type = true;
        }else{
            $message->message = $request->message;
            $message->type = false;
        }

        if ($message->save()) {
            try {
                $message->users()->attach($sender_id, ['receiver_id' => $receiver_id]);
                $sender = User::find($sender_id);
                $receiver = User::find($receiver_id);

                $data = [];
                $data['sender_id'] = $sender_id;
                $data['sender_name'] = $sender->name;
                $data['receiver_id'] = $receiver_id;
                $data['socket_id'] = $receiver->socket_id;
                $data['message'] = $message->message;
                $data['created_at'] = $message->created_at;
                $data['message_id'] = $message->id;
                $data['is_file'] = $message->type;

                event(new PrivateMessageEvent($data));

                return response()->json([
                    'status' => 201,
                    'data' => $data,
                ], 201);
            } catch (\Exception $e) {
                $message->delete();
                return response()->json([
                    'status' => 400,
                    'message' => $e->getMessage(),
                ], 400);
            }
        }
    }

    public function updateOnline(Request $request){
        User::find($request->user_id)->update([
            'socket_id' => $request->socket_id,
            'is_online' => true
        ]);
        return response()->json([
            'status' => 200,
            'message' => 'user is_online update'
        ]);
    }

    public function updateOffline(Request $request){
        try {
            User::where('socket_id', $request->socket_id)->update([
                'is_online' => false
            ]);
            return response()->json([
                'status' => 200,
                'message' => 'user is_offline update'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 400,
                'message' => $e->getMessage()
            ], 400);
        }
    }

    public function seen(Request $request){
        $this->updateSeen($request->adminID, $request->myID);

        return response()->json([
            'status' => 200,
            'message' => 'Message update successfully'
        ]);
    }

    public function updateSeen($sender_id, $receiver_id)
    {
        $messages = Message::with(['user_messages'])->whereHas('user_messages', function ($query) use($sender_id, $receiver_id) {
            $query->where(function ($q) use($sender_id, $receiver_id) {
                $q->where('sender_id', $receiver_id);
                $q->where('receiver_id', $sender_id);
            })->orWhere(function ($q) use($sender_id, $receiver_id) {
                $q->where('sender_id', $sender_id);
                $q->where('receiver_id', $receiver_id);
            });
        })->get();

        foreach ($messages as $message){
            $message->user_messages()->where('seen_status', false)->update(['seen_status' => true]);
        }
        return response()->json([
            'status' => 200,
            'data' => ['receiver_id' => $receiver_id],
        ]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function startConversation(Request  $request){
        $existUser = User::where('id', auth()->id())->whereHas('messages', function ($query){
            return $query->where('sender_id', auth()->id());
        })->orderBy('id', 'desc')->first();

        if ($existUser){
            return response()->json([
                'status' => 201,
                'data' => ['receiver_id' => $existUser->message->receiver_id],
            ]);
        }

        $user = \auth()->user();

        $available_employee = User::inRandomOrder()->role('Admin')->first();

        if ($request->lang == 'ar'){
            $message = 'بدأ محادثة جديدة';
        } else {
            $message = 'Start New Conversation';
        }

        $message = Message::create([
            'message' => $message,
        ]);

        $message->users()->attach($user->id, ['receiver_id' => $available_employee->id]);

        $data = [];
        $data['receiver_id'] = $available_employee->id;

        return response()->json([
            'status' => 201,
            'data' => $data,
        ]);
    }
}
