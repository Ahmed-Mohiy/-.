<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\BidResource;
use App\Http\Resources\DealResource;
use App\Http\Resources\LatestPriceListResource;
use App\Http\Resources\PriceListResource;
use App\Models\AutomaticBid;
use App\Models\Bid;
use App\Models\Deal;
use App\Models\PriceList;
use App\Models\Product;
use App\Rules\IsClosedDealRule;
use App\Rules\IsRunningDealRule;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class JoinSellerDealController extends Controller
{

    public function __construct()
    {
//        $this->middleware(['role_or_permission:Seller|can bid']);
//        $this->middleware(['role_or_permission:Seller|Seller-Finance'], ['only' => ['details']]);
    }

    public function bid(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'deal_id' => ['required', 'exists:deals,id', new IsClosedDealRule()],
            'product_number' => 'required|numeric',
            'currency_id' => ['exists:currencies,id'],
            'price_list.*.price' => 'required|numeric',
            'price_list.*.range_from' => 'required|numeric',
            'price_list.*.range_to' => 'required|numeric',
            'price_list.*' => 'required|array',
            'product_id' => 'required|exists:products,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $company_id = auth()->user()->company->id;
        if (auth()->user()->company->bids()->where('deal_id', $request->deal_id)->count() > 0) {
            return response()->json([
                'status' => 400,
                'error' => 'already joined this deal',
            ], '400');
        }
        DB::transaction(function () use ($request, $company_id) {
            $price_list = PriceList::create([
                'product_id' => $request->product_id,
                'currency_id' => $request->currency_id,
                'company_id' => $company_id,
                'user_id' => auth()->id(),
            ]);

            foreach ($request->price_list as $price) {
                DB::table('prices')->insert([
                    'price_list_id' => $price_list->id,
                    'range_from' => $price['range_from'],
                    'range_to' => $price['range_to'],
                    'price' => $price['price']
                ]);
            }

            Bid::create([
                'company_id' => $company_id,
                'created_by' => auth()->id(),
                'price_list_id' => $price_list->id,
                'product_number' => $request->product_number,
                'new_product_number' => $request->product_number,
                'deal_id' => $request->deal_id,
                'able_negotiate' => 0,
                'product_id' => $request->product_id,
            ]);
        });
        return response()->json([
            'status' => 200,
            'message' => 'Joined Successfully',
        ], 201);

    }

    public function bidByPriceList(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'deal_id' => ['required', 'exists:deals,id', new IsClosedDealRule()],
            'product_number' => 'required|numeric',
            'price_list_id' => 'required|exists:price_lists,id',
            'product_id' => 'required|exists:products,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $company_id = auth()->user()->company->id;

        Bid::create([
            'company_id' => $company_id,
            'created_by' => auth()->id(),
            'price_list_id' => $request->price_list_id,
            'product_number' => $request->product_number,
            'deal_id' => $request->deal_id,
            'able_negotiate' => 0,
            'product_id' => $request->product_id,
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Joined Successfully',
        ], 201);

    }

    public function getLatestPriceList(Product $product)
    {
        // return my last price list: stop use this api
        $company_id = auth()->user()->company->id;
        return new LatestPriceListResource($product->getLatestPriceList()->where('company_id', $company_id)->first());
    }

    public function toggle(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'price_list_id' => ['required', 'exists:price_lists,id'],
            'product_id' => 'required|exists:products,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $company_id = auth()->user()->company->id;
        $count = AutomaticBid::where('company_id', $company_id)->where('product_id', $request->product_id)->count();
        if ($count !== 0) {
            AutomaticBid::where('company_id', $company_id)->where('product_id', $request->product_id)->delete();
        } else {
            AutomaticBid::create([
                'company_id' => $company_id,
                'product_id' => $request->product_id,
                'price_list_id' => $request->price_list_id,
            ]);
        }
        return response()->json([
            'status' => 200,
            'message' => 'success',
        ], 201);
    }

    public function cancel(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'deal_id' => ['required', 'exists:deals,id'],
            'product_id' => 'required|exists:products,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $company_id = auth()->user()->company->id;
        if (!Bid::where('company_id', $company_id)->where('deal_id', $request->deal_id)->first()) {
            return response()->json([
                'status' => 422,
                'error' => 'No Bid on this deal for this company',
            ], 422);
        }
        Bid::where('company_id', $company_id)->where('deal_id', $request->deal_id)->delete();
        AutomaticBid::where('company_id', $company_id)->where('product_id', $request->product_id)->delete();

        return response()->json([
            'status' => 200,
            'message' => 'success',
        ], 201);
    }

    public function show(Deal $deal)
    {
        $bid = $deal->bids()->where('company_id', auth()->user()->company->id)->first();

        if (!$bid) {
            return new DealResource($deal);
        }
        return new BidResource($bid);
    }

    public function editBid(Bid $bid, Request $request)
    {
        $validator = Validator::make($request->all(), [
            'deal_id' => ['required', 'exists:deals,id', new IsClosedDealRule()],
            'product_number' => 'required|numeric',
            'price_list_id' => ['exists:price_lists,id'],
            'price_list.*.price' => 'required|numeric',
            'price_list.*.range_from' => 'required|numeric',
            'price_list.*.range_to' => 'required|numeric',
            'price_list.*' => 'required|array',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        DB::transaction(function () use ($request, $bid) {
            $price_list = PriceList::find($request->price_list_id);
            $price_list->prices()->delete();
            foreach ($request->price_list as $price) {
                DB::table('prices')->insert([
                    'price_list_id' => $price_list->id,
                    'range_from' => $price['range_from'],
                    'range_to' => $price['range_to'],
                    'price' => $price['price']
                ]);
            }

            $bid->update([
                'product_number' => $request->product_number,
            ]);
        });
        return response()->json([
            'status' => 200,
            'message' => 'Bidding updated Successfully',
        ], 201);

    }

    public function getDealSlaps(Deal $deal)
    {
        $total_Quantity = $deal->submissions->sum('total_quantity');
        $slap_size = $total_Quantity * 0.1;
        //$number_of_slaps = round($total_Quantity / $slap_size, 0);
        $slaps = [];
        $count = 0;
        for ($i = 0; $i < $total_Quantity; $i = ceil($i + $slap_size)) {
            $slaps [] = [
                'from' => ceil($i + 1),
                'to' => ceil($i + $slap_size)
            ];
            $count++;
        }
        $number_of_slaps = $count;
        return response()->json(['data' => [
            'total_quantity' => $total_Quantity,
            'slap_size' => round($slap_size, 0),
            'number_of_slaps' => $number_of_slaps,
            'slaps' => $slaps
        ], 'msg' => 'success'], 200);
    }

    public function showDealSlaps($deal_id)
    {
        $deal = Deal::find($deal_id);
        $data = new Collection();
        foreach ($deal->bids as $bid) {

            foreach ($bid->priceList->prices as $key => $price) {
                if ($key == 9) {
                    $data->push($price);
                }
            }
        }
        $low = $data->sortBy('price')->first();
        if (!$low) {
            return response()->json([
                'status' => 404,
                'message' => __('messages.No slap to show')
            ], 404);
        }
        return response()->json([
            'status' => 200,
            'data' => [
                'range_from' => $low->range_from,
                'range_to' => $low->range_to,
                'price' => $low->price,
                'updated_at' => $low->updated_at
            ]
        ], 200);
    }
}
