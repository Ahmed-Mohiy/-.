<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Repositories\CategoryRepository;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function __construct(CategoryRepository $categoryRepository)
    {
        $this->categoryRepository = $categoryRepository;
        $this->middleware(['role:Admin'], ['except' => ['index', 'show']]);
    }

    /**
     * @param Category $categories
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Category $categories, Request $request)
    {
        return $this->categoryRepository->index($categories, $request);
    }

    /**
     * @param Request $request
     * @return \App\Http\Resources\CategoryResource|\Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        return $this->categoryRepository->store($request);
    }

    /**
     * @param $id
     * @return \App\Http\Resources\CategoryResource
     */
    public function show($id)
    {
        return $this->categoryRepository->show($id);
    }

    /**
     * @param Request $request
     * @param $id
     * @return \App\Http\Resources\CategoryResource|\Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        return $this->categoryRepository->update($request, $id);
    }

    /**
     * @param $id
     * @return void
     */
    public function destroy($id)
    {
        return $this->categoryRepository->destroy($id);
    }
}
