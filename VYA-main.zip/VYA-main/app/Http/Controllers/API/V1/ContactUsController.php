<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\ContactUsRequest;
use App\Models\Contact;
use App\Repositories\ContactUsRepository;
use Illuminate\Http\Request;

class ContactUsController extends Controller
{
    public function __construct(ContactUsRepository $contactUsRepository)
    {
        $this->contactUsRepository = $contactUsRepository;
        $this->middleware(['role:Admin|Admin-Customer-Service'], ['except' => ['store']]);
    }

    public function index(){
        return $this->contactUsRepository->index();
    }

    public function store(ContactUsRequest $request){
        return $this->contactUsRepository->store($request);
    }

    public function delete(Contact $contact){
        return $this->contactUsRepository->delete($contact);
    }
}
