<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\SliderStoreRequest;
use App\Models\Slider;
use App\Repositories\SliderRepository;
use Illuminate\Http\Request;

class SliderController extends Controller
{
    public function __construct(SliderRepository $sliderRepository)
    {
        $this->middleware(['role:Admin'], ['except' => ['index', 'show']]);
        $this->sliderRepository = $sliderRepository;
    }

    /**
     * list all slides
     *
     */
    public function index(Slider $sliders, Request $request){
        return $this->sliderRepository->index($sliders, $request);
    }

    /**
     * @param SliderStoreRequest $request
     *
     */
    public function store(SliderStoreRequest $request){
        return $this->sliderRepository->store($request);
    }

    /**
     * @int $slider
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function show($slider){
        return $this->sliderRepository->show($slider);
    }


    public function update(Request $request, $id)
    {
        return $this->sliderRepository->update($request, $id);
    }

    public function destroy($id){
        return $this->sliderRepository->destroy($id);
    }
}
