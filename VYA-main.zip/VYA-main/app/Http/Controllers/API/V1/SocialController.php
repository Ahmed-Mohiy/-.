<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Repositories\SocialRepository;
use Illuminate\Http\Request;

class SocialController extends Controller
{
    public function __construct(SocialRepository $socialRepository)
    {
        $this->socialRepository = $socialRepository;
    }

    public function show(){
        return $this->socialRepository->show();
    }

    /**
     * @param Request $request
     * @return \App\Http\Resources\SocialResource
     */
    public function update(Request $request){
        return $this->socialRepository->update($request);
    }
}
