<?php

namespace App\Http\Controllers\API\V1;

use App\Helper\EFAA;
use App\Helper\SendNotificationHelper;
use App\Http\Controllers\Controller;
use App\Http\Resources\TransactionsResource;
use App\Models\Company;
use App\Models\Order;
use App\Models\Submission;
use App\Models\User;
use App\Notifications\EFAAWebHookEmail;
use App\Notifications\OTOWebHookEmail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class ChargeController extends Controller
{

    public function __construct()
    {
        //$this->middleware(['role:Admin|Buyer'], ['only' => ['transactions']]);
        //$this->middleware(['role:Buyer|Buyer-Finance'], ['only' => ['balance', 'refresh', 'charge']]);
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function balance()
    {
        return response()->json([
            'status' => 200,
            'data' => [
                'balance' => auth()->user()->company->balance
            ],
        ], 200);
    }

    public function receipt(){
        $data = new Collection();

        $submissions = auth()->user()->company->submissions()->where('status', Submission::STATUS['AWAITING PAYMENT'])->get();
        $orders = auth()->user()->company->orders()->where('status', Order::STATUS['WAITING_PRICE'])->get();

        $missions = [];
        $ordeing = [];

        foreach ($submissions as $submission){
            $missions[] = [
                'deal_code' => $submission->deal->code,
                'deposit_amount' => $submission->deposit_amount
            ];
        }

        foreach ($orders as $order){
            $ordeing[] = [
                'order_id' => $order->id,
                'total_price' => $order->total_price
            ];
        }

        $data->push(['submissions' => $missions, 'orders' => $ordeing]);

        return response()->json([
            'status' => 200,
            'data' => $data,
        ], 200);
    }

    /**
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function transactions()
    {
        if (auth()->user()->hasRole('Admin')){
            $transactions = Company::whereHas('transactions')->with('transactions')->latest()->paginate(15);
        } else {
            $transactions = auth()->user()->company->transactions()->latest()->paginate(15);
        }

        return TransactionsResource::collection($transactions);
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        auth()->user()->company->wallet->refreshBalance();
        return response()->json([
            'status' => 200,
            'data' => [
                'balance' => auth()->user()->company->balance
            ],
        ], 200);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function charge(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $company = auth()->user()->company;

        // auth()->user()->company->deposit($request->amount, ['description' => 'charge account']);
        try {
            $activity = EFAA::get('activity');
            $activity_id = $activity['data'][0]['id'];
            $data = [
                "accountNumber" => $company->account_number,
                "billNumber" => Str::random(10),
                "entityActivityId" => $activity_id,
                "customerFullName" => $company->owner_name,
                "customerEmailAddress" => $company->email,
                "customerMobileNumber" => $company->mobile,
                "dueDate" => Carbon::today()->format('Y-m-d'),
                "billItemList" => [
                    [
                        "name" => "Add New Credit: " . $request->amount,
                        "quantity" => 1,
                        "unitPrice" => $request->amount,
                        "discount" => 0,
                        "discountType" => "FIXED",
                        "vat" => "0.05"
                    ]
                ]
            ];

            $efaaAccount = EFAA::post('recurring/onetime', $data);

            return response()->json([
                'status' => 201,
                'message' => __('validation.attributes.charge_message'),
                'data' => [
                    'sadad_number' => $company->sadad_number,
                    'bill_number' => $company->account_number,
                    'balance' => auth()->user()->company->balance,
                    'efaa' => $efaaAccount
                ],
            ], 201);
        } catch (\Exception $e) {
            report($e);
            return response()->json([
                'status' => 400,
                'message' => $e->getMessage()
            ], 201);
        }

    }

    public function webhook(Request $request)
    {
        $company = Company::where('sadad_number', $request->sadadNumber)->firstOrFail();
        $requestBody = trim(preg_replace('/\s+/', ' ', json_encode($request->all())));
        $signature = $request->header('signature');
        $pubkeyid = openssl_pkey_get_public('-----BEGIN CERTIFICATE-----
MIIGfzCCBWegAwIBAgIEXVHeTDANBgkqhkiG9w0BAQsFADBSMQswCQYDVQQGEwJT
QTENMAsGA1UEChMEU0FNQTEbMBkGA1UECxMSU0FNQSBlVHJ1c3QgQ2VudGVyMRcw
FQYDVQQDEw5TQU1BIFNoYXJlZCBDQTAeFw0yMjAyMjExMTI3MTVaFw0yNDAyMjEx
MTU3MTVaMF4xCzAJBgNVBAYTAlNBMQ0wCwYDVQQKEwRTQU1BMRswGQYDVQQLExJT
QU1BIGVUcnVzdCBDZW50ZXIxFDASBgNVBAsTC1NBTUEgRG9tYWluMQ0wCwYDVQQD
EwRlZmFhMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0y1D5WVv0K78
2TT7or3izBqq50cX0oHVbJ0EX6w5W5DYjpXBnjdCEkIA3jv7Kt6T+40qnZW0QSXG
Lx6qZp6HqRDJgpHIpq/zCGeabIyOwK2NujKIVyFI8QZ3DsZSrt2qgT6Ga3INrKkX
ubZ6WyCtxVd7vAtGVWtTWcBBuaZvH0xqmrmQlvBadfokwfqS8heq7Dqx2ZebLvgM
odztgwIV8bPXYz7fcshp1rlqIjGk3ugM7LvT4VBbP1wH8U3F134so9nEQ5QTWzQX
C3KyBcf6WyRQ6zWLbd1jPR7S3UGq9EmvROIa5cYgz4G7zZwKH2Wzj0zQzo/8N3tg
mLJEQZ+HsQIDAQABo4IDTzCCA0swCwYDVR0PBAQDAgP4MFgGCWCGSAGG+mseAQRL
DElUaGUgcHJpdmF0ZSBrZXkgY29ycmVzcG9uZGluZyB0byB0aGlzIGNlcnRpZmlj
YXRlIG1heSBoYXZlIGJlZW4gZXhwb3J0ZWQuMB0GA1UdJQQWMBQGCCsGAQUFBwMB
BggrBgEFBQcDAjCBxAYDVR0gBIG8MIG5MIG2Bg0rBgEEAYGHHQEBBgABMIGkMIGh
BggrBgEFBQcCAjCBlBqBkVRoaXMgY2VydGlmaWNhdGUgaGFzIGJlZW4gaXNzdWVk
IGJ5IFNBTUEgZVRydXN0IENlbnRlci4gU0FNQSBkb2VzIG5vdCBhY2NlcHQgYW55
IGxpYWJpbGl0eSBmb3IgYW55IGNsYWltIGV4Y2VwdCBhcyBleHByZXNzbHkgcHJv
dmlkZWQgaW4gdGhpcyBDUC4wDwYDVR0RBAgwBoIEZWZhYTCCAVYGA1UdHwSCAU0w
ggFJMIHaoIHXoIHUhmZodHRwOi8vcGtpZnJvbnQtcDEuZXRydXN0LWNlbnRlci5z
YW1hLmdvdi5zYS9DUkwvc2FtYV9zaGFyZWRfY2Ffc2FtYV9ldHJ1c3RfY2VudGVy
X21hX2Nfc2FfY3JsZmlsZS5jcmyGamxkYXA6Ly9QS0lDQS1EUi9jbj1TQU1BJTIw
U2hhcmVkJTIwQ0Esb3U9U0FNQSUyMGVUcnVzdCUyMENlbnRlcixvPVNBTUEsYz1T
QT9jZXJ0aWZpY2F0ZVJldm9jYXRpb25MaXN0P2Jhc2UwaqBooGakZDBiMQswCQYD
VQQGEwJTQTENMAsGA1UEChMEU0FNQTEbMBkGA1UECxMSU0FNQSBlVHJ1c3QgQ2Vu
dGVyMRcwFQYDVQQDEw5TQU1BIFNoYXJlZCBDQTEOMAwGA1UEAxMFQ1JMMTAwKwYD
VR0QBCQwIoAPMjAyMjAyMjExMTI3MTVagQ8yMDIzMDcxNzExNTcxNVowHwYDVR0j
BBgwFoAUVMwso2AIJir4u/8qKvZ164nEQQEwHQYDVR0OBBYEFJ8yAp5TQ4b9JSiF
aVqx3JDWCtwSMAkGA1UdEwQCMAAwGQYJKoZIhvZ9B0EABAwwChsEVjguMwMCBLAw
DQYJKoZIhvcNAQELBQADggEBAESNPpgKaNpdwAy3BmWXzvAKjI5K7ECu41yytnG2
xF6Nkzm7+v5w/dExeylMh995wt7Y9vDVkGaYkoUNfANGmteEKVuBuo2UXLw8PQRG
3OrlxcEmOdbKPrxr5e+QsVN5JE4shheYd7jt/rMXXTJpGUi4aHEN4BpEo6AKED+w
DDMtZvWcrfCxG/g/qmND/jB0TluM/a5sDG3+zF2qjGYXt7Luc4NTf1WTPiisdny/
WRsqKmY3usso9N/OrUCK9ZcM01YJCq7sqjcC6j0+SSuqwez9xErnzu68375yPomb
e/lTiaDkrDrHzJmPe61tEiochcfNWm97TXoiKVNO9PSYr9g=
-----END CERTIFICATE-----
');
        $ok = openssl_verify($requestBody, base64_decode($signature), $pubkeyid, "sha256WithRSAEncryption");
        if ($ok == 1) {
            $company->deposit($request->paymentAmount, ['description' => 'charge account', 'billNumber' => $request->billNumber]);

            // send notification to admin
            $title = 'Account Charged';
            $message = 'Account Charge Successfully';
            $action_type = 'company';
            $action_id = $company->id;
            $users = $company->users;
//            $click_action = 'RESULT';


            Notification::send($users, new EFAAWebHookEmail($title, $message, $action_id, $action_type));
//            SendNotificationHelper::notify($users, $message, $company_name, $click_action, $action_type, $action_id);

            return response()->json([
                'status' => 201,
                'message' => 'Account Charge Successfully'
            ], 201);
        } elseif ($ok == 0) {
            return response()->json([
                'status' => 422,
                'message' => 'invalid Signature'
            ], 422);
        } else {
            return response()->json([
                'status' => 422,
                'message' => 'Error checking signature'
            ], 422);
        }
    }
}
