<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\AccountType;
use App\Models\Address;
use App\Models\Company;
use App\Models\CompanyRequest;
use App\Models\LegalPaper;
use App\Models\User;
use App\Repositories\CompanyRepository;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    public function __construct(CompanyRepository $companyRepository)
    {
//        $this->middleware(['role:Seller|Buyer'], ['except' => ['listCompanies', 'showCategories', 'showAddresses', 'approveCompany', 'listRequests', 'approveCompanyRequest']]);
        $this->middleware(['role:Admin|Admin-Customer-Service'], ['only' => ['approveCompany', 'listRequests', 'approveCompanyRequest', 'listCompanies']]);
        $this->companyRepository = $companyRepository;
    }

    public function syncCategories(Request $request){
        return $this->companyRepository->syncCategories($request);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function showCategories($id = null)
    {
        if(empty($id)){
            $id = auth()->user()->company->id;
        }
        return $this->companyRepository->showCategories($id);
    }
    public function syncProducts(Request $request){
        return $this->companyRepository->syncProducts($request);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function showProducts(Request $request, $id = null)
    {
        if(empty($id)){
            $id = auth()->user()->company->id;
        }
        return $this->companyRepository->showProducts($request, $id);
    }

    public function addAddresses(Request $request)
    {
        $id = auth()->user()->company->id;
        return $this->companyRepository->AddAddresses($request, $id);
    }

    public function editAddress(Request $request, Address $address)
    {
        return $this->companyRepository->editAddress($request, $address);
    }

    public function deleteAddress(Address $address)
    {
        return $this->companyRepository->deleteAddress($address);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function showAddresses($id=null)
    {
        if(empty($id)){
            $id = auth()->user()->company->id;
        }
        return $this->companyRepository->showAddresses($id);
    }


    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function showLegalPapers($id=null)
    {
        if(empty($id)){
            $id = auth()->user()->company->id;
        }
        return $this->companyRepository->showLegalPapers($id);
    }

    public function addLegalPapers(Request $request){
        $id = auth()->user()->company->id;
        return $this->companyRepository->AddLegalPapers($request, $id);
    }

    public function deleteLegalPapers(LegalPaper $legalPaper){
        return $this->companyRepository->deleteLegalPapers($legalPaper);
    }

    public function profile($id = null)
    {
        return $this->companyRepository->profile($id);
    }

    public function listCompanies($type=null)
    {
        if($type === 'vendor'){
            $type = AccountType::TYPE['SELLER'];
        }elseif ($type === 'buyer'){
            $type = AccountType::TYPE['BUYER'];
        }

        return $this->companyRepository->listCompanies($type);
    }

    public function approveCompany(Request $request, $id){
        $company = Company::find($id);
        return $this->companyRepository->approveCompany($request, $company);
    }

    public function approveCompanyRequest(Request $request, CompanyRequest $companyRequest){
        return $this->companyRepository->approveCompanyRequest($request, $companyRequest);
    }

    public function changeRequest(Request $request, Company $company){
        return $this->companyRepository->changeRequest($request, $company);
    }

    public function listRequests(Request $request){
        return $this->companyRepository->listRequests($request);
    }
    public function listUserRequests(Request $request){
        return $this->companyRepository->listRequests($request);
    }
    public function syncImport(Request $request){
        return $this->companyRepository->syncImport($request);
    }
}
