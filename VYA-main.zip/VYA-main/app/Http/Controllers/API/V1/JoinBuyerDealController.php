<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\SubmissionResource;
use App\Models\Currency;
use App\Models\Deal;
use App\Models\Product;
use App\Models\Submission;
use App\Models\SubmissionAddress;
use App\Notifications\DownPaymentAmountForBuyers;
use App\Rules\CheckCompanyBalanceRule;
use App\Rules\HesAddressRule;
use App\Rules\IsRunningDealRule;
use App\Rules\ProductHasSellerRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Validator;

class JoinBuyerDealController extends Controller
{
    public function __construct()
    {
        $this->middleware(['role_or_permission:Buyer|join deal']);
        $this->middleware(['role_or_permission:Buyer|Buyer-Finance|Seller'], ['only' => ['show']]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Request $request)
    {
        $perPage = $request->get('per_page', 20);

        $submission = Submission::with(['company','deal','deal.product','submissionAddresses'])->where('company_id', auth()->user()->company_id)->paginate($perPage)->appends([
            'per_page' => $perPage
        ]);
        return SubmissionResource::collection($submission);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function join(Request $request)
    {
//        $quant = array_sum(array_column($request->addresses, 'quantity'));
        $validator = Validator::make($request->all(), [
            'deal_id' => ['required', 'exists:deals,id', new IsRunningDealRule(), new ProductHasSellerRule()],
            'max_price' => 'required|numeric',
            'specific_price' => 'nullable',
            'addresses.*.address_id' => ['exists:addresses,id', new HesAddressRule()],
            'addresses.*.quantity' => 'required|numeric',
            'addresses' => 'required|array'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $submission = Submission::where('deal_id', $request->deal_id)->where('company_id', auth()->user()->company->id)->first();

        if ($submission) {
            return response()->json([
                'status' => 400,
                'message' => 'You are in the deal already',
            ], '400');
        }

        $submission = Submission::create([
            'deal_id' => $request->deal_id,
            'company_id' => auth()->user()->company->id,
            'max_price' => $request->max_price ?? null,
            'specific_price' => $request->specific_price ?? false,
            'currency_id' => Currency::NAME['SR'],
            'status' => Submission::STATUS['AWAITING PAYMENT']
        ]);


        foreach ($request->addresses as $address) {
            SubmissionAddress::create([
                'submission_id' => $submission->id,
                'address_id' => $address['address_id'],
                'quantity' => $address['quantity']
            ]);
        }

        $deposit_deduction = $this->getDeduction($submission);

        if (auth()->user()->company->balance >= $deposit_deduction) {
            $submission->update([
                'deposit_amount' => $deposit_deduction,
                'status' => Submission::STATUS['JOINED']
            ]);

            auth()->user()->company->forceWithdraw($deposit_deduction, ['description' => 'Deposit Amount Deduction for Deal Code:' . $submission->deal->code]);

        } else {
            if (!in_array(Carbon::today()->toDateString(), Carbon::getWeekendDays()) || Carbon::today() != Carbon::FRIDAY || Carbon::today() != Carbon::SATURDAY || Carbon::parse($submission->created_at)->toDateTimeString() < Carbon::parse('today 9pm')){
                $date = Carbon::parse('today 11:59pm');
            } else {
                $date = Carbon::parse('tomorrow 11:59pm');
            }

            Notification::send(auth()->user()->company->users, new DownPaymentAmountForBuyers($date, $deposit_deduction, $submission->deal->id));
        }

        $submission->update([
            'deposit_amount' => $deposit_deduction,
        ]);

        return response()->json([
            'status' => 201,
            'message' => 'Joined Successfully',
        ], 201);

    }

    /**
     * @param $id
     * @return SubmissionResource|\Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $submission = Submission::with(['company','deal','deal.product','submissionAddresses'])->where('id', $id)->where('company_id', auth()->user()->company_id)->first();
        if (!$submission) {
            return response()->json([
                'status' => 404,
                'error' => 'Submission dos not exist',
            ], 404);
        }
        return new SubmissionResource($submission);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'submission_id' => ['required', 'string', 'exists:submissions,id'],
            'max_price' => 'nullable|numeric',
            'addresses.*.submission_address_id' => ['nullable', 'exists:submission_addresses,id'],
            'addresses.*.address_id' => ['exists:addresses,id'],
            'addresses.*.quantity' => 'required|numeric',
            'addresses.*' => 'required|array'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $submission = Submission::where('company_id', auth()->user()->company->id)->where('id', $request->submission_id)->first();

        if (!$submission) {
            return response()->json([
                'status' => 404,
                'message' => 'Not Found!',
            ], 404);
        }

        $submission->update([
            'max_price' => $request->max_price
        ]);

        foreach ($request->addresses as $address) {
            $submission->submissionAddresses()->updateOrCreate(
                ['id' => $address['submission_address_id']],
                [
                    'submission_id' => $submission->id,
                    'address_id' => $address['address_id'],
                    'quantity' => $address['quantity']
                ]
            );
        }

        $deposit_deduction = $this->getDeduction($submission);

        if ($deposit_deduction != $submission->deposit_amount) {
            $priceDifference = $submission->deposit_amount - $deposit_deduction;
            if (auth()->user()->company->balance >= $priceDifference) {
                $submission->update([
                    'deposit_amount' => $deposit_deduction,
                    'status' => Submission::STATUS['JOINED']
                ]);
                auth()->user()->company->forceWithdraw($priceDifference, ['description' => 'Deposit Amount Deduction Price Difference for Deal Code:' . $submission->deal->code]);
            }
            $submission->update([
                'deposit_amount' => $deposit_deduction,
                'status' => Submission::STATUS['AWAITING PAYMENT']
            ]);
        }

        return response()->json([
            'status' => 200,
            'message' => 'Submission Updated Successfully',
        ], 200);
    }

    public function cancel(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'submission_id' => ['required', 'string', 'exists:submissions,id'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $submission = Submission::where('company_id', auth()->user()->company->id)->where('id', $request->submission_id)->first();

        if (!$submission) {
            return response()->json([
                'status' => 404,
                'message' => 'Not Found!',
            ], 404);
        }

        $submission->update([
            'status' => Submission::STATUS['CANCELED']
        ]);

        if ($submission->deal->running()) {
            auth()->user()->company->deposit($submission->deposit_amount, ['description' => 'The Amount has been returned to your e-wallet for Deal Code:' . $submission->deal->code]);
            // TODO send notification about return amount if exts
        }

        return response()->json([
            'status' => 200,
            'message' => 'Submission Canceled Successfully',
        ], 200);
    }

    /**
     * @param $submission
     * @return float|int
     */
    private function getDeduction($submission): int|float
    {
        $deposit_type = $submission->deal->product->category->deposit_type;
        $deposit_amount = $submission->deal->product->category->deposit_amount;

        if ($deposit_type == 0) { //total
            $deposit_deduction = $deposit_amount;
        } else { //unit
            $quantity = $submission->submissionAddresses->sum('quantity');
            $deposit_deduction = $quantity * $deposit_amount;
        }
        return $deposit_deduction;
    }

    public function averagePrice(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => ['required', 'exists:products,id'],
            'quantity' => 'required|numeric'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $product = Product::find($request->product_id);
        $quantity = $request->quantity;
        $prices = new Collection();
        $deals = $product->deals()->orderBy('id', 'desc')->limit(6)->get();

        if ($product->deals->count()) {
            foreach ($deals as $deal) {
                foreach ($deal->bids as $bid) {
                    foreach ($bid->priceList->prices as $price) {
                        if ($quantity >= $price->range_from && $quantity <= $price->range_to) {
                            $prices->push($price);
                        }
                    }
                }
            }
        } else {
            return response()->json([
                'status' => 200,
                'data' => [
                    'condition' => 'There are no deals for this Product',
                    'average' => 0
                ]
            ], 200);
        }

        $average = round($prices->avg('price'), 1);
        $condition = 'Average Market Price';

        if ($prices->isEmpty()) {
            foreach ($deals as $deal) {
                foreach ($deal->bids as $bid) {
                    $prices->push($bid->priceList->prices()->orderByDesc('id')->first());
                }
            }
            $condition = 'Last Slap with max Price';
            $average = round($prices->avg('price'), 1);
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'condition' => $condition,
                'average' => $average
            ]
        ], 200);
    }
}
