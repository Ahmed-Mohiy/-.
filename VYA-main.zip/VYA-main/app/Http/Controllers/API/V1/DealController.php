<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\Deal;
use App\Repositories\DealRepository;
use Illuminate\Http\Request;

class DealController extends Controller
{
    public function __construct(DealRepository $dealRepository)
    {
        $this->dealRepository = $dealRepository;
        $this->middleware(['role:Admin|Admin-Procurement'], ['except' => ['index', 'show']]);
    }

    /**
     * @param Deal $deal
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Deal $deal, Request $request)
    {
        return $this->dealRepository->index($deal, $request);
    }

    /**
     * @param $id
     * @return \App\Http\Resources\DealResource|\Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        return $this->dealRepository->show($id);
    }

    /**
     * @param Request $request
     * @param $id
     * @return \App\Http\Resources\DealResource|\Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        return $this->dealRepository->update($request, $id);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function status(Request $request)
    {
        return $this->dealRepository->status($request);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        return $this->dealRepository->destroy($id);
    }
}
