<?php

namespace App\Http\Controllers\API\V1;

use App\Helper\OTO;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ShipmentController extends Controller
{

    /**
     * @param $id
     * @return mixed
     */
    public function history(Request $request){
        $oto_history_response = OTO::orderHistory($request->order_ids);
        return json_decode($oto_history_response);
    }
}
