<?php
namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\AddAdminRequest;
use App\Http\Requests\addPermissionRequest;
use App\Http\Requests\addRoleRequest;
use App\Http\Requests\assignRoleRequest;
use App\Http\Requests\givePermissionRequest;
use App\Http\Requests\syncRoleRequest;
use App\Http\Requests\updateAdminRequest;
use App\Interfaces\UserRepositoryInterface;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->middleware(['role:Admin'],['except' => [
            'index', 'register', 'listRoles', 'addEmployee', 'listEmployee', 'editEmployee'
        ]]);
        $this->userRepository = $userRepository;
    }


    public function index($type)
    {
        return $this->userRepository->index($type);
    }

    /**
     * @param addPermissionRequest $request
     *
     */
    public function addPermission(addPermissionRequest $request)
    {
        return $this->userRepository->addPermission($request);
    }


    public function listRoles($type = null)
    {
        return $this->userRepository->listRoles($type);
    }

    /**
     * @param addRoleRequest $request
     *
     */
    public function addRoles(addRoleRequest $request)
    {
        return $this->userRepository->addRoles($request);
    }

    /**
     * @param givePermissionRequest $request
     * @return mixed
     */
    public function givePermissions(givePermissionRequest $request)
    {
        return $this->userRepository->givePermissions($request);
    }

    /**
     * @param assignRoleRequest $request
     * @return mixed
     */
    public function assignRole(assignRoleRequest $request)
    {
        return $this->userRepository->assignRole($request);
    }

    /**
     * @param syncRoleRequest $request
     * @return mixed
     */
    public function syncRole(syncRoleRequest $request)
    {
        return $this->userRepository->syncRole($request);
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function addUser(Request $request){
        return $this->userRepository->addUser($request);
    }

    public function register(Request $request){
        return $this->userRepository->addUser($request);
    }

    /**
     * @param updateAdminRequest $request
     * @param User $user
     * @return mixed
     */
    public function updateUser(updateAdminRequest $request, User $user){
        return $this->userRepository->updateUser($request, $user->id);
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function addEmployee(Request $request){
        return $this->userRepository->addEmployee($request);
    }

    public function listEmployee(){
        return $this->userRepository->listEmployee();
    }

    public function editEmployee(Request $request, User $user){
        return $this->userRepository->editEmployee($request, $user);
    }
}
