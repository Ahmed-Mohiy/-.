<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\PushNotifications;
use App\Repositories\PushNotificationRepository;
use Illuminate\Http\Request;

class PushNotificationController extends Controller
{
    public function __construct(PushNotificationRepository $pushNotificationRepository)
    {
        $this->pushNotificationRepository = $pushNotificationRepository;
        $this->middleware(['role:Admin'], ['except' => ['index', 'getTopics']]);
    }
    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function getTopics() {
        return $this->pushNotificationRepository->getTopics();
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(PushNotifications $pushNotifications, Request $request) {
        return $this->pushNotificationRepository->index($pushNotifications, $request);
    }

    /**
     * @param Request $request
     * @return void
     */
    public function store(Request $request){
        return $this->pushNotificationRepository->store($request);
    }
}
