<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Notifications\PasswordResetSuccess;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ChangePasswordController extends Controller
{
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "old_password"      => "required|min:1|max:255",
            "new_password"      => "required|min:1|max:255"
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        if ($request->old_password == $request->new_password){
            return response()->json([
                'status' => 400,
                'error' => 'Passwords can not identical',
            ], '400');
        }

        $checkPassword = Hash::check($request->old_password, auth()->user()->password);

        if (!$checkPassword){
            return response()->json([
                'status'    => 400,
                'error'   => 'Passwords not correct'
            ], 400);
        }

        auth()->user()->update([
            'password' => bcrypt($request->new_password),
            'password_change' => false
        ]);

        auth()->user()->notify(new PasswordResetSuccess());

        return response()->json([
            'status' => 200,
            'message' => 'Password Changed Successfully',
        ], '200');

    }
}
