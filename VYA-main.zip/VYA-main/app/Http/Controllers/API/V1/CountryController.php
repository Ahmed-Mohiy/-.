<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Repositories\CountryRepository;
use Illuminate\Http\Request;

class CountryController extends Controller
{
    public function __construct(CountryRepository $countryRepository)
    {
        $this->countryRepository = $countryRepository;
        $this->middleware(['role:Admin'], ['except' => ['index']]);
    }

    /**
     * @param Country $countries
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Country $countries, Request $request)
    {
        return $this->countryRepository->index($countries, $request);
    }

    /**
     * @param Request $request
     * @return \App\Http\Resources\CountryResource|\Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        return $this->countryRepository->store($request);
    }

    /**
     * @param $id
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function show($id)
    {
        return $this->countryRepository->show($id);
    }

    /**
     * @param Request $request
     * @param $id
     * @return \App\Http\Resources\CountryResource|\Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        return $this->countryRepository->update($request, $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
