<?php

namespace App\Http\Controllers\API\V1;

use App\Helper\SendNotificationHelper;
use App\Http\Controllers\Controller;
use App\Models\Shipment;
use App\Notifications\JoiningDealEmail;
use App\Notifications\OTOWebHookEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

class OTOController extends Controller
{
    public function __construct()
    {
//        $this->middleware(['role_or_permission:Admin|Admin-Procurement']);
    }

    public function webhook(Request $request){
//        array (
//            'dcStatus' => NULL,
//            'note' => NULL,
//            'feedbackLink' => 'https://login.tryoto.com/main/OrderFeedback?enc=YTZkelhpK20vdWRPL04vKzUrNjAxUzI5bmZ1aEhXYmVNdzBDRTZ4U2FZbzJoZkpDUDBaQVNnPT0=',
//            'orderId' => 'avKkHXxpuPE8BV6oFiPE',
//            'status' => 'delivered',
//            'timestamp' => 1663769517586,
//        );

        $shipment = Shipment::shipment($request->orderId)->first();
        $buyers = $shipment->buyer->users;
        Log::info($shipment);
        Log::info($buyers);
        if ($request->status === 'delivered'){
            $shipment->order()->update([
                'status' => 4
            ]);
            $shipment->update([
               'status' => 3
            ]);
        } elseif ($request->status === 'canceled') {
            $shipment->order()->update([
                'status' => 3
            ]);
            $shipment->update([
                'status' => 0
            ]);
        } elseif ($request->status === 'assignedToWarehouse') {
            $shipment->order()->update([
                'status' => 2
            ]);
            $shipment->update([
                'status' => 2
            ]);
        }
        $title = 'Message From VYA Delivery';
        $message = 'Your Shipment from VYA is: '.$request->status;
        $action_type = 'order';
        $action_id = $shipment->order->id;
        $users = $buyers;
        Notification::send($users, new OTOWebHookEmail($title, $message, $action_id, $action_type));
        $shipment->update([
            'feedbackLink' => $request->feedbackLink
        ]);
        return 200;
    }
}
