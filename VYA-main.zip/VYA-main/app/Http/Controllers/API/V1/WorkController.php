<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\WorkStoreRequest;
use App\Models\Work;
use App\Repositories\WorkRepository;
use Illuminate\Http\Request;

class WorkController extends Controller
{
    public function __construct(WorkRepository $workRepository)
    {
        $this->middleware(['role:Admin'], ['except' => ['index', 'show']]);
        $this->workRepository = $workRepository;
    }

    /**
     * list all slides
     *
     */
    public function index($type, Request $request, Work $works){
        if($type === 'how-it-works'){
            $type = 1;
        }elseif($type === 'sell-with-us'){
            $type = 0;
        }elseif ($type === 'buy-with-us'){
            $type = 2;
        }
        return $this->workRepository->index($type, $request, $works);
    }

    /**
     * @param WorkStoreRequest $request
     *
     */
    public function store(WorkStoreRequest $request){
        return $this->workRepository->store($request);
    }

    /**
     * @param $id
     * @return \App\Http\Resources\WorkResource
     */
    public function show($id){
        return $this->workRepository->show($id);
    }


    public function update(Request $request, $id)
    {
        return $this->workRepository->update($request, $id);
    }

    public function destroy($id){
        return $this->workRepository->destroy($id);
    }
}
