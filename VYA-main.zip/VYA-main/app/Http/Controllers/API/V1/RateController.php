<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Repositories\RateRepository;
use Illuminate\Http\Request;

class RateController extends Controller
{
    public function __construct(RateRepository $rateRepository)
    {
        $this->rateRepository = $rateRepository;
        $this->middleware(['role:Buyer'], ['except' => ['index']]);
    }

    public function store(Request $request){
        return $this->rateRepository->store($request);
    }

    public function index(Product $product){
        return $this->rateRepository->productIndex($product);
    }

    public function orderIndex(Order $order){
        return $this->rateRepository->orderIndex($order);
    }
}
