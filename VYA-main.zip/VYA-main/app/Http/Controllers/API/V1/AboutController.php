<?php

namespace App\Http\Controllers\API\V1;

use App\Http\Controllers\Controller;
use App\Repositories\AboutRepository;
use Illuminate\Http\Request;

class AboutController extends Controller
{

    public function __construct(AboutRepository $aboutRepository)
    {
        $this->middleware(['role:Admin'], ['only' => ['update']]);
        $this->aboutRepository = $aboutRepository;
    }

    public function show(Request $request){
        return $this->aboutRepository->show($request);
    }

    public function update(Request $request){
        return $this->aboutRepository->update($request);
    }
}
