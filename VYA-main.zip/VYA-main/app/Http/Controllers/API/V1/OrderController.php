<?php

namespace App\Http\Controllers\API\V1;

use App\Helper\OTO;
use App\Http\Controllers\Controller;
use App\Http\Resources\BidResource;
use App\Http\Resources\DealResource;
use App\Http\Resources\OrderResource;
use App\Models\Bid;
use App\Models\CompanyProduct;
use App\Models\Deal;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    public function __construct()
    {
//        $this->middleware(['role_or_permission:Buyer|Buyer-Logistics']);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Request $request){
        $perPage = $request->get('per_page', 15);
        $orders = Order::query();
        $orders = $orders->with(['deal','deal.product']);
        $orders = $orders->where('buyer_id', auth()->user()->company->id);

        if (isset($request->order_by)){
            $orders = $orders->orderBy('created_at', $request->order_by);
        }

        if (isset($request->status)){
            $orders = $orders->whereIn('status', $request->status);
        }

        return OrderResource::collection($orders->paginate($perPage)->appends([
            'per_page' => $perPage
        ]));
    }

    /**
     * @param $id
     * @return OrderResource
     */
    public function show($id){
        $order = Order::with(['deal','shipments','buyer','sellers','deal.product'])
        ->where('id', $id)
        ->where('buyer_id', auth()->user()->company->id)
        ->firstOrFail();
        return new OrderResource($order);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function cancel(Request $request){
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $order = Order::where('id', $request->order_id)->where('buyer_id', auth()->user()->company_id)->first();
        if (!$order){
            return response()->json([
                'status' => 401,
                'message' => 'You no Permission to Edit this Order!',
            ], '401');
        }

        $order->update([
            'status' => Order::STATUS['CANCELED']
        ]);

        return response()->json([
            'status' => 200,
            'message' => 'Order Canceled',
        ], 200);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function confirm(Request $request){
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|exists:orders,id',
            'new_quantity' => 'nullable|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $order = Order::where('id', $request->order_id)->where('company_id', auth()->user()->company_id)->first();
        if (!$order){
            return response()->json([
                'status' => 401,
                'message' => 'You no Permission to Edit this Order!',
            ], '401');
        }
            if ($request->new_quantity !== null || $request->new_quantity !==''){
                $order->update([
                    'status' => Order::STATUS['CONFIRMED'],
                    'total_quantity' => $request->new_quantity
                ]);
            }else{
                $order->update([
                    'status' => Order::STATUS['CONFIRMED']
                ]);
            }


        return response()->json([
            'status' => 200,
            'message' => 'Order Confirmed',
        ], 200);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function dealsIndex(Request $request) {
        $perPage = $request->get('per_page', 15);
        $orderBy = $request->get('order_by', 'desc');

        if ($request->status == Bid::STATUS['PENDING']){
            $deals = auth()->user()->company->bids()->where('status', Bid::STATUS['PENDING']);

        } elseif ($request->status == Bid::STATUS['WON']){
            $deals = auth()->user()->company->bids()->where('status', Bid::STATUS['WON']);

        } elseif ($request->status == Bid::STATUS['NOT SELECTED']) {
            $deals = auth()->user()->company->bids()->where('status', Bid::STATUS['NOT SELECTED']);

        } else {
            $deals = Deal::with(['bids','submissions','product'])->where('status', [Deal::STATUS['WAITING']])
                ->whereHas('product', function ($query){
                    $query->whereIntegerInRaw('id', CompanyProduct::where('company_id', auth()->user()->company_id)->pluck('product_id'));
                })->whereHas('submissions')
                ->orderBy('deals.id', $orderBy)
                ->paginate($perPage)
                ->appends([
                    'per_page' => $perPage
                ]);
            return DealResource::collection($deals);
        }

        return BidResource::collection($deals->orderBy('id', $orderBy)->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    /**
     * @param $id
     * @return BidResource|DealResource
     */
    public function dealsShow($id){

        $deal = auth()->user()->company->bids()->whereHas('deal', function ($query) use ($id){
            $query->where('id', $id);
        })->first();

        if (!$deal){
            $deal = Deal::with(['bids','submissions','submissionsAddresses','product','shipments','priceList','priceList.prices'])->where('id', $id)->whereIn('status', ['2','3'])->first();
            return new DealResource($deal);
        }
        return new BidResource($deal);

    }
    /**
     * @param $id
     * @return BidResource
     */
    public function dealWithdraw($id){

        $deals = auth()->user()->company->bids()->whereHas('deal', function ($deal) use ($id){
            $deal->where('id', $id);
        });

        return new BidResource($deals->first());
    }

}
