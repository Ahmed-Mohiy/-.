<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\DealAdminResource;
use App\Http\Resources\DealResource;
use App\Models\Deal;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class DealAdminController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Request $request)
    {
        $deals = Deal::query();
        $deals = $deals->with(['product','category','submissionsAddresses','submissions','bids'])->withCount(['submissions','bids']);
        $deals = $deals->whereHas('product');

        if (isset($request->running) && $request->running == 1) {
            $deals = $deals->running();
        }

        if (isset($request->product_id)) {
            $product_id = $request->product_id;
            $deals = $deals->whereHas('product', function ($query) use ($product_id) {
                $query->whereLike(['id','products.en_name','products.ar_name'], $product_id);
            });
        }

        if (isset($request->category_id)) {
            $category_id = $request->category_id;
            $deals = $deals->whereHas('category', function ($query) use ($category_id) {
                $query->whereLike(['categories.id','categories.en_name','categories.ar_name'], $category_id);
            });
        }

        if (isset($request->date_from) && isset($request->date_to)) {
            $startDate = Carbon::parse($request->date_from);
            $endDate = Carbon::parse($request->date_to);

            $deals = $deals->where([['date_from', '>=', $startDate], ['date_to', '<=', $endDate]]);
        }

        if (isset($request->search)) {
            $search = $request->search;
            $deals = $deals->whereLike(['code', 'id', 'product_id'], $search);
        }

        $perPage = $request->get('per_page', 15);
        $deals = $deals->orderBy('date_to', 'desc')->paginate($perPage)->appends([
            'per_page' => $perPage
        ]);
        return DealAdminResource::collection($deals);
    }

    /**
     * @param Request $request
     * @return DealResource|\Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'code'          => 'required|max:255|string|unique:deals,code',
            'product_id'    => 'required|max:255|string|exists:products,id',
            'date_from'     => 'required|date|after:today',
            'date_to'       => 'required|date|after:date_from',
            'status'        => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $product = Product::where('id', $request->product_id)->whereHas('deals', function ($query) use ($request){
            return $query->whereBetween('date_from', [$request->date_from, $request->date_to])->orWhereBetween('date_to', [$request->date_from, $request->date_to]);
        })->first();
        if ($product) {
            return response()->json([
                'status' => 400,
                'error' => 'Product already have a deal in this date!',
            ], 400);
        }

        $deal = Deal::create([
            'code' => $request->code,
            'product_id' => $request->product_id,
            'date_from' => $request->date_from,
            'date_to' => $request->date_to,
            'status' => $request->status,
        ]);

        return new DealResource($deal);

    }
    public function show($id)
    {
        $deal = Deal::with(['product','category','submissionsAddresses','submissions','bids','orders','orders.shipments','orders.buyer'])->withCount(['submissions','bids','orders'])->where('id', $id)->first();
        return new DealAdminResource($deal);
    }

    public function autoMatch(Request $request, Deal $deal)
    {
        // submissions
        $buyers = $deal->submissions->sortByDesc('hits'); //Matching to Sellers’ Slaps
        $total_quantity = $buyers->sum('total_quantity'); //Total Q(t)
        $max_price = $buyers->sum('max_price'); //Total P(t)
        $total_hits = $buyers->sum('hits'); //Total Q*P (t)
        $buyers_list = ['buyers' => $buyers, "total_quantity" => $total_quantity, "total_hits" => $total_hits, "max_price" => $max_price];

        //bids
        $bids = $deal->bids;
        $sellers = [];
        $slaps = [];

        foreach ($bids as $seller) {
            $sellers[] = [
                'company_id' => $seller->company->id,
                'company' => $seller->company->name,
                'product_number' => $seller->product_number,
                'prices' => $seller->priceList->prices
            ];
            $slap = $this->getSlap($seller, $total_quantity);
                ($slap !== null) ?? array_push($slaps, $slap);
        }
        /*
         * there is 2 cases
         * 1- SoloSeller
         *      -Quantity covered by one seller
         *      -not covered : available quantity, remove big quantity with low price.
         * 2- multiSeller
         *      -
         */
        if (empty($sellers)) {
            return response()->json([
                'message' => 'There is no vendor bid on this deal',
                'code' => 404
            ], 200);
        }
        if (empty($buyers)) {
            return response()->json([
                'message' => 'There is no buyer submit on this deal',
                'code' => 404
            ], 200);
        }
        if ($request->type == 'solo') {
            return $this->soloSeller($sellers, $buyers, $total_hits);
        } else {
            return $this->multipleSeller($sellers, $buyers, $total_hits);
        }
    }

    /**
     * @param $prices
     * @param $quantity
     * @return false
     * * 1- check total quantity exists in any slap
     * 2- return the slaps that this quantity exists
     */
    private function getSlap($prices, $quantity)
    {
        foreach ($prices['prices'] as $price) {
            if ($quantity <= $price->range_to && $quantity >= $price->range_from) {
                $price->company_id = $prices['company_id'];
                $price->company_name = $prices['company'];
                $price->product_number = $prices['product_number'];
                return $price;
            }
        }
    }

    private function filterBuyers($buyers, $vendor, $total_buyers_quantity, $total_hits)
    {
        $arr = [];
        Log::info($vendor);
        $available_Quantity = $vendor->product_number;
        $seller_p = $total_buyers_quantity * $vendor->price;
        $percentage = $seller_p / $total_hits;

        foreach ($buyers as $buyer) {
            $i = $buyer->total_quantity;
            if ($i <= $available_Quantity) {
                $buyer->low_price = round($buyer->max_price - (($buyer->max_price - $vendor->price) / 2), 2);
                $buyer->total_price_quantity = round($buyer->low_price * $buyer->total_quantity, 2);
                $buyer->saving_percentage = ((($buyer->max_price - $buyer->low_price) / $buyer->max_price) * 100) . '%';
                $buyer->name = $buyer->company->name;
                $arr [] = $buyer;
                $available_Quantity = $available_Quantity - $i;
            }
        }

        return $arr;
    }

    /*
     * create fixed slaps for every seller [priceList]
     * Algorithm for multi seller should exclude all sellers that have more or equal to the required quantity
     * remove sellers that have available quantity less than the maximum in first slap
     * the best price list
     * 0-100 [[sellerA- 350], []]
     * 101-200 []
     * 201-300 []
     * 301-400 [[sellerA- 450], []] => X
     *
     */


    private function filterMultiBuyers($buyers, $vendors, $total_available_quantity, $total_buyers_quantity, $total_hits)
    {
        $arr = [];
        /*
         *  loop over buyers
         *  for every buyer quantity you should select one or more sellers to fit the quantity
         * [20000, 5000, 500, 200 ,300 ,1500], [[15000, p], [4000, p], [2000, p], [150,p]], $total_available_quantity=51000
         * [16000, 500, 200 ,300 ,1500], [13000, 4000,200,150]
         *
         * code scenario
         * best case
         * first loop on every buyer
         * select the first buyer
         * then set the new_product_quantity equal to total quantity that he needs
         * after that loop on sellers
         * check if the new_product_number is set or not
         * if not set the new product number equal to product number available at this seller
         * then check if quantity that required for the buyer is lower that the quantity available at this seller
         * then set the new value available at this seller  (seller_product_number - Buyer_required_quantity)
         * and set the Buyer_required_quantity for this buyer to 0
         *
         *else
         * this is means that the required quantity by buyer is not available at this seller so
         * we will set the new required quantity for this buyer (Buyer_required_quantity - seller_product_number)
         * and set the seller_product_number for this buyer to 0
         *
         * then we will to loop over all sellers & buyers to full fill the total required quantity
         * ******************************************************************************************
         * the total required quantity is lower than the offered quantity from sellers
         *
         *
         */
        $i = 0;
        $result = new Collection();
        foreach ($buyers as $buyer) { //n
            if ($buyer->total_quantity <= $total_available_quantity) { //log(n)
                if (!isset($buyer->new_buyer_quantity)) {
                    $buyer->new_buyer_quantity = $buyer->total_quantity; // 15000 // 20000
                }
                $price = 0;
                $child = [];//1400
                $taken = [];//1400
                $steps = [];
                foreach ($vendors as $k => $sellers) { //n
                    list($from, $to) = explode(',', $k);

                    if ($buyer->new_buyer_quantity >= $from && $buyer->new_buyer_quantity <= $to) {
                        //return $total_available_quantity;
                        $new_buyer_quantity = [];
                        foreach ($sellers as $seller) {
                            if (!isset($seller['new_product_number'])) {
                                $seller['new_product_number'] = $seller['product_number']; // 30000 /// 5000
                            }
                            if ($buyer->new_buyer_quantity > 0 && $seller['new_product_number'] > 0) {
                                if ($buyer->new_buyer_quantity <= $seller['new_product_number']) {
                                    $remaining_quantity = $seller['new_product_number'] - $buyer->new_buyer_quantity; //15000
                                    $steps[$seller->company_name] = $buyer->new_buyer_quantity;
                                    array_push($child, $seller);
                                    //array_push($taken, $steps);
                                    $buyer->vendor = $child;
                                    $buyer->taken = $steps;
                                    $price += $buyer->new_buyer_quantity * $seller['price'];
                                    $buyer->new_buyer_quantity = 0;
                                    $seller['new_product_number'] = $remaining_quantity;
                                } else {
                                    $new_buyer_quantity = ($buyer->new_buyer_quantity - $seller['new_product_number']); //5000
                                    $buyer->new_buyer_quantity = $new_buyer_quantity;
                                    $steps[$seller->company_name] = $seller['new_product_number'];
                                    array_push($child, $seller);
                                    //array_push($taken, $steps);
                                    $buyer->vendor = $child;
                                    $buyer->taken = $steps;
                                    $price += $seller['new_product_number'] * $seller['price'];
                                    $seller['new_product_number'] = 0;
                                }

                            }

                        }
                        $buyer->name = $buyer->company->name;
                        //$arr[$buyer->company_id]['steps'] = $steps;
                        $arr[$i]['total_price'] = $price;
                        $arr[$i]['required_price'] = $buyer->max_price * $buyer->total_quantity;
                        $arr[$i]['low_price'] = round($buyer->max_price - (($buyer->max_price - ($price / $buyer->total_quantity)) / 2), 2);
                        $arr[$i]['total_price_quantity'] = $arr[$i]['low_price'] * $buyer->total_quantity;
                        $arr[$i]['saving_percentage'] = ((($buyer->max_price - $arr[$i]['low_price']) / $buyer->max_price) * 100) . '%';
                        $arr[$i]['info'] = $buyer;
                        $i++;
                    }
                }

                $total_available_quantity = $total_available_quantity - $buyer->total_quantity;
                $buyer->total_available_quantity = $total_available_quantity;
            }

        }
        return $arr;
    }



//    private function filterMultiBuyersOld($buyers, $vendors, $total_available_quantity, $total_buyers_quantity, $total_hits){
//        $arr= [];
////        $seller_p = 0;
//
////        $percentage =  $seller_p / $total_hits;
//        /*
//         *  loop over buyers
//         *  for every buyer quantity you should select one or more sellers to fit the quantity
//         * [20000, 5000, 500, 200 ,300 ,1500], [[15000, p], [4000, p], [2000, p], [150,p]], $total_available_quantity=51000
//         * [16000, 500, 200 ,300 ,1500], [13000, 4000,200,150]
//         *
//         * code scenario
//         * best case
//         * first loop on every buyer
//         * select the first buyer
//         * then set the new_product_quantity equal to total quantity that he needs
//         * after that loop on sellers
//         * check if the new_product_number is set or not
//         * if not set the new product number equal to product number available at this seller
//         * then check if quantity that required for the buyer is lower that the quantity available at this seller
//         * then set the new value available at this seller  (seller_product_number - Buyer_required_quantity)
//         * and set the Buyer_required_quantity for this buyer to 0
//         *
//         *else
//         * this is means that the required quantity by buyer is not available at this seller so
//         * we will set the new required quantity for this buyer (Buyer_required_quantity - seller_product_number)
//         * and set the seller_product_number for this buyer to 0
//         *
//         * then we will to loop over all sellers & buyers to full fill the total required quantity
//         * ******************************************************************************************
//         * the total required quantity is lower than the offered quantity from sellers
//         *
//         *
//         */
//
//        $local_s = $vendors;
//        $local_b = $buyers;
//        $t = $total_available_quantity;// 51000
//        $i = 0;
//            foreach ($local_b as $buyer){ //n
//                if($buyer->total_quantity <= $t){ //log(n)
//                    if(!isset($buyer->new_buyer_quantity)){
//                        $buyer->new_buyer_quantity = $buyer->total_quantity; // 15000 // 20000
//                    }
//                    $price = 0;
//                    $child = [];
//                   foreach ($local_s as $k => $vendor) { //n
//                        if(!isset($vendor['new_product_number'])){
//                            $vendor['new_product_number'] = $vendor['product_number']; // 30000 /// 5000
//                        }
//                       if ($buyer->new_buyer_quantity > 0 && $vendor['new_product_number'] > 0) {
//                           //$buyer_quantity = $buyer->new_buyer_quantity; //15000 // 20000
//                               /*
//                                * $buyer->low_price = round($buyer->max_price - (($buyer->max_price - $vendor['prices']->sum('price'))/2),2);
//                               $buyer->total_price_quantity = round($buyer->low_price * $buyer->total_quantity, 2);
//                               $buyer->saving_percentage = ((($buyer->max_price-$buyer->low_price) / $buyer->max_price) * 100).'%';
//                               */
//
//                               if ($buyer->new_buyer_quantity <= $vendor['new_product_number']) {
////                                   if($i == 1){
////                                       return 'x';
////                                   }
//                                   $vendor['new_product_number'] = $vendor['new_product_number'] - $buyer->new_buyer_quantity; //15000
//                                   array_push($child, $vendor);
//                                   $buyer->vendor = $child;
//                                   $price += $buyer->new_buyer_quantity * $vendor['price'];
//                                   $buyer->new_buyer_quantity = 0;
//                               }else{
//                                   $buyer->new_buyer_quantity = $buyer->new_buyer_quantity - $vendor['new_product_number']; //5000
//                                   array_push($child, $vendor);
//                                   $buyer->vendor = $child;
//                                   $price += $vendor['new_product_number'] * $vendor['price'];
//                                   $vendor['new_product_number'] = 0;
//                               }
//                           $arr[$buyer->company_id]['total_price']      = $price;
//                           $arr[$buyer->company_id]['required_price']   = $buyer->max_price * $buyer->total_quantity;
//                           $arr[$buyer->company_id]['low_price']        = round($buyer->max_price - (($buyer->max_price - ($price /  $buyer->total_quantity))/2),2);
//                           $arr[$buyer->company_id]['total_price_quantity']   = $arr[$buyer->company_id]['low_price'] * $buyer->total_quantity;
//                           $arr[$buyer->company_id]['saving_percentage']      = ((($buyer->max_price-$arr[$buyer->company_id]['low_price']) / $buyer->max_price) * 100).'%';
//                           $arr[$buyer->company_id][$vendor->company_name] = $buyer;
//                       }
//
//                   }
//                                   if($i == 1){
//                                       return $arr;
//                                   }
//                    //return $vendors;
//                    $t = $t - $buyer->total_quantity;
//                    $buyer->total_available_quantity = $t;
//            }
////            $seller_p =+ $total_buyers_quantity * $vendor['prices']->sum('price');
//                $i++;
//        }
//
//
//        return $arr;
//    }

    /**
     * @param $sellers
     * @param $buyers
     * @return array|\Illuminate\Http\JsonResponse
     */
    private function soloSeller($sellers, $buyers, $total_hits)
    {
        $list = [];
        $price_lists = [];
        $slaps = [];
        $total_buyers_quantity = $buyers->sum('total_quantity');
        foreach ($sellers as $seller) {
            if ($total_buyers_quantity <= $seller['product_number']) {
                array_push($list, $seller);
                foreach ($seller['prices'] as $price) {
                    if ($total_buyers_quantity <= $price->range_to && $total_buyers_quantity > $price->range_from) {
                        $price['company_name'] = $seller['company'];
                        $price['company_id'] = $seller['company_id'];
                        $price['product_number'] = $seller['product_number'];
                        array_push($slaps, $price);
                    }
                }

            }
            array_push($price_lists, $this->getSlap($seller, $seller['product_number']));
        }
        $price_lists = array_filter($price_lists, function ($v) {
            return !is_null($v) && $v !== '';
        });
        /*
            $itemsQty = array_column($price_lists, 'product_number');
            $itemsPrice = array_column($price_lists, 'price');
            array_multisort($itemsQty, SORT_ASC, $price_lists);
            array_multisort($itemsQty, SORT_DESC, $itemsPrice, SORT_ASC, $price_lists);
            $total_available_quantity =  array_sum($itemsQty);
        */
        if (empty($list)) {
            //return 'not covered by one seller';
            $vendor = collect($price_lists)->sortBy('price')->first();
            Log::error($vendor);
            $buyers = $this->filterBuyers($buyers->values(), $vendor, $total_buyers_quantity, $total_hits);
            $data = [
                'sellers' => [$vendor],
                'buyers' => $buyers
            ];

            $message = 'Solo Seller Max Quantity';

        } elseif (count($list) > 1) {
            //multiple Sellers
            $price = array_column($slaps, 'price');
            array_multisort($price, SORT_ASC, $slaps);
            $vendor = $slaps[0];
            $buyers = $this->filterBuyers($buyers->values(), $vendor, $total_buyers_quantity, $total_hits);
            $data = [
                'sellers' => [$vendor],
                'buyers' => $buyers
            ];
            $message = 'Solo Seller Covered by Best Price';
        } else {
            //One Seller Covered
            $vendor = collect($list[0]['prices'])
                ->where('range_to', '>=', $total_buyers_quantity)
                ->where('range_from', '<', $total_buyers_quantity)->first();
            $buyers = $this->filterBuyers($buyers->values(), $vendor, $total_buyers_quantity, $total_hits);
            $data = [
                'sellers' => [$vendor],
                'buyers' => $buyers
            ];
            $message = 'Solo Seller Covered';
        }

        return response()->json([
            'message' => $message,
            'data' => $data
        ], 200);
    }

    /**
     * @param $sellers
     * @param $buyers
     * @param $total_hits
     * @return array
     *
     * create fixed slaps for every seller [priceList]
     * Algorithm for multi seller should exclude all sellers that have more or equal to the required quantity
     * remove sellers that have available quantity less than the maximum in first slap
     * the best price list
     * 0-100 [[sellerA- 350], []]
     * 101-200 []
     * 201-300 []
     * 301-400 [[sellerA- 450], []] => X
     * seller [0][1]...[9]
     * slap[0][[sellerA, 10], [9]]
     *
     */

    private function multipleSeller($sellers, $buyers, $total_hits)
    {
        $list = [];
        $vendors = [];
//        $price_lists = [];
        $slaps = [];
        $total_buyers_quantity = $buyers->sum('total_quantity'); // 58212
        foreach ($sellers as $seller) {
            if ($seller['product_number'] < $total_buyers_quantity && $seller['product_number'] > $seller['prices'][0]->range_to) {
                array_push($list, $seller);
                $i = 0;
                foreach ($seller['prices'] as $price) {
                    if ($seller['product_number'] >= $price->range_to) {
                        $price['company_name'] = $seller['company'];
                        $price['company_id'] = $seller['company_id'];
                        $price['product_number'] = $seller['product_number'];
                        $slaps['' . $seller['prices'][$i]->range_from . ',' . $seller['prices'][$i]->range_to . ''][] = $price;
                        $i++;
                    }
                }
            }
        }
//        $price_lists = array_filter($price_lists, function ($v) {
//            return !is_null($v) && $v !== '';
//        });
        $total_available_quantity = 0;
        foreach ($slaps as $k => $slap) {
            $itemsQty = array_column($slap, 'product_number');
            $itemsPrice = array_column($slap, 'price');
            //array_multisort($itemsQty, SORT_ASC, $price_lists);
            array_multisort($itemsPrice, SORT_ASC, $itemsQty, SORT_DESC, $slap);
            $vendors[$k] = $slap;
        }
        $total_available_quantity = $buyers->sum('total_quantity'); //8250
//        $buyers = []; 4803
        if ($total_available_quantity <= $total_buyers_quantity) {
            return $this->filterMultiBuyers($buyers->values(), $vendors, $total_available_quantity, $total_buyers_quantity, $total_hits);
        } else {
            return $this->filterMultiBuyers($buyers->values(), $vendors, $total_available_quantity, $total_buyers_quantity, $total_hits);
        }
        return $buyers;

    }

    private function multipleSellerOld($sellers, $buyers, $total_hits)
    {
        $list = [];
        $price_lists = [];
        $slaps = [];
        $total_buyers_quantity = $buyers->sum('total_quantity'); // 58212
        foreach ($sellers as $seller) {
            if ($total_buyers_quantity <= $seller['product_number']) {
                array_push($list, $seller);
                foreach ($seller['prices'] as $price) {
                    if ($total_buyers_quantity <= $price->range_to && $total_buyers_quantity > $price->range_from) {
                        $price['company_name'] = $seller['company'];
                        $price['company_id'] = $seller['company_id'];
                        $price['product_number'] = $seller['product_number'];
                        array_push($slaps, $price);
                    }
                }
            }
            array_push($price_lists, $this->getSlap($seller, $seller['product_number']));
        }
        $price_lists = array_filter($price_lists, function ($v) {
            return !is_null($v) && $v !== '';
        });
        $itemsQty = array_column($price_lists, 'product_number');
        $itemsPrice = array_column($price_lists, 'price');
        //array_multisort($itemsQty, SORT_ASC, $price_lists);
        array_multisort($itemsPrice, SORT_ASC, $itemsQty, SORT_DESC, $price_lists);
        $total_available_quantity = array_sum($itemsQty); //51137
//        $buyers = [];
        if ($total_available_quantity <= $total_buyers_quantity) {
            return $this->filterMultiBuyers($buyers->values(), $price_lists, $total_available_quantity, $total_buyers_quantity, $total_hits);
        } else {

        }
        return $buyers;

    }
}
