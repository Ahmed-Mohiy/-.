<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\CompanyRequest;
use App\Models\User;
use Illuminate\Http\Request;

class UserHomeController extends Controller
{
    public function index(){
        $total_users = User::count();
        $total_requests = CompanyRequest::count();
        $total_buyers = User::role(['Buyer','Buyer-logistics','Buyer-Finance'])->count();
        $total_sellers = User::role(['Seller','Seller-Finance','Seller-Logistics'])->count();

        return response()->json([
            'status' => 200,
            'data' => [
                'total_users' => $total_users,
                'total_requests' => $total_requests,
                'total_buyers' => $total_buyers,
                'total_sellers' => $total_sellers,
            ]
        ]);
    }
}
