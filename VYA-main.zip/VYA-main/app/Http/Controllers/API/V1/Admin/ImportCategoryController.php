<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use App\Imports\CategoryImport;
use Illuminate\Http\Request;
use Excel;

class ImportCategoryController extends Controller
{
    public function import(Request $request)
    {
        Excel::import(new CategoryImport(), $request->file);

        return response()->json([
            'status' => 201,
            'message' => 'All good!'
        ]);
    }
}
