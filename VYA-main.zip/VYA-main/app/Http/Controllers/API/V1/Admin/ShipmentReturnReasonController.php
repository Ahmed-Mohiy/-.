<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ShipmentReturnReasonController extends Controller
{
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request){
        $reasons = \App\Models\ShipmentReturnReason::all();
        $data = [];
        foreach ($reasons as $reason){
            $data[] = [
                'id' => $reason->id,
                'title' => $request->lang == 'ar' ? $reason->ar_title : $reason->en_title
            ];
        }
        return response()->json([
            'status' => 200,
            'data' => $data
        ]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'en_title'   => 'required|max:255|string|unique:shipment_return_reasons,en_title',
            'ar_title'   => 'required|max:255|string|unique:shipment_return_reasons,ar_title',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        \App\Models\ShipmentReturnReason::create([
            "en_title" => $request->en_title,
            "ar_title" => $request->ar_title
        ]);

        return response()->json([
            'status' => 201,
            'message' => 'Reason is Created Successfully',
        ], '201');
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id){
        $validator = Validator::make($request->all(), [
            'en_title'   => 'required|max:255|string|unique:shipment_return_reasons,en_title' . ($id ? ",$id" : ''),
            'ar_title'   => 'required|max:255|string|unique:shipment_return_reasons,ar_title' . ($id ? ",$id" : ''),
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        \App\Models\ShipmentReturnReason::find($id)->update([
            "en_title" => $request->en_title,
            "ar_title" => $request->ar_title
        ]);

        return response()->json([
            'status' => 201,
            'message' => 'Reason is Updated Successfully',
        ], '201');
    }

    /**
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id){
        \App\Models\ShipmentReturnReason::find($id)->delete();

        return response()->json([
            'status' => 201,
            'message' => 'Reason is Deleted Successfully',
        ], '201');
    }
}
