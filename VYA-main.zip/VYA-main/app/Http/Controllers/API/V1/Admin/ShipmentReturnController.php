<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Helper\OTO;
use App\Helper\SendNotificationHelper;
use App\Http\Controllers\Controller;
use App\Http\Resources\ShipmentReturnResource;
use App\Models\Shipment;
use App\Models\ShipmentReturn;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ShipmentReturnController extends Controller
{
    public function index(Request $request)
    {
        $perPage = $request->get('per_page', 20);

        $returns = ShipmentReturn::query();

        if (isset($request->order_number)){
            $number = $request->order_number;
            $returns = $returns->whereHas('order', function ($query) use ($number){
                $query->where('id', $number);
            });
        }

        if (isset($request->company_name)){
            $name = $request->company_name;
            $returns = $returns->whereHas('buyer', function ($query) use ($name){
                $query->where('name', $name);
            });
        }
        if (isset($request->created_at)){
            $returns = $returns->whereDate('created_at', $request->created_at);
        }
        if (isset($request->price)){
            $returns = $returns->where('shipment_return_price', $request->price);
        }

        $returns = $returns->with(['buyer','seller','shipment','reason']);

        if (auth()->user()->hasRole(['Seller'])) {
            $returns = $returns->where('seller_id', auth()->user()->company_id);
        }
        if (auth()->user()->hasRole(['Buyer'])) {
            $returns = $returns->where('buyer_id', auth()->user()->company_id);
        }

        return ShipmentReturnResource::collection($returns->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'shipment_id' => 'required|max:255|string|exists:shipments,id|unique:shipment_returns',
            'shipment_return_reason_id' => 'required|max:255|string|exists:shipment_return_reasons,id',
        ]);
        $shipment = Shipment::find($request->shipment_id);
        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        ShipmentReturn::create([
            'shipment_id' => $shipment->id,
            'buyer_id' => $shipment->buyer_id,
            'order_id' => $shipment->order_id,
            'seller_id' => $shipment->vendor_id,
            'shipment_return_price' => $shipment->shipment_price,
            'shipment_return_reason_id' => $request->shipment_return_reason_id,
        ]);
        $name = 'Message From VYA Delivery';
        $action_type = 'order';
        $action_id = $shipment->order->id;
        $message = 'Your Shipment from VYA is Waiting Admin Confirmed ';
        $users = User::role('Admin')->get();
        $click_action = 'RESULT';
        SendNotificationHelper::notify($users, $message, $name, $click_action, $action_type, $action_id);
        return response()->json([
            'status' => 201,
            'message' => 'Return request is created successfully',
        ], '201');
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'shipment_return_reason_id' => 'required|max:255|string|exists:shipment_return_reasons,id',
        ]);
        $shipment_return = ShipmentReturn::find($id);
        if (!isset($shipment_return)) {

            return response()->json([
                'status' => 404,
                'message' => 'request does not exist',
            ], '404');
        }
        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        ShipmentReturn::find($id)->update([
            'shipment_return_reason_id' => $request->shipment_return_reason_id,
        ]);
        return response()->json([
            'status' => 201,
            'message' => 'Return reason is updated successfully',
        ], '201');
    }

    public function status(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|integer|between:0,5',
            'shipment_return_id' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $shipment_return = ShipmentReturn::find($request->shipment_return_id);

        if (!isset($shipment_return)) {
            return response()->json([
                'status' => 404,
                'message' => 'shipment return does not exist',
            ], '404');
        }

        $shipment_return->update([
            'status' => $request->status
        ]);

        if ($request->status == 1 || $request->status == 5) {
            $message = $request->status == 1 ? 'Your Shipment return from VYA is waiting seller confirmed' : 'Your Shipment return from VYA canceled';
            $users = $shipment_return->buyer->users;
        } elseif ($request->status == 2) {
            OTO::createReturnShipment($shipment_return->shipment->oto_order_id);
            $message = 'Your Shipment from VYA is waiting shipment ';
            $users = $shipment_return->buyer->users;
        }

        $name = 'Message From VYA Delivery';
        $action_type = 'order';
        $action_id = $shipment_return->order->id ?? null;
        $click_action = 'RESULT';
        SendNotificationHelper::notify($users, $message, $name, $click_action, $action_type, $action_id);


            return response()->json([
                'status' => 201,
                'message' => 'Return request status is updated successfully',
            ], '201');
    }

    public function destroy($id)
    {
        $shipment_return = ShipmentReturn::find($id);
        if (!isset($shipment_return)) {

            return response()->json([
                'status' => 404,
                'message' => 'Return request does not exist',
            ], '404');
        }
        $shipment_return->delete();
        return response()->json(['message' => 'Return request deleted successfully'], 200);
    }
}
