<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\HolidayResource;
use App\Models\Holiday;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class HolidayController extends Controller
{
    public function index(Request $request){
        $holidays = new Holiday();
        $perPage = $request->get('per_page', 15);

        return HolidayResource::collection($holidays->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }
    public function show($id){
        return new HolidayResource(Holiday::find($id));
    }
    public function store(Request $request){
        $validator = Validator::make($request->all(), [
            'date' => ['required'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $holiday = Holiday::create($request->all());
        return HolidayResource::make($holiday);
    }
    public function update(Request $request, $id){
        $validator = Validator::make($request->all(), [
            'date' => ['required','date'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $holiday = Holiday::find($id)->update($request->all());
        return response()->json([
            'status' => 200,
            'message' => 'Date Updated'
        ]);
    }
    public function destroy(Holiday $holiday){

        $holiday->delete();
        return response()->json([
            'status' => 200,
            'message' => 'Date Deleted'
        ]);
    }
}
