<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Models\Bid;
use App\Models\Company;
use App\Models\Currency;
use App\Models\Deal;
use App\Models\Order;
use App\Models\OrderSeller;
use App\Models\Shipment;
use App\Models\SubmissionAddress;
use App\Rules\BuyerinThisDealRule;
use Illuminate\Support\Facades\DB;
use App\Rules\IsBuyerRule;
use App\Rules\IsClosedDealRule;
use App\Rules\IsSellerRule;
use App\Rules\SellerinThisDealRule;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Helper\OTO;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware(['role_or_permission:Admin']);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function index(Request $request)
    {
        $perPage = $request->get('per_page', 15);

        $orders = Order::query();
        $orders = $orders->with(['deal','deal.product', 'buyer']);

        if (isset($request->deal_id)) {
            $orders = $orders->where('deal_id', $request->deal_id);
        }

        return OrderResource::collection($orders->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );
    }

    /**
     * @param $id
     * @return OrderResource|\Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $order = Order::with(['deal','shipments','buyer','sellers','deal.product'])->where('id', $id)->first();

        if (!$order) {
            return response()->json([
                'status' => 404,
                'message' => 'Order not found',
            ], '404');
        }

        return new OrderResource($order);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        // TODO if seller and buyer in this deal: Done
        $validator = Validator::make($request->all(), [
            'deal_id' => ['required', 'exists:deals,id', new IsClosedDealRule()],
            'buyer_id' => ['required', 'exists:companies,id', new IsBuyerRule(), new BuyerinThisDealRule($request->deal_id)],
            'offer' => 'required|numeric',
            'quantity' => 'required|numeric',
            'sellers.*' => ['required', 'array'],
            'sellers.*.seller_id' => ['required', 'exists:companies,id', new IsSellerRule(), new SellerinThisDealRule($request->deal_id)],
            'sellers.*.quantity' => ['required', 'numeric'],
            'sellers.*.price_per_unit' => ['required', 'numeric'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        try {
            DB::transaction(function ($message) use ($request) {
                $buyer = Company::find($request->buyer_id);

                $total_quantity = $request->quantity;

                if (isset($request->offer)) {
                    $total_price = $total_quantity * $request->offer;
                } else {
                    $total_price = $total_quantity * $buyer->submission($request->deal_id)->first()->max_price;
                }

                $total_price = round($total_price, 2);

                if ($buyer->balance < $total_price) {
                    $status = Order::STATUS['WAITING_PRICE'];
//            return response()->json([
//                'status' => 400,
//                'message' => 'The company\'s balance is less than the required amount'
//            ], 400);
                } else {
                    $status = Order::STATUS['CONFIRMED'];
                }

                $deal = Deal::find($request->deal_id);

                $order = Order::updateOrCreate(
                    [
                        'deal_id' => $deal->id,
                        'buyer_id' => $buyer->id,
                    ],
                    [
                        'deal_id' => $deal->id,
                        'buyer_id' => $buyer->id,
                        'status' => $status,
                        'offer' => $request->offer,
                        'total_quantity' => $total_quantity,
                        'total_price' => $total_price,
                        'currency_id' => Currency::NAME['SR'],
                    ]
                );
                foreach ($request->sellers as $seller) {
                    OrderSeller::updateOrCreate(
                        [
                            'order_id' => $order->id,
                            'seller_id' => $seller['seller_id'],
                            'quantity' => $seller['quantity'],
                        ],
                        [
                            'order_id' => $order->id,
                            'seller_id' => $seller['seller_id'],
                            'price_per_unit' => $seller['price_per_unit'],
                            'currency_id' => Currency::NAME['SR'],
                            'quantity' => $seller['quantity'],
                        ]
                    );
                    //TODO Add New Seller Q. and withdrawal $seller->quantity :Done

                    $bid = Bid::where('company_id', $seller['seller_id'])->where('deal_id', $deal->id)->first();

                    if ($bid->new_product_number >= $seller['quantity']) {
                        $bid->update([
                            'new_product_number' => $bid->new_product_number - $seller['quantity'],
                            'status' => Bid::STATUS['WON']
                        ]);
                    } else {
                        throw ValidationException::withMessages([
                            'error' => 'Seller Have not enough Product Quantity'
                        ]);
                    }

                    $price = $total_price - ($submission->deposit_amount ?? 0);
                    if ($buyer->balance >= $price) {
                        $addresses = $buyer->submissionAddress($request->deal_id)->get();

                        $seller = Company::find($seller['seller_id']);

                        foreach ($addresses as $address) {

                            if ($deal->product->shipment_type == Shipment::TYPE['OTO']) {

                                //TODO Get width and other data from where?
                                $itemDetails = [
                                    'weight' => 1,
                                    'totalDue' => $total_quantity,
                                    'originCity' => $seller->address->country->en_name,
                                    'destinationCity' => $address->address->country->en_name,
                                    "height" => 170,
                                    "width" => 50,
                                    "length" => 50
                                ];
                                $deliveryOrderOTOFee = OTO::checkOTODeliveryFee($itemDetails);

                                $deliveryOrderOTOFee = json_decode($deliveryOrderOTOFee, true);
                                if ($deliveryOrderOTOFee['success']) {
                                    $deliveryOptionId = $deliveryOrderOTOFee['deliveryCompany'][0]['deliveryOptionId'];
                                    $deliveryOptionPrice = $deliveryOrderOTOFee['deliveryCompany'][0]['price'];
                                }

                                $randomOrderId = Str::random(20);
                                $orderData = [
                                    'orderId' => $randomOrderId,
                                    'parentOrderId' => $order->id,
                                    'payment_method' => 'paid',
                                    'pickupLocationCode' => $address->address->oto_code ?? null,
                                    'createShipment' => !($address->address->oto_code == null),
                                    'deliveryOptionId' => $deliveryOptionId,
                                    'amount' => '0',
                                    'amount_due' => 0,
                                    'packageCount' => $address->quantity,
                                    'packageWeight' => $request->weight,
                                    'orderDate' => Carbon::now()->format('d/m/Y H:m')
                                ];
                                $customeData = [
                                    'name' => $address->name,
                                    'email' => $buyer->email,
                                    'mobile' => $address->mobile
                                ];
                                $addressData = [
                                    'address' => $address->address->building_number . ', ' . ', ' . $address->address->unit_number . ', ' . $address->address->street_name,
                                    'district' => $address->address->country->en_name,
                                    'city' => $address->address->country->en_name,
                                    'country' => 'SA',
                                    'lat' => $address->address->lat,
                                    'lng' => $address->address->lng
                                ];
                                $items = [
                                    [
                                        "productId" => $deal->product->id,
                                        "name" => $deal->product->en_name,
                                        "price" => '',
                                        "rowTotal" => '',
                                        "taxAmount" => '',
                                        "quantity" => '',
                                        "sku" => $deal->product->sku,
                                        "image" => ''
                                    ]
                                ];
                                $oto_create_response = OTO::createOrder($orderData, $customeData, $addressData, $items);
                                $oto_response = json_decode($oto_create_response);
                                $shipment_number = $oto_response->success == true ? $oto_response->otoId : null;
                                Log::warning($oto_create_response);
                            } else {
                                $shipment_number = 'SELLER-shipment-' . Str::random(6);
                            }

                            $orderStatus = OTO::orderStatus($randomOrderId);
                            $orderStatus = json_decode($orderStatus, true);

                            if ($orderStatus['success']) {
                                $printAWBURL = $orderStatus['printAWBURL'] ?? null;
                            }

                            $orderHistory = OTO::orderHistory($randomOrderId);
                            $orderHistory = json_decode($orderHistory, true);
                            if ($orderHistory['success']) {
                                $trackingURL = $orderHistory['items'][0]['trackingURL'] ?? null;
                            }

                            Shipment::create([
                                'order_id' => $order->id,
                                'buyer_id' => $buyer->id,
                                'vendor_id' => $seller->id,
                                'deal_id' => $request->deal_id,
                                'status' => Shipment::STATUS['WAITING_SHIPMENT'],
                                'oto_order_id' => $randomOrderId,
                                'shipment_number' => $shipment_number,
                                'seller_address_id' => $seller->address->id,
                                'buyer_address_id' => $address->address->id,
                                'quantity' => $address->quantity,
                                'shipment_price' => $deliveryOptionPrice, // TODO delivery option get price: Done
                                'printAWBURL' => $printAWBURL ?? null,
                                'trackingURL' => $trackingURL ?? null,
                            ]);

                        }

                        $buyer->forceWithdraw($price, ['description' => 'Balance deduction for purchase on order No.: ' . $order->id]);
                    }

                }
            });

        } catch (\Throwable $exception) {
            report($exception);
            return response()->json([
                'status' => 400,
                'error' => $exception->getMessage()
            ], 400);
        }
        return response()->json([
            'status' => 201,
            'message' => 'Order Created Successfully!',
        ], 201);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|void
     */
    public function shipment(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'order_id' => ['required', 'exists:orders,id'],
            'address_id' => ['required', 'exists:addresses,id'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }
        $order = Order::find($request->order_id);

//        $deal = $order->deal;

//        $buyer = $order->buyer;
        try {
            DB::transaction(function ($message) use ($order,$request) {
                foreach ($order->sellers as $seller) {
                    //TODO Add New Seller Q. and withdrawal $seller->quantity :Done

                    $bid = Bid::where('company_id', $seller->seller_id)->where('deal_id', $order->deal_id)->first();

                    if ($bid->new_product_number >= $seller['quantity']) {
                        $bid->update([
                            'new_product_number' => $bid->new_product_number - $seller['quantity'],
                            'status' => Bid::STATUS['WON']
                        ]);
                    } else {
                        throw ValidationException::withMessages([
                            'error' => 'Seller Have not enough Product Quantity'
                        ]);
                    }

                    $price = $order->total_price;
                    if ($order->buyer->balance >= $price) {
                        $addresses = $order->buyer->submissionAddress($order->deal_id)->get();

                        foreach ($addresses as $address) {

                            if ($order->deal->product->shipment_type == Shipment::TYPE['OTO']) {

                                //TODO Get width and other data from where?
                                $itemDetails = [
                                    'weight' => 1,
                                    'totalDue' => $order->total_quantity,
                                    'originCity' => $seller->address->country->en_name,
                                    'destinationCity' => $address->address->country->en_name,
                                    "height" => 170,
                                    "width" => 50,
                                    "length" => 50
                                ];
                                $deliveryOrderOTOFee = OTO::checkOTODeliveryFee($itemDetails);

                                $deliveryOrderOTOFee = json_decode($deliveryOrderOTOFee, true);
                                if ($deliveryOrderOTOFee['success']) {
                                    $deliveryOptionId = $deliveryOrderOTOFee['deliveryCompany'][0]['deliveryOptionId'];
                                    $deliveryOptionPrice = $deliveryOrderOTOFee['deliveryCompany'][0]['price'];
                                }

                                $randomOrderId = Str::random(20);
                                $orderData = [
                                    'orderId' => $randomOrderId,
                                    'parentOrderId' => $order->id,
                                    'payment_method' => 'paid',
                                    'pickupLocationCode' => $address->address->oto_code ?? null,
                                    'createShipment' => !($address->address->oto_code == null),
                                    'deliveryOptionId' => $deliveryOptionId,
                                    'amount' => '0',
                                    'amount_due' => 0,
                                    'packageCount' => $address->quantity,
                                    'packageWeight' => $request->weight ?? 50,
                                    'orderDate' => Carbon::now()->format('d/m/Y H:m')
                                ];
                                $customeData = [
                                    'name' => $address->address->name,
                                    'email' => $address->address->email,
                                    'mobile' => $address->address->mobile
                                ];
                                $addressData = [
                                    'address' => $address->address->building_number . ', ' . ', ' . $address->address->unit_number . ', ' . $address->address->street_name,
                                    'district' => $address->address->country->en_name,
                                    'city' => $address->address->country->en_name,
                                    'country' => 'SA',
                                    'lat' => $address->address->lat,
                                    'lng' => $address->address->lng
                                ];
                                $items = [
                                    [
                                        "productId" => $order->deal->product->id,
                                        "name" => $order->deal->product->en_name,
                                        "price" => '',
                                        "rowTotal" => '',
                                        "taxAmount" => '',
                                        "quantity" => '',
                                        "sku" => $order->deal->product->sku,
                                        "image" => ''
                                    ]
                                ];
                                $oto_create_response = OTO::createOrder($orderData, $customeData, $addressData, $items);
                                $oto_response = json_decode($oto_create_response);
                                $shipment_number = $oto_response->success == true ? $oto_response->otoId : null;
                                Log::warning($oto_create_response);
                            } else {
                                $shipment_number = 'SELLER-shipment-' . Str::random(6);
                            }

                            $orderStatus = OTO::orderStatus($randomOrderId);
                            $orderStatus = json_decode($orderStatus, true);

                            if ($orderStatus['success']) {
                                $printAWBURL = $orderStatus['printAWBURL'] ?? null;
                            }

                            $orderHistory = OTO::orderHistory($randomOrderId);
                            $orderHistory = json_decode($orderHistory, true);
                            if ($orderHistory['success']) {
                                $trackingURL = $orderHistory['items'][0]['trackingURL'] ?? null;
                            }

                            Shipment::create([
                                'order_id' => $order->id,
                                'buyer_id' => $order->buyer_id,
                                'vendor_id' => $order->seller_id,
                                'deal_id' => $order->deal_id,
                                'status' => Shipment::STATUS['WAITING_SHIPMENT'],
                                'oto_order_id' => $randomOrderId,
                                'shipment_number' => $shipment_number,
                                'seller_address_id' => $seller->address->id,
                                'buyer_address_id' => $address->address->id,
                                'quantity' => $address->quantity,
                                'shipment_price' => $deliveryOptionPrice, // TODO delivery option get price: Done
                                'printAWBURL' => $printAWBURL ?? null,
                                'trackingURL' => $trackingURL ?? null,
                            ]);

                        }

                        $order->buyer->forceWithdraw($price, ['description' => 'Balance deduction for purchase on order No.: ' . $order->id]);
                    }

                }
            });
        } catch (\Throwable $exception) {
            report($exception);
            return response()->json([
                'status' => 400,
                'error' => $exception->getMessage()
            ], 400);
        }

        return response()->json([
            'status' => 201,
            'message' => 'Shipment Created Successfully!',
        ], 201);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function checkDeliveryFee(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'weight' => ['required'],
            'length' => ['required'],
            'height' => ['required'],
            'quantity' => ['required', 'numeric'],
            'city_from' => 'required|string',
            'city_to' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 400,
                'error' => $validator->messages(),
            ], '400');
        }

        $itemDetails = [
            'weight' => $request->weight,
            'totalDue' => $request->quantity,
            'originCity' => $request->city_from,
            'destinationCity' => $request->city_to,
            "height" => $request->height,
            "width" => $request->width,
            "length" => $request->length
        ];
        $deliveryOrderOTOFee = OTO::checkOTODeliveryFee($itemDetails);

        $deliveryOrderOTOFee = json_decode($deliveryOrderOTOFee, true);
        if (!$deliveryOrderOTOFee['success']) {
            return response()->json([
                'status' => 400,
                'message' => $deliveryOrderOTOFee
            ]);
        }

        return response()->json(json_decode($deliveryOrderOTOFee));
    }
}
