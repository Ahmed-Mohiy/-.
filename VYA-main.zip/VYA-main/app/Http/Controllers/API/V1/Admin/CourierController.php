<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Exports\ShipmentExport;
use App\Helper\Amount;
use App\Http\Controllers\Controller;
use App\Http\Resources\CourierResource;
use App\Http\Resources\ShipmentSellerResource;
use App\Models\AccountType;
use App\Models\Company;
use App\Models\Deal;
use App\Models\Order;
use App\Models\Shipment;
use App\Models\ShipmentReturn;
use Illuminate\Http\Request;

class CourierController extends Controller
{
    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(){
        $total_deal = Deal::count();
        $running_orders = Order::whereIn('status', [1,2])->count();
        $pending_shipments = Shipment::where('status', [1,2])->count();
        $returns = ShipmentReturn::count();

        return response()->json([
            'status' => 200,
            'data' => [
                'total_deal' => $total_deal,
                'running_orders' => $running_orders,
                'pending_shipments' => $pending_shipments,
                'returns' => $returns,
            ]
        ]);
    }

    public function reports(Request $request){
        $shipments = Shipment::query();

        $perPage = $request->get('per_page', 20);

        $total_shipments = Amount::get($shipments->count());
        $total_orders = Amount::get(Order::count());
        $total_buyers = Amount::get(Company::where('account_type_id', AccountType::TYPE['BUYER'])->count());
        $total_sellers = Amount::get(Company::where('account_type_id', AccountType::TYPE['SELLER'])->count());

        if (isset($request->order_status)){
            $order_status = $request->order_status;
            $shipments = $shipments->whereHas('order', function ($query) use ($order_status){
                $query->where('status', $order_status);
            });
        }
        if (isset($request->shipment_status)){
            $shipment_status = $request->shipment_status;
            $shipments = $shipments->where('status', $shipment_status);
        }
        if (isset($request->price_range)){
            $price_range = explode(',',$request->price_range);
            $shipments = $shipments->whereBetween('shipment_price', [$price_range[0],$price_range[1]]);
        }
        if (isset($request->period)){
            $period = explode(',',$request->period);
            $shipments = $shipments->whereBetween('created_at', [$period[0],$period[1]]);
        }

        if ($request->export){
            $export_url_file = $this->export($shipments->get());
        }


        return response()->json([
            'status' => 200,
            'data' => [
                'total_shipments' => $total_shipments,
                'total_orders' => $total_orders,
                'total_buyers' => $total_buyers,
                'total_sellers' => $total_sellers,
                'export_url_file' => $export_url_file ?? null,
                'shipments' => ShipmentSellerResource::collection($shipments->paginate($perPage)->appends([
                    'per_page' => $perPage
                ]))
            ]
        ]);

    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function list(Request $request){
        $query = Shipment::query();
        $query = $query->with(['buyer','seller']);
        if (isset($request->buyer_name)) {
            $buyerName = $request->buyer_name;

            $query->whereHas('buyer', function ($query) use ($buyerName) {
                $query->where('name', $buyerName);
            });
        }
        if (isset($request->seller_name)) {
            $sellerName = $request->seller_name;
            $query->whereHas('seller', function ($query) use ($sellerName) {
                $query->where('name', $sellerName);
            });
        }
        if (isset($request->status)) {
            $status = $request->status;
            $query->where('status', $status);
        }
        if (isset($request->shipment_number)) {
            $shipment_number = $request->shipment_number;
            $query->where('shipment_number', $shipment_number);
        }
        if (isset($request->created_at)) {
            $created_at = $request->created_at;
            $query->whereDate('created_at', $created_at);
        }

        $perPage = $request->get('per_page', 20);
        return CourierResource::collection($query->paginate($perPage)->appends([
            'per_page' => $perPage
        ])
        );

    }

    private function export($shipments){

        $fileName = 'files/' . now() . '-' . 'shipments' . '.xlsx';

        if ($shipments->isEmpty()) {
            return response()->json([
                'status' => 404,
                'message' => 'No Requests to Show',
            ], '404');
        }

        \Excel::store(new ShipmentExport($shipments), $fileName, 'public');

        return asset(\Storage::url($fileName));
    }
}
