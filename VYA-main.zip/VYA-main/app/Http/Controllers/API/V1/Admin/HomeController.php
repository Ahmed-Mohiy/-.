<?php

namespace App\Http\Controllers\API\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\AccountType;
use App\Models\Bid;
use App\Models\Company;
use App\Models\Deal;
use App\Models\Order;
use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Http\Request;
use DB;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $buyer = Company::where('account_type_id', AccountType::TYPE['BUYER'])->where('status', true)->count();
        $seller = Company::where('account_type_id', AccountType::TYPE['SELLER'])->where('status', true)->count();
        $deals = Deal::where('status', 1)->whereHas('product')->count();
        $order = new Order();
        $orders = $order->whereIn('status', [1, 2])->count();

        $status = ['3' => 'Order Canceled', '1' => 'Waiting for confirmation final Price', '2' => 'Awaiting Shipment', '4' => 'Order Delivered'];
        $running_orders_list = [];
        foreach ($status as $key => $value){
            $count = $order->where('status', $key)->count();
            $running_orders_list[] = [
                'title' => $value,
                'value' => $count,
                'percentage' => $count * $order->count() / 100
            ];
        }

        $top_buyer = Company::where('account_type_id', AccountType::TYPE['BUYER'])->where('status', true)->withCount('submissions')->take(10)->orderBy('submissions_count', 'desc')->get();
        $top_seller = Company::where('account_type_id', AccountType::TYPE['SELLER'])->where('status', true)->withCount('bids')->take(10)->orderBy('bids_count', 'desc')->get();

        $products = Product::withCount('submissions')->latest('submissions_count')->where('status', true)->take(5)->get();
        $most_products = [];

        foreach ($products as $product) {
            $most_products[] = [
                'id' => $product->id,
                'name' => $product->en_name,
                'count_submissions' => $product->submissions()->count()
            ];
        }

        $count = [];
        $startDate = ($request->year ?? Carbon::today()->format('Y')) . "-01-01";
        $endDate = ($request->year ?? Carbon::today()->format('Y')) . "-12-31";

        $count = Order::where('status', Order::STATUS['COMPLETED'])->whereBetween('created_at', [$startDate, $endDate])
//                ->groupBy('year')
//                ->groupBy('month')
            ->get()->groupBy(function ($date) {
                //return Carbon::parse($date->created_at)->format('Y'); // grouping by years
                return Carbon::parse($date->created_at)->format('m'); // grouping by months
            });

        $usermcount = [];
        $userStats = [];

        foreach ($count as $key => $value) {
            $usermcount[(integer)$key] = $value->sum('total_price');
        }

        for ($i = 1; $i <= 12; $i++) {
            if (!empty($usermcount[$i])) {
                $userStats[$i] = $usermcount[$i];
            } else {
                $userStats[$i] = 0;
            }
        }

        return response()->json([
            'status' => 200,
            'data' => [
                'annual_revenue' => $userStats,
                'running_deals' => $deals,
                'running_orders' => $orders,
                'total_buyer' => $buyer,
                'top_buyer' => $top_buyer,
                'total_seller' => $seller,
                'top_seller' => $top_seller,
                'total_most_products' => $products->count(),
                'most_products' => $most_products,
                'running_order_list' => $running_orders_list,
            ]
        ]);
    }
}
