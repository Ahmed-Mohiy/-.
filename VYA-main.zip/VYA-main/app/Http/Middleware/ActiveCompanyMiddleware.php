<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class ActiveCompanyMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\JsonResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (auth()->check() && auth()->user()->company->status){
            return $next($request);
        }
        return response()->json([
            'status' => 401,
            'Your Company Account maybe not Active or Suspended'
        ]);
    }
}
