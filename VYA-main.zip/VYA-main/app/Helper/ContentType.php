<?php

namespace App\Helper;

use Illuminate\Support\Facades\Storage;

class ContentType
{
    static function get($type, $data)
    {
        $value = null;
        switch ($type) {
            case '0': //message
                $value = $data;
                break;
            case '2': //file
                $file = asset(Storage::url($data));

                $value = self::fileType($file);
                break;
            default: //else
                $value = '<div class="alert alert-danger" role="alert">Unknown file type!</div>';
                break;
        }
        return $value;
    }

    private static function fileType($url){
        $value = pathinfo($url,PATHINFO_EXTENSION);

        switch ($value) {
            case 'png':
            case 'jpg':
            case 'jpeg':
            case 'avif':
            case 'gif':
                $value = '<a href="'.$url.'" data-lightbox="image-1">
                <img alt=".." src="'.$url.'"  width="300" class="img-fluid" />
                </a>
                ';
                break;
            case 'pdf':
            case 'csv':
            case 'xlsx':
            case 'docx':
            case 'doc':
                $value = '<a href="'.$url.'" download="download" class="btn btn-primary"><i class="fas fa-long-arrow-alt-down"></i> Download File</a>';
                break;
            default:
                $value = '<div class="alert alert-danger" role="alert">Unknown file type!</div>';
                break;
        }
        return $value;
    }
}
