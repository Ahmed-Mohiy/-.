<?php


namespace App\Helper;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;

class StoreFile
{
    static function store($file, $folder = 'media'){
        $fileName      = $folder . '/' . Str::random(30) . '.' . $file->extension();

        Storage::putFileAs('/', $file, $fileName);

        return $fileName;
    }

    public static function delete($oldFile){
        $exists = Storage::exists($oldFile);
        if ($exists){
            Storage::delete($oldFile);
        }
        return 200;
    }
}
