<?php

namespace App\Helper;
use Illuminate\Support\Facades\Http;

class EFAA
{
    const BASE_URL = 'https://qa.e-faa.com.sa/ibps/clientApi';
    const ACCOUNT = [
        'USERNAME' => '20220518001',
        'PASSWORD' => 'Alamal@1254'
    ];
    public $url = null;
    public $data = null;

    /**
     * @param $url
     * @param $data
     */
    public function __construct($url = null, $data = null)
    {
        $this->url = $url;
        $this->data = $data;
    }

    static function get($url, $data = []){

        $response = Http::withHeaders([
            'username' => self::ACCOUNT['USERNAME'],
            'password' => self::ACCOUNT['PASSWORD'],
        ])->get(self::BASE_URL.'/'.$url);

        return $response->json();
    }
    static function post($url, $data){
        $response = Http::withHeaders([
            'username' => self::ACCOUNT['USERNAME'],
            'password' => self::ACCOUNT['PASSWORD'],
        ])->post(self::BASE_URL.'/'.$url, $data);
        return $response->json();
    }
}
