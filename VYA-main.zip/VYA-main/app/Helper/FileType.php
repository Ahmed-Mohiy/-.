<?php


namespace App\Helper;


use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class FileType
{
    /**
     * @param $data
     * @return string
     */
    static function get($data)
    {
        $file = asset(Storage::url($data));
        return self::fileType($file);
    }

    /**
     * @param $url
     * @return string
     */
    private static function fileType($url){
        $value = pathinfo($url,PATHINFO_EXTENSION);

        switch ($value) {
            case 'png':
            case 'jpg':
            case 'jpeg':
            case 'gif':
            case 'svg':
            case 'jfif':
            case 'avif':
                $value = 'image';
                break;
            case 'mp4':
            case 'avi':
            case 'wmv':
            case 'flv':
            case 'webm':
            case 'mpeg':
                $value = 'video';
                break;
            case 'pdf':
            case 'csv':
            case 'xlsx':
            case 'docx':
            case 'doc':
                $value = 'file';
                break;
            default:
                $value = 'unknown';
                break;

        }
        return $value;
    }
}
