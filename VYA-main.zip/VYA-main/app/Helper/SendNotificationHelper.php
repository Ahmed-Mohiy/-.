<?php

namespace App\Helper;

use App\Events\Notifications;
use App\Notifications\UserNotification;

class SendNotificationHelper
{
    public static function notify($users, $message, $title, $click_action, $action_type, $action_id){
        foreach ($users as $user){
            $topic = $user->device_token;
            $user->notify(new UserNotification(
                auth()->check() ? auth()->user()->name : $title,
                $user->name,
                $title,
                $message,
                $action_type,
                $action_id
            ));
            $unreadNotificationsNumber = $user->unreadNotifications->count();
            event(new Notifications());
            PushNotificationHelper::sendTopicNotification($topic, $title, $message, $click_action, $action_type, $action_id, $unreadNotificationsNumber);
        }
    }
}
