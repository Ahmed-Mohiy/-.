<?php

namespace App\Models;

use App\Traits\TagTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    use HasFactory, TagTrait;
    protected $table = 'tags';
    protected $guarded = [];
}
