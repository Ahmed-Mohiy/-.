<?php

namespace App\Models;

use App\Traits\UserCategoryMostUsedTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserCategoryMostUsed extends Model
{
    use HasFactory, UserCategoryMostUsedTrait;
    protected $table = 'user_category_most_useds';
    protected $guarded = [];
}
