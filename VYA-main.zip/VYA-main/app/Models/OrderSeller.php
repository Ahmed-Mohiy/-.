<?php

namespace App\Models;

use App\Traits\OrderSellerTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderSeller extends Model
{
    use HasFactory, OrderSellerTrait;
    protected $table = 'order_sellers';
    protected $guarded = [];
}
