<?php

namespace App\Models;

use App\Traits\BidTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bid extends Model
{
    use HasFactory, BidTrait;

    protected $table = 'bids';
    protected $guarded = [];
    protected $appends = ['message'];

    const STATUS = [
        'DECLINED' => 0,
        'PENDING' => 1,
        'WON' => 2,
        'NOT SELECTED' => 3,
        'CANCELED' => 4
    ];

    /**
     * @return string
     */
    public function getMessageAttribute(){
        switch ($this->status) {
            case 0:
                $status = 'Bid Declined';
                break;
            case 1:
                $status = 'Bid is Pending';
                break;
            case 2:
                $status = 'Won for the Deal';
                break;
            case 3:
                $status = 'Not Selected';
                break;
            case 4:
                $status = 'Bid Canceled';
                break;
            default:
                $status = 'Unknown Status Message';
        }
        return $status;
    }
}
