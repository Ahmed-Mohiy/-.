<?php

namespace App\Models;

use App\Traits\ShipmentReturnTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShipmentReturn extends Model
{
    use HasFactory, ShipmentReturnTrait;
    protected $table = 'shipment_returns';
    protected $guarded = [];

    protected $appends = ['message'];


    /**
     * @return string
     */
    public function getMessageAttribute(){
        switch ($this->status) {
            case 0:
                $status = 'Deals Canceled';
                break;
            case 1:
                $status = 'Deal Running';
                break;
            case 2:
                $status = 'Waiting for Biding';
                break;
            case 3:
                $status = 'Deal Closed';
                break;
            default:
                $status = 'Unknown Status Message';
        }
        return $status;
    }

}
