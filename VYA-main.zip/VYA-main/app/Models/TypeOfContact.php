<?php

namespace App\Models;

use App\Traits\TypeOfContactTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TypeOfContact extends Model
{
    use HasFactory, SoftDeletes, TypeOfContactTrait;
    protected $table = 'type_of_contacts';
    protected $guarded = [];
}
