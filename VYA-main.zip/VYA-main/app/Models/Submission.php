<?php

namespace App\Models;

use App\Traits\SubmissionTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Submission extends Model
{
    use HasFactory, SubmissionTrait;

    protected $table = 'submissions';
    protected $guarded = [];

    protected $appends = array('total_quantity', 'hits', 'message');

    const STATUS = [
        'DECLINED' => 0,
        'AWAITING PAYMENT' => 1,
        'JOINED' => 2,
        'SELECTED' => 3,
        'CANCELED' => 4
    ];

    /**
     * @return string
     */
    public function getMessageAttribute(){
        switch ($this->status) {
            case 0:
                $status = 'Submission Declined';
                break;
            case 1:
                $status = 'Waiting for Payment';
                break;
            case 2:
                $status = 'Joined Deal';
                break;
            case 3:
                $status = 'Selected for the Deal';
                break;
            case 4:
                $status = 'Submission Canceled';
                break;
            default:
                $status = 'Unknown Status Message';
        }
        return $status;
    }
}
