<?php

namespace App\Models;

use App\Traits\SubmissionAddressTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubmissionAddress extends Model
{
    use HasFactory, SubmissionAddressTrait;
    protected $table = 'submission_addresses';
    protected $guarded = [];
}
