<?php

namespace App\Models;

use App\Traits\CompanyProductTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyProduct extends Model
{
    use HasFactory, CompanyProductTrait;
    protected $table = 'company_products';
    protected $guarded = [];
}
