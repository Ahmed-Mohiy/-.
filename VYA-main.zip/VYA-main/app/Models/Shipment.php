<?php

namespace App\Models;

use App\Traits\ShipmentTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shipment extends Model
{
    use HasFactory, ShipmentTrait;
    protected $table = 'shipments';
    protected $guarded = [];
    protected $appends = ['message'];

    const STATUS = [
        'DECLINED' => 0,
        'WAITING_SHIPMENT' => 1,
        'WAITING_PICKUP' => 2,
        'COMPLETED' => 3
    ];

    const TYPE = [
        'SELLER' => 0,
        'OTO' => 1
    ];

    public function getMessageAttribute(){
        switch ($this->status) {
            case 0:
                $status = 'Shipment Declined';
                break;
            case 1:
                $status = 'Waiting Shipment';
                break;
            case 2:
                $status = 'Waiting Pickup';
                break;
            case 3:
                $status = 'Completed Shipment and Order';
                break;
            default:
                $status = 'Unknown Status Message';
        }
        return $status;
    }
}
