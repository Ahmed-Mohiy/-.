<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Reason extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $table = 'reasons';

    public function model(): MorphTo
    {
        return $this->morphTo();
    }

    public function __toString(): string
    {
        return $this->description;
    }

    public function user(){
        return $this->belongsTo(User::class, 'created_by');
    }
}
