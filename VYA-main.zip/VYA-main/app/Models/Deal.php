<?php

namespace App\Models;

use App\Traits\DealTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Deal extends Model
{
    use HasFactory, DealTrait;
    protected $table = 'deals';
    protected $guarded = [];
    protected $appends = ['message'];

    const STATUS = [
        'CANCELED' => 0,
        'RUNNING' => 1,
        'WAITING' => 2,
        'CLOSED' => 3
    ];

    /**
     * @return string
     */
    public function getMessageAttribute(){
        switch ($this->status) {
            case 0:
                $status = 'Deals Canceled';
                break;
            case 1:
                $status = 'Deal Running';
                break;
            case 2:
                $status = 'Waiting for Biding';
                break;
            case 3:
                $status = 'Deal Closed';
                break;
            default:
                $status = 'Unknown Status Message';
        }
        return $status;
    }
}
