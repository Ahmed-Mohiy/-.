<?php

namespace App\Models;

use App\Traits\CountryTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Country extends Model
{
    use HasFactory, SoftDeletes, CountryTrait;
    protected $table = 'countries';
    protected $guarded = [];
}
