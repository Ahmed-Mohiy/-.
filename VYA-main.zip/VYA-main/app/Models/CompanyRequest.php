<?php

namespace App\Models;

use App\Traits\CompanyRequestTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyRequest extends Model
{
    use HasFactory, CompanyRequestTrait;

    protected $guarded = [];
}
