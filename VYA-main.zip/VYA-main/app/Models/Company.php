<?php

namespace App\Models;

use App\Traits\CompanyTrait;
use Bavix\Wallet\Traits\HasWallet;
use Bavix\Wallet\Interfaces\Wallet;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Company extends Model implements Wallet
{
    use HasFactory, SoftDeletes, CompanyTrait, HasWallet;
    protected $table = 'companies';
    protected $guarded = [];
}
