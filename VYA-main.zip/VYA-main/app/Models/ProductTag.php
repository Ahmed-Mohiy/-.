<?php

namespace App\Models;

use App\Traits\ProductTagTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductTag extends Model
{
    use HasFactory, ProductTagTrait;
    protected $table = 'product_tags';
    protected $guarded = [];
}
