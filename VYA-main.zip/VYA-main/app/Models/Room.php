<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    use HasFactory;
    protected $table = 'rooms';
    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    public function scopeGetRoom($query, $userID, $myID)
    {
        return $query->where(function ($query) use ($userID, $myID) {
            $query->where(function ($q) use ($userID, $myID) {
                $q->where('sender_id', $myID);
                $q->where('receiver_id', $userID);
            })->orWhere(function ($q) use ($userID, $myID) {
                $q->where('sender_id', $userID);
                $q->where('receiver_id', $myID);
            });
        });
    }

    /**
     * The channels the user receives notification broadcasts on.
     *
     * @return string
     */
    public function receivesBroadcastNotificationsOn()
    {
        return 'notify_room.'.$this->id;
    }
}
