<?php

namespace App\Models;

use App\Traits\LegalPaperTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LegalPaper extends Model
{
    use HasFactory, SoftDeletes, LegalPaperTrait;
    protected $table = 'legal_papers';
    protected $guarded = [];
}
