<?php

namespace App\Models;

use App\Traits\CompanyCategoryTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyCategory extends Model
{
    use HasFactory, CompanyCategoryTrait;
    protected $table = 'company_categories';
    protected $guarded = [];
}
