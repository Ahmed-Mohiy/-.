<?php

namespace App\Models;

use App\Traits\HasReasonTrait;
use App\Traits\OrderTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory, OrderTrait, HasReasonTrait;
    protected $table = 'orders';
    protected $guarded = [];
    protected $appends = ['message'];

    const STATUS = [
        'DECLINED' => 0,
        'WAITING_PRICE' => 1,
        'CONFIRMED' => 2,
        'CANCELED' => 3,
        'COMPLETED' => 4
    ];

    public function getMessageAttribute(){
        switch ($this->status) {
            case 0:
                $status = 'Order Declined';
                break;
            case 1:
                $status = 'Waiting for your acceptance of the price';
                break;
            case 2:
                $status = 'Order Confirmed';
                break;
            case 3:
                $status = 'Order Canceled';
                break;
            case 4:
                $status = 'Order Completed';
                break;
            default:
                $status = 'Unknown Status Message';
        }
        return $status;
    }
}
