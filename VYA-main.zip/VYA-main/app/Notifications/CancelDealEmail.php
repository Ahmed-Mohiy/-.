<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class CancelDealEmail extends Notification
{
    use Queueable;
    protected $name,$url, $action_id, $action_type;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($name, $url, $action_id, $action_type)
    {
        $this->name = $name;
        $this->url = $url;
        $this->action_id = $action_id;
        $this->action_type = $action_type;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('Unfortunately, your joined has been cancelled')
                    ->line('Hi '. $this->name)
                    ->line('Unfortunately, your joined to this deal has been cancelled')
                    ->line('We did not find enough balance in your wallet to proceed')
                    ->action('Deal Link', url($this->url));
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }


    public function toDatabase($notifiable)
    {
        return [
            'subject'       => 'Unfortunately, your joined has been cancelled',
            'message'       => 'Unfortunately, your joined to this deal has been cancelled',
            'action_id'     => $this->action_id,
            'action_type'   => $this->action_type,
        ];
    }
}
