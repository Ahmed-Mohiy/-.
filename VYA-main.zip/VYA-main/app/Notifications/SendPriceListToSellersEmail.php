<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class SendPriceListToSellersEmail extends Notification
{
    use Queueable;
    protected $url, $name, $action_id, $action_type;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($url, $name, $action_id, $action_type)
    {
        $this->url = $url;
        $this->name = $name;
        $this->action_id = $action_id;
        $this->action_type = $action_type;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
                    ->subject('Deal is over, time to join')
                    ->line('Dear'. $this->name)
                    ->line('The deal is over, time to join and add your price list')
                    ->action('Join Now', $this->url)
                    ->line('You only have 48 from the closing time to add and edit your price list and compete with the rest of the sellers within this deal');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }


    public function toDatabase($notifiable)
    {
        return [
            'subject'       => 'Deal is over, time to join',
            'message'       => 'The deal is over, time to join and add your price list',
            'action_id'     => $this->action_id,
            'action_type'   => $this->action_type,
        ];
    }
}
