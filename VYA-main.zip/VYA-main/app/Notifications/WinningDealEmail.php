<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class WinningDealEmail extends Notification
{
    use Queueable;
    protected $name, $url, $action_id, $action_type;


    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($name, $url, $action_id, $action_type)
    {
        $this->name = $name;
        $this->url = $url;

        $this->action_id = $action_id;
        $this->action_type = $action_type;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Congratulations! you have won!')
                    ->line('Hi, '.$this->name)
                    ->line('We would love to congratulate you.')
                    ->action('you have won', $this->url)
                    ->line('keep nailing it.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }


    public function toDatabase($notifiable)
    {
        return [
            'subject'       => 'Congratulations! you have won!',
            'message'       => 'We would love to congratulate you. you have won deal: '.$this->action_id,
            'action_id'     =>$this->action_id,
            'action_type'   => $this->action_type,
        ];
    }
}
