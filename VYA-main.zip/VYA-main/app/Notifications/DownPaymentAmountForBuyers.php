<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class DownPaymentAmountForBuyers extends Notification
{
    use Queueable;
    protected $date, $amount, $action_id;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($date, $amount, $action_id)
    {
        $this->date = $date;
        $this->amount = $amount;
        $this->action_id = $action_id;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param mixed $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('You are so close to an amazing deal.')
            ->line('For request to be finalised, a down-payment of '.$this->amount.' must be paid before '.$this->date.'.')
            ->action('Click Here', url('https://vya-frontend.cat-sw.com/my-submissions/'. $this->action_id));
    }

    /**
     * Get the array representation of the notification.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }

    public function toDatabase($notifiable)
    {
        return [
            'subject'       => 'You are so close to an amazing deal',
            'message'       => 'For request to be finalised, a down-payment of '.$this->amount.' must be paid before '.$this->date.'.',
            'action_id'     => $this->action_id,
            'action_type'   => 'my-submissions',
        ];
    }
}
