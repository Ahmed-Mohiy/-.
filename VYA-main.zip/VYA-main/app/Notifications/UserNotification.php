<?php


namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class UserNotification extends Notification
{
    use Queueable;
    private $from;
    private $to;
    private $subject;
    private $message;
    private $action_type;
    private $action_id;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($from, $to, $subject, $message, $action_type, $action_id)
    {
        $this->from         = $from;
        $this->to           = $to;
        $this->subject      = $subject;
        $this->message      = $message;
        $this->action_type  = $action_type;
        $this->action_id    = $action_id;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'mail'];
//        return explode(',', $notifiable->notification_preference);
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject($this->subject)
            ->greeting('Hello ' .$this->to)
            ->line($this->message)
            ->line('Thank you for using VYA!');
    }

    public function toDatabase()
    {
        return [
            'from'          => $this->from,
            'to'            => $this->to,
            'subject'       => $this->subject,
            'message'       => $this->message,
            'action_id'     => $this->action_id,
            'action_type'   => $this->action_type,
        ];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            'from'          => $notifiable->from,
            'to'            => $notifiable->to,
            'subject'       => $notifiable->subject,
            'message'       => $notifiable->message,
            'action_id'     => $notifiable->action_id,
            'action_type'   => $notifiable->action_type,
        ];
    }
}
