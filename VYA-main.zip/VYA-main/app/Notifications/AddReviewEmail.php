<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class AddReviewEmail extends Notification
{
    use Queueable;
    protected $url, $action_id, $action_type;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($url, $action_id, $action_type)
    {
        $this->url = $url;
        $this->action_id = $action_id;
        $this->action_type = $action_type;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail','database'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('A “new review” to review')
                    ->line('Hi “Admin”')
                    ->line('A buyer has just submitted a review on their purchase.')
                    ->action('View', $this->url)
                    ->line('we want to share it with the world as soon as possible')
                    ->line('please have a look at it and if it’s okay allow the rest of our family to know how good our services are.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }


    public function toDatabase($notifiable)
    {
        return [
//            'to'            => $this->to,
            'subject'       => 'A “new review” to review',
            'message'       => 'A buyer has just submitted a review on their purchase',
            'action_id'     => $this->action_id,
            'action_type'   => $this->action_type,
        ];
    }
}
