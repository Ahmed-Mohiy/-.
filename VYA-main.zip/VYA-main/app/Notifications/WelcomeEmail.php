<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class WelcomeEmail extends Notification
{
    use Queueable;
    protected $company_name;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($company_name)
    {
        $this->company_name = $company_name;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['database', 'mail'];
//        return explode(',', $notifiable->notification_preference);
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('You’re almost IN!')
            ->line('Welcome to VYA, '.$this->company_name)
            ->line('your registration request is upon review. we will get back to you the soonest.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }


    public function toDatabase($notifiable)
    {
        return [
            'subject'       => 'You’re almost IN!',
            'message'       => 'Welcome to VYA',
            'action_id'     =>'',
            'action_type'   => '',
        ];
    }
}
