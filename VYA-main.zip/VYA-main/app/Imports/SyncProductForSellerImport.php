<?php

namespace App\Imports;

use App\Models\CompanyProduct;
use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class SyncProductForSellerImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        $product = Product::where('sku', $row['sku_number'])->where('status', true)->first();
        if ($product){
            return CompanyProduct::firstOrCreate([
                'company_id' => auth()->user()->company_id,
                'product_id' => $product->id
            ]);
        }
        return 404;
    }
}
