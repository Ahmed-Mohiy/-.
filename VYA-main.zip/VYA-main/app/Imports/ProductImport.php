<?php

namespace App\Imports;

use App\Helper\StoreFile;
use App\Jobs\NotifyUserOfCompletedImport;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImages;
use App\Models\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\RemembersChunkOffset;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use File;
use Maatwebsite\Excel\Events\AfterImport;
use Maatwebsite\Excel\Events\ImportFailed;

class ProductImport implements ToModel, WithHeadingRow, WithChunkReading, ShouldQueue
{
    use RemembersChunkOffset;

    public function __construct(User $importedBy)
    {
        $this->importedBy = $importedBy;
    }

    public function registerEvents(): array
    {
        return [
            AfterImport::class => function(AfterImport $event) {
                $this->importedBy->notify(new NotifyUserOfCompletedImport($this->importedBy));
            },
        ];
    }

    public function model(array $row)
    {
        $category = Category::where('en_name', $row['category'])->first();
        if (empty($category)){
            Log::info($row['sku']);
        }
//        if (!empty($category)){
            $name = str_replace('   ', ' ', $row['en_name']);
            $product = Product::updateOrCreate(
                ['sku' => $row['sku']],
                [
                    'en_name' => $name,
                    'ar_name' => $name,
                    'sku' => $row['sku'],
                    'category_id' => $category->id,
                    'en_description' => $row['en_description'],
                    'ar_description' => $row['en_description'],
                    'shipment_type' => $row['shipment_type'] == 'OTO' ? 1 : 0,
                    'status' => $row['status'] == 'Active' ? 1 : 0,
                    'created_by' => 1,
                    'sku_identifier' => $row['sku_identifier'],
                    'additional_information' => $row['additional_information'],
                    'type' => $row['type'],
                ]
            );
            if (file_exists($row['en_name'])){
                $path = public_path($row['en_name']);
                $files = File::files($path);
                foreach ($files as $file){

                    $file_name = StoreFile::store($file, 'product');
                    ProductImages::create([
                        'product_id' => $product->id,
                        'file' => $file_name,
                        'is_main' => true,
                        'thumbnail' => $file_name
                    ]);
                }
            }
//        }
    }

    public function startRow(): int
    {
        return 1;
    }

    public function chunkSize(): int
    {
        return 500;
    }

    public static function afterImport(AfterImport $event)
    {
        Log::info(' after import excel file');
    }
}
