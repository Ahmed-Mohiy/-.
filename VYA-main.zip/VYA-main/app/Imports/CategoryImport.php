<?php

namespace App\Imports;

use App\Models\Category;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithProgressBar;

class CategoryImport implements ToModel, WithHeadingRow
{
    use Importable;
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return Category::firstOrCreate(
            ['en_name' => $row['en_name']],
            [
                'en_name' => $row['en_name'],
                'ar_name' => $row['en_name'],
                'status' => true,
                'image' => $row['image'] ?? null,
                'parent_id' => Category::where('en_name', $row['parent'])->first()->id ?? null
            ]
        );
    }
}
