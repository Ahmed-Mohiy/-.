<?php

namespace App\Rules;

use App\Models\Deal;
use Illuminate\Contracts\Validation\Rule;

class IsClosedDealRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $deal = Deal::where('status', '>=', 2)->where('id', $value)->first();

        if (!$deal){
            return false;
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'This Deal is not closed yat!';
    }
}
