<?php

namespace App\Rules;

use App\Models\Deal;
use Carbon\Carbon;
use Illuminate\Contracts\Validation\Rule;

class IsRunningDealRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $deal = Deal::where('status', 1)->where('id', $value)->where(function ($query) {
            return $query->running();
        })->first();

        if (!$deal){
            return false;
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The :attribute not running.';
    }
}
