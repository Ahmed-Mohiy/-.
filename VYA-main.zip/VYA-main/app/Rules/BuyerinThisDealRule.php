<?php

namespace App\Rules;

use App\Models\Submission;
use Illuminate\Contracts\Validation\Rule;

class BuyerinThisDealRule implements Rule
{
    protected $deal_id;
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct($deal_id)
    {
        $this->deal_id = $deal_id;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $submission = Submission::where('deal_id', $this->deal_id)->where('company_id', $value)->first();
        if (!$submission){
            return false;
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The Buyer is not in this deal!';
    }
}
