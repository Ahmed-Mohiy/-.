<?php

namespace App\Rules;

use App\Models\AccountType;
use App\Models\Company;
use Illuminate\Contracts\Validation\Rule;

class IsBuyerRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $company = Company::where('account_type_id', AccountType::TYPE['BUYER'])->where('id', $value)->first();

        if (!$company){
            return false;
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'This Account is not a Buyer Account!';
    }
}
