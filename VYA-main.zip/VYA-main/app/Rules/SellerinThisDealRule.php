<?php

namespace App\Rules;

use App\Models\Bid;
use Illuminate\Contracts\Validation\Rule;

class SellerinThisDealRule implements Rule
{
    protected $deal_id;
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct($deal_id)
    {
        $this->deal_id = $deal_id;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $bid = Bid::where('deal_id', $this->deal_id)->where('company_id', $value)->first();
        if (!$bid){
            return false;
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'The Seller is not in this deal!';
    }
}
