<?php

namespace App\Rules;

use App\Models\Deal;
use Illuminate\Contracts\Validation\Rule;

class CheckCompanyBalanceRule implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct($param)
    {
        $this->quantity = $param;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $deal = Deal::find($value);
        $deposit_amount = $deal->product->deposit_amount;
        if($deal->product->deposit_type == 0){
            if ($deposit_amount > auth()->user()->company->balance){
                return false;
            }
        } else {
            $deposit_amount = $this->quantity * $deposit_amount;
            if ($deposit_amount > auth()->user()->company->balance){
                return false;
            }
        }

        return true;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'Your company balance is not enough to participate in this deal';
    }
}
