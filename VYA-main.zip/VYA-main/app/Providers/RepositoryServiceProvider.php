<?php

namespace App\Providers;

use App\Interfaces\AboutRepositoryInterface;
use App\Interfaces\AuthRepositoryInterface;
use App\Interfaces\CategoryRepositoryInterface;
use App\Interfaces\ChatRepositoryInterface;
use App\Interfaces\CompanyRepositoryInterface;
use App\Interfaces\ContactUsRepositoryInterface;
use App\Interfaces\CountryRepositoryInterface;
use App\Interfaces\CurrencyRepositoryInterface;
use App\Interfaces\DealRepositoryInterface;
use App\Interfaces\FAQRepositoryInterface;
use App\Interfaces\InviteRepositoryInterface;
use App\Interfaces\ProductRepositoryInterface;
use App\Interfaces\PushNotificationInterface;
use App\Interfaces\RateRepositoryInterface;
use App\Interfaces\SliderRepositoryInterface;
use App\Interfaces\SocialRepositoryInterface;
use App\Interfaces\StaticRepositoryInterface;
use App\Interfaces\TypeOfContactInterface;
use App\Interfaces\UserRepositoryInterface;
use App\Interfaces\WishlistRepositoryInterface;
use App\Interfaces\WorkRepositoryInterface;
use App\Repositories\AboutRepository;
use App\Repositories\AuthRepository;
use App\Repositories\CategoryRepository;
use App\Repositories\ChatRepository;
use App\Repositories\CompanyRepository;
use App\Repositories\ContactUsRepository;
use App\Repositories\CountryRepository;
use App\Repositories\CurrencyRepository;
use App\Repositories\DealRepository;
use App\Repositories\FAQRepository;
use App\Repositories\InviteRepository;
use App\Repositories\ProductRepository;
use App\Repositories\PushNotificationRepository;
use App\Repositories\RateRepository;
use App\Repositories\SliderRepository;
use App\Repositories\SocialRepository;
use App\Repositories\StaticRepository;
use App\Repositories\TypeOfContactRepositories;
use App\Repositories\UserRepository;
use App\Repositories\WishlistRepository;
use App\Repositories\WorkRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(AuthRepositoryInterface::class, AuthRepository::class);
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
        $this->app->bind(CategoryRepositoryInterface::class, CategoryRepository::class);
        $this->app->bind(CountryRepositoryInterface::class, CountryRepository::class);
        $this->app->bind(WishlistRepositoryInterface::class, WishlistRepository::class);
        $this->app->bind(PushNotificationInterface::class, PushNotificationRepository::class);
        $this->app->bind(SliderRepositoryInterface::class, SliderRepository::class);
        $this->app->bind(ProductRepositoryInterface::class, ProductRepository::class);
        $this->app->bind(WorkRepositoryInterface::class, WorkRepository::class);
        $this->app->bind(CompanyRepositoryInterface::class, CompanyRepository::class);
        $this->app->bind(DealRepositoryInterface::class, DealRepository::class);
        $this->app->bind(CurrencyRepositoryInterface::class, CurrencyRepository::class);
        $this->app->bind(InviteRepositoryInterface::class, InviteRepository::class);
        $this->app->bind(AboutRepositoryInterface::class, AboutRepository::class);
        $this->app->bind(FAQRepositoryInterface::class, FAQRepository::class);
        $this->app->bind(StaticRepositoryInterface::class, StaticRepository::class);
        $this->app->bind(ChatRepositoryInterface::class, ChatRepository::class);
        $this->app->bind(ContactUsRepositoryInterface::class, ContactUsRepository::class);
        $this->app->bind(AboutRepositoryInterface::class, AboutRepository::class);
        $this->app->bind(SocialRepositoryInterface::class, SocialRepository::class);
        $this->app->bind(RateRepositoryInterface::class, RateRepository::class);
        $this->app->bind(TypeOfContactInterface::class, TypeOfContactRepositories::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
