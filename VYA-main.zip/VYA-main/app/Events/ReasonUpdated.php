<?php

namespace App\Events;

use App\Models\Reason;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Database\Eloquent\Model;

class ReasonUpdated
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /** @var Reason|null */
    public $oldReason;

    /** @var Reason */
    public $newReason;

    /** @var \Illuminate\Database\Eloquent\Model */
    public $model;

    public function __construct(?Reason $oldReason, Reason $newReason, Model $model)
    {
        $this->oldReason = $oldReason;

        $this->newReason = $newReason;

        $this->model = $model;
    }
}
