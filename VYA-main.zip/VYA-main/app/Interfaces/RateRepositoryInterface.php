<?php
namespace App\Interfaces;

interface RateRepositoryInterface {
    public function store($request);
    public function destroy($request);
    public function productIndex($product);
    public function orderIndex($order);
}
