<?php

namespace App\Interfaces;

interface SocialRepositoryInterface
{
    public function show();
    public function update($request);
}
