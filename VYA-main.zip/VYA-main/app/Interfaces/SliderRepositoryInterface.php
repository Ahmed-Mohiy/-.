<?php
namespace App\Interfaces;

interface SliderRepositoryInterface {
    public function index($sliders, $request);
    public function store($request);
    public function update($request, $id);
    public function show($slider);
    public function destroy($id);
}
