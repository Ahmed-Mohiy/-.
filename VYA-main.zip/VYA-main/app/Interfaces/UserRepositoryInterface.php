<?php

namespace App\Interfaces;

interface UserRepositoryInterface {
    public function addUser($request);
    public function updateUser($request, $id);
    public function index($type);
    public function addPermission($request);
    public function listRoles($type);
    public function addRoles($request);
    public function givePermissions($request);
    public function assignRole($request);
    public function syncRole($request);
    public function addEmployee($request);
    public function listEmployee();
    public function editEmployee($request, $user);
}
