<?php

namespace App\Interfaces;

interface PushNotificationInterface
{
    public function getTopics();
    public function index($pushNotifications, $request);
    public function store($request);
}
