<?php
namespace App\Interfaces;

interface StaticRepositoryInterface {
    public function index($type);
    public function update($request, $type);
}
