<?php

namespace App\Interfaces;

interface ProductRepositoryInterface
{
    public function index($product, $request);
    public function store($request);
    public function show($id);
    public function update($request, $id);
    public function destroy($id);
    public function storeAttach($request);
    public function updateAttach($request);
    public function destroyAttach($id);
    public function status($request);
}
