<?php

namespace App\Interfaces;

interface AuthRepositoryInterface {
    public function login($request);
    public function me();
    public function logout();
    public function refresh();
    public function respondWithToken($token);
    public function guard();
    public function token($request);
}
