<?php

namespace App\Interfaces;

interface VendorRepositoryInterface
{
    public function index($request);
}
