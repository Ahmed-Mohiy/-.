<?php

namespace App\Interfaces;

interface ChatRepositoryInterface
{
    public function conversation($userID);
    public function sendMessage($request);
    public function updateOnline($request);
    public function updateOffline($request);
    public function seen($request);
    public function updateSeen($userID, $myID);
}
