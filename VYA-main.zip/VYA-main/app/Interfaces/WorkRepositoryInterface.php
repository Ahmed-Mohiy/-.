<?php
namespace App\Interfaces;

interface WorkRepositoryInterface {
    public function index($type, $request, $works);
    public function store($request);
    public function update($request, $id);
    public function show($id);
    public function destroy($id);
}
