<?php

namespace App\Interfaces;

interface InviteRepositoryInterface
{
    public function index($invite, $request);
    public function store($request);
    public function show($id);
    public function update($request, $id);
    public function destroy($id);
}
