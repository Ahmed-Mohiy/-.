<?php
namespace App\Interfaces;

interface CompanyRepositoryInterface {
    public function listCompanies($type);
    public function profile($company);
    public function syncCategories($request);
    public function showCategories($id);
    public function syncProducts($request);
    public function showProducts($request, $id);
    public function AddAddresses($request, $id);
    public function editAddress($request, $address);
    public function deleteAddress($address);
    public function showAddresses($id);
    public function AddLegalPapers($request, $id);
    public function showLegalPapers($id);
    public function deleteLegalPapers($legalPaper);
    public function approveCompany($request, $company);
    public function approveCompanyRequest($request, $companyRequest);
    public function changeRequest($request, $company);
    public function listRequests($request);
    public function syncImport($request);
}
