<?php

namespace App\Interfaces;

interface AboutRepositoryInterface
{
    public function show($request);
    public function update($request);
}
