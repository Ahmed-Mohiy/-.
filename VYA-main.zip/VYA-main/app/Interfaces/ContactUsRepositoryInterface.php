<?php

namespace App\Interfaces;

interface ContactUsRepositoryInterface {
    public function index();
    public function store($request);
    public function delete($contact);
}
