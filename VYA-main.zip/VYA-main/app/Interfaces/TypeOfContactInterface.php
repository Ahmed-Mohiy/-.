<?php

namespace App\Interfaces;

interface TypeOfContactInterface
{
    public function index($request);
    public function store($request);
    public function update($request, $id);
    public function destroy($id);
}
