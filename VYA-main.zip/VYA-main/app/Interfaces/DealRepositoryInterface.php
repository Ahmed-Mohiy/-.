<?php

namespace App\Interfaces;

interface DealRepositoryInterface
{
    public function index($deal, $request);
    public function show($id);
    public function update($request, $id);
    public function status($request);
    public function destroy($id);
}
