<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SendInvitesMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $name, $company_name, $url;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($name, $company_name, $url)
    {
        $this->company_name = $company_name;
        $this->name = $name;
        $this->url = $url;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->from(env('MAIL_FROM_ADDRESS'), env('APP_NAME'))
            ->markdown('emails.users.invite')
            ->with([
                'name' => $this->name,
                'company_name' => $this->company_name,
                'url' => $this->url
            ]);
        //return $this->view('view.name');
    }
}
