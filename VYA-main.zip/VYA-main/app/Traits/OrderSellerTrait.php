<?php

namespace App\Traits;

trait OrderSellerTrait
{

}
