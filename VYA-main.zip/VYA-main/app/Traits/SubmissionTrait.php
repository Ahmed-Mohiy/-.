<?php

namespace App\Traits;

use App\Models\Company;
use App\Models\Currency;
use App\Models\Deal;
use App\Models\Product;
use App\Models\SubmissionAddress;

trait SubmissionTrait
{
    public function deal(){
        return $this->belongsTo(Deal::class, 'deal_id');
    }
    public function company(){
        return $this->belongsTo(Company::class, 'company_id');
    }
    public function currency(){
        return $this->belongsTo(Currency::class, 'currency_id');
    }
    public function getTotalQuantityAttribute()
    {
        return $this->submissionAddresses()->sum('quantity');
    }
    public function submissionAddresses(){
        return $this->hasMany(SubmissionAddress::class);
    }
    public function getHitsAttribute()
    {
        return (int) $this->submissionAddresses()->sum('quantity') * $this->max_price;
    }

}
