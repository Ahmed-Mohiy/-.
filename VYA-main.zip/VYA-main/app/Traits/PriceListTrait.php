<?php
namespace App\Traits;

use App\Models\Currency;
use App\Models\Price;

trait PriceListTrait{
    public function prices(){
        return $this->hasMany(Price::class, 'price_list_id');
    }

    public function currency(){
        return $this->belongsTo(Currency::class, 'currency_id');
    }
}
