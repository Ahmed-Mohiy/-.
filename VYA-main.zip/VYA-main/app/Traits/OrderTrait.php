<?php

namespace App\Traits;

use App\Models\Company;
use App\Models\Currency;
use App\Models\Deal;
use App\Models\OrderSeller;
use App\Models\Rate;
use App\Models\Shipment;
use App\Models\ShipmentReturn;

trait OrderTrait
{
    public function deal(){
        return $this->belongsTo(Deal::class, 'deal_id');
    }

    public function buyer(){
        return $this->belongsTo(Company::class, 'buyer_id');
    }

    public function sellers(){
        return $this->belongsToMany(Company::class, 'order_sellers', 'order_id', 'seller_id');
    }

    public function currency(){
        return $this->belongsTo(Currency::class, 'currency_id');
    }

//    public function shipment(){
//        return $this->hasOne(Shipment::class);
//    }
    public function shipments(){
        return $this->hasMany(Shipment::class);
    }
    public function shipment_return(){
        return $this->hasOne(ShipmentReturn::class);
    }
    public function rate() {
        return $this->hasMany(Rate::class, 'order_id')->where('product', '0');
    }

}
