<?php

namespace App\Traits;

use App\Models\Product;

trait BrandTrait
{
    public function products(){
        return $this->hasMany(Product::class);
    }
}
