<?php

namespace App\Traits;

use App\Models\Company;

trait LegalPaperTrait
{
    public function company(){
        return $this->belongsTo(Company::class, 'company_id');
    }
}
