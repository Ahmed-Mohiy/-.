<?php

namespace App\Traits;

use App\Models\Company;
use App\Models\Product;

trait CompanyProductTrait
{
    public function company(){
        return $this->belongsTo(Company::class, 'company_id');
    }
    public function product(){
        return $this->belongsTo(Product::class, 'category_id');
    }
}
