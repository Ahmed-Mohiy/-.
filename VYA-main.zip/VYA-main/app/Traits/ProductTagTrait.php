<?php

namespace App\Traits;

use App\Models\Product;
use App\Models\Tag;

trait ProductTagTrait
{
    public function tag(){
        return $this->belongsTo(Tag::class, 'tag_id');
    }
    public function product(){
        return $this->belongsTo(Product::class, 'product_id');
    }
}
