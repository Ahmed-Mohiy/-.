<?php

namespace App\Traits;

use App\Models\Category;
use App\Models\CompanyCategory;
use App\Models\Product;
use App\Models\UserCategoryMostUsed;

trait CategoryTrait
{
    public function categories()
    {
        return $this->hasMany(Category::class, 'parent_id', 'id')->with('categories');
    }

    public function companyCategories()
    {
        return $this->hasMany(CompanyCategory::class);
    }
    public function userCategoryMostUsed()
    {
        return $this->hasMany(UserCategoryMostUsed::class);
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }
    public function childs(){
        return $this->hasMany(Category::class, 'parent_id', 'id');
    }
    public function recursiveChilds(){
        return $this->childs()->with('recursiveChilds');
    }
}
