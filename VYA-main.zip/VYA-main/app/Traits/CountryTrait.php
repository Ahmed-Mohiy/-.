<?php

namespace App\Traits;

use App\Models\Address;
use App\Models\Country;

trait CountryTrait
{
    public function address(){
        return $this->hasMany(Address::class);
    }
    public function children(){
        return $this->hasMany(Country::class,'country_id','id')->with('children');
    }
    public function country(){
        return $this->belongsTo(Country::class, 'country_id');
    }
}
