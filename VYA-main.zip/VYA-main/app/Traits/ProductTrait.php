<?php

namespace App\Traits;

use App\Models\Category;
use App\Models\Company;
use App\Models\CompanyCategory;
use App\Models\CompanyProduct;
use App\Models\Deal;
use App\Models\Price;
use App\Models\PriceList;
use App\Models\ProductImages;
use App\Models\ProductTag;
use App\Models\Rate;
use App\Models\Specification;
use App\Models\Submission;
use App\Models\Tag;
use App\Models\User;
use App\Models\Wishlist;
use Carbon\Carbon;

trait ProductTrait
{
    public function tags(){
        return $this->hasManyThrough(ProductTag::class, Tag::class);
    }
    public function productTags(){
        return $this->hasMany(ProductTag::class);
    }
    public function category(){
        return $this->belongsTo(Category::class, 'category_id');
    }
    public function deals(){
        return $this->hasMany(Deal::class);
    }
    public function scopeRunning($query){
        return $query->whereRaw("DATEDIFF(date_to, NOW()) >= 0")->whereRaw("DATEDIFF(NOW(), date_from) >= 0");
    }
    public function wishlists(){
        return $this->hasMany(Wishlist::class);
    }
    public function user(){
        return $this->belongsTo(User::class, 'created_by');
    }
    public function files(){
        return $this->hasMany(ProductImages::class);
    }
    public function defaultImage(){
        return $this->hasOne(ProductImages::class)->orderBy('sort')->where('is_main', true);
    }
    public function rate() {
        return $this->hasMany(Rate::class, 'product_id')->whereNotNull('product');
    }
    public function ratingCompany($id){
       return $this->hasOne(Rate::class, 'product_id')->where('user_id', $id)->whereNotNull('product');
    }
    public function submissions(){
        return $this->hasManyThrough(Submission::class, Deal::class, 'id', 'deal_id');
    }

    public function companyProducts()
    {
        return $this->hasMany(CompanyProduct::class);
    }
    public function company()
    {
        return $this->belongsToMany(Company::class, 'company_products');
    }
    public function scopeExitsProductCompany($query)
    {
        return $query->companyProducts();
    }

    public function specifications()
    {
        return $this->hasMany(Specification::class);
    }

    public function prices(){
        return $this->hasManyThrough(Price::class, PriceList::class);
    }

    public function getLatestPriceList()
    {
        return $this->hasMany(PriceList::class)->latest();
    }
}
