<?php

namespace App\Traits;

use App\Models\Address;
use App\Models\Submission;

trait SubmissionAddressTrait
{
    public function submission(){
        return $this->belongsTo(Submission::class, 'submission_id');
    }
    public function address(){
        return $this->belongsTo(Address::class, 'address_id');
    }
}
