<?php

namespace App\Traits;

use App\Models\Company;
use App\Models\CompanyCategory;
use App\Models\CompanyProduct;
use App\Models\Rate;
use App\Models\Room;
use App\Models\UserCategoryMostUsed;
use App\Models\UserMessage;
use App\Models\Wishlist;

trait UserTrait
{
    public function company(){
        return $this->belongsTo(Company::class, 'company_id')->with('legalPapers');
    }
    public function wishlists(){
        return $this->hasMany(Wishlist::class);
    }
    public function wished($product){
        return (boolean) $this->wishlists()->where('product_id', $product)->first();
    }
    public function categories(){
        return $this->hasMany(CompanyCategory::class);
    }
    public function products(){
        return $this->hasMany(CompanyProduct::class);
    }
    public function category_used(){
        return $this->hasMany(UserCategoryMostUsed::class);
    }
    public function messages(){
        return $this->hasMany(UserMessage::class, 'sender_id', 'id');
    }
    public function message(){
        return $this->hasOne(UserMessage::class, 'sender_id', 'id');
    }
    public function senderTransactions() {
        return $this->hasMany(Room::class, 'sender_id');
    }
    public function receiverTransactions() {
        return $this->hasMany(Room::class, 'receiver_id');
    }
    public function getTransactionsAttribute() {
        return $this->senderTransactions->merge($this->receiverTransactions);
    }
    public function rate() {
        return $this->hasMany(Rate::class, 'user_id');
    }
}
