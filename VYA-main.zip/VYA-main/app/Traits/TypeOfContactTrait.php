<?php

namespace App\Traits;

use App\Models\Contact;

trait TypeOfContactTrait
{
    public function contact(){
        return $this->hasMany(Contact::class);
    }
}
