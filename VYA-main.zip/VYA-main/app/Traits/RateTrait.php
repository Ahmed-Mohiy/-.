<?php

namespace App\Traits;

use App\Models\ProductTag;
use App\Models\User;

trait RateTrait
{
    public function user(){
        return $this->belongsTo(User::class);
    }
}
