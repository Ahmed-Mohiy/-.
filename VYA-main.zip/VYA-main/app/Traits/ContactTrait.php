<?php

namespace App\Traits;

use App\Models\TypeOfContact;

trait ContactTrait
{
    public function types(){
        return $this->belongsTo(TypeOfContact::class, 'type_of_contact_id');
    }
}
