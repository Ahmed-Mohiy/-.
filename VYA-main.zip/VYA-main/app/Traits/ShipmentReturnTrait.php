<?php

namespace App\Traits;


use App\Models\Company;
use App\Models\Order;
use App\Models\Shipment;
use App\Models\ShipmentReturnReason;
use App\Models\User;

trait ShipmentReturnTrait
{

    public function shipment(){
        return $this->belongsTo(Shipment::class);
    }
    public function order(){
        return $this->belongsTo(Order::class);
    }
    public function buyer(){
        return $this->belongsTo(Company::class, 'buyer_id');
    }
    public function seller(){
        return $this->belongsTo(Company::class, 'seller_id');
    }
    public function reason(){
        return $this->belongsTo(ShipmentReturnReason::class, 'shipment_return_reason_id');
    }
}
