<?php

namespace App\Traits;

use App\Models\Address;
use App\Models\Bid;
use App\Models\Category;
use App\Models\CompanyCategory;
use App\Models\CompanyRequest;
use App\Models\Invite;
use App\Models\LegalPaper;
use App\Models\Order;
use App\Models\Product;
use App\Models\ShipmentReturn;
use App\Models\Submission;
use App\Models\SubmissionAddress;
use App\Models\User;

trait CompanyTrait
{
    public function users(){
        return $this->hasMany(User::class);
    }
    public function addresses(){
        return $this->hasMany(Address::class);
    }
    public function address(){
        return $this->hasOne(Address::class)->where('is_default', true);
    }
    public function submissions(){
        return $this->hasMany(Submission::class);
    }
    public function bids(){
        return $this->hasMany(Bid::class);
    }
    public function submission($value){
        return $this->hasOne(Submission::class)->where('deal_id', $value);
    }
    public function submissionAddress($value){
        return $this->hasManyThrough(SubmissionAddress::class, Submission::class)->where('submissions.deal_id', $value);
    }
    public function bidding($value){
        return $this->hasOne(Bid::class)->where('deal_id', $value);
    }
    public function requests(){
        return $this->hasMany(CompanyRequest::class);
    }
    public function legalPapers(){
        return $this->hasMany(LegalPaper::class);
    }
    public function invites(){
        return $this->hasMany(Invite::class);
    }
    public function orders(){
        return $this->hasMany(Order::class, 'buyer_id');
    }
    public function categories(){
        return $this->belongsToMany(Category::class, 'company_categories', 'company_id', 'category_id');
    }
    public function products(){
        return $this->belongsToMany(Product::class, 'company_products', 'company_id', 'product_id');
    }
    public function shipment_return(){
        return $this->hasMany(ShipmentReturn::class);
    }
}
