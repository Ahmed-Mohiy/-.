<?php

namespace App\Traits;

use App\Models\Company;
use App\Models\Country;
use App\Models\Shipment;
use App\Models\Submission;
use App\Models\SubmissionAddress;

trait AddressTrait
{
    public function company(){
        return $this->belongsTo(Company::class, 'company_id');
    }
    public function country(){
        return $this->belongsTo(Country::class, 'country_id');
    }
    public function submission(){
        return $this->hasManyThrough(Submission::class,SubmissionAddress::class);
    }

    public function buyerShipment(){
        return $this->hasMany(Shipment::class,'buyer_address_id');
    }
}
