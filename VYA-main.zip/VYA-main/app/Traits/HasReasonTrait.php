<?php

namespace App\Traits;

use App\Events\ReasonUpdated;
use App\Models\Reason;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Support\Arr;

trait HasReasonTrait
{
    public function reasons(): MorphMany
    {
        return $this->morphMany(Reason::class, 'model', 'model_type', 'model_id')->latest('id');
    }

    public function reason()
    {
        return $this->latestReason();
    }

    public function setReason(string $description): self
    {
        $oldReason = $this->latestReason();

        $newReason = $this->reasons()->create([
            'created_by' => auth()->id(),
            'description' => $description,
        ]);

        event(new ReasonUpdated($oldReason, $newReason, $this));

        return $this;
    }

    public function latestReason(...$descriptions): ?Reason
    {
        $reasons = $this->relationLoaded('reasons') ? $this->reasons : $this->reasons();

        $descriptions = is_array($descriptions) ? Arr::flatten($descriptions) : func_get_args();
        if (count($descriptions) < 1) {
            return $reasons->first();
        }

        return $reasons->whereIn('description', $descriptions)->first();
    }

}
