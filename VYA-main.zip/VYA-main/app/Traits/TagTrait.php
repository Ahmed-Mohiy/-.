<?php

namespace App\Traits;

use App\Models\ProductTag;

trait TagTrait
{
    public function tagProducts(){
        return $this->hasMany(ProductTag::class);
    }
}
