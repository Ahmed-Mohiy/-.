<?php

namespace App\Traits;

use App\Models\Category;
use App\Models\Company;

trait CompanyCategoryTrait
{
    public function company(){
        return $this->belongsTo(Company::class, 'company_id');
    }
    public function category(){
        return $this->belongsTo(Category::class, 'category_id');
    }
}
