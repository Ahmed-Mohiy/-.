<?php

namespace App\Traits;

use App\Models\Address;
use App\Models\Company;
use App\Models\Deal;
use App\Models\Order;
use App\Models\ShipmentReturn;

trait ShipmentTrait
{

    public function deal(){
        return $this->belongsTo(Deal::class, 'deal_id');
    }
    public function buyer(){
        return $this->belongsTo(Company::class, 'buyer_id');
    }
    public function seller(){
        return $this->belongsTo(Company::class, 'vendor_id');
    }
    public function addressTo(){
        return $this->belongsTo(Address::class, 'buyer_address_id');
    }
    public function addressForm(){
        return $this->belongsTo(Address::class, 'seller_address_id');
    }
    public function order(){
        return $this->belongsTo(Order::class, 'order_id');
    }
    public function scopeShipment($query, $OTOOrderID){
        return $query->where('oto_order_id', $OTOOrderID);
    }
    public function shipment_return(){
        return $this->hasOne(ShipmentReturn::class);
    }
}
