<?php

namespace App\Traits;

use App\Models\Bid;
use App\Models\Category;
use App\Models\Company;
use App\Models\CompanyProduct;
use App\Models\Order;
use App\Models\Product;
use App\Models\Submission;
use App\Models\SubmissionAddress;
use Carbon\Carbon;

trait DealTrait
{
    public function scopeRunning($query){
        return $query->whereRaw("DATEDIFF(date_to, NOW()) >= 0")->whereRaw("DATEDIFF(NOW(), date_from) >= 0");
    }

    public function getDaysLeftAttribute()
    {
        $carbon = new Carbon();
        $today = $carbon->today();
        $finish_time = $carbon->parse($this->date_to);
        return ($today->diffInDays($finish_time, false) <= 0) ? 0 : $today->diffInDays($finish_time, false);
    }

    public function product(){
        return $this->belongsTo(Product::class);
    }

    public function category(){
        return $this->hasOneThrough(Category::class, Product::class, 'id', 'id', 'product_id', 'category_id');
    }

    public function orders(){
        return $this->hasMany(Order::class);
    }

    public function bids(){
        return $this->hasMany(Bid::class);
    }

    public function submissions(){
        return $this->hasMany(Submission::class);
    }

    public function buyers(){
        return $this->belongsToMany(Company::class, Submission::class);
    }

    public function submissionsAddresses(){
        return $this->hasManyThrough(SubmissionAddress::class, Submission::class, 'deal_id', 'submission_id');
    }


}
