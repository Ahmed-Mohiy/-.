<?php

namespace App\Traits;


use App\Models\AutomaticBid;
use App\Models\Company;
use App\Models\Deal;
use App\Models\Price;
use App\Models\PriceList;
use App\Models\Shipment;

trait BidTrait
{
    public function priceList(){
        return $this->belongsTo(PriceList::class, 'price_list_id')->with('prices');
    }
    public function company(){
        return $this->belongsTo(Company::class, 'company_id');
    }

    public function deal(){
        return $this->belongsTo(Deal::class);
    }

    public function is_automated($id, $company){
        return AutomaticBid::where('price_list_id', $id)->where('company_id', $company)->count();
    }

    public function prices(){
        return $this->hasManyThrough(Price::class, PriceList::class, 'id', 'price_list_id', 'id');
    }
    public function shipments(){
        return $this->hasManyThrough(Shipment::class, Deal::class, 'id', 'deal_id', 'deal_id');
    }
}
