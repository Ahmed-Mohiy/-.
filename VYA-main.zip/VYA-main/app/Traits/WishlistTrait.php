<?php

namespace App\Traits;

use App\Models\Product;
use App\Models\User;

trait WishlistTrait
{
    public function user(){
        return $this->belongsTo(User::class, 'user_id');
    }
    public function product(){
        return $this->belongsTo(Product::class, 'product_id');
    }
    public function scopeWished($query, $arg)
    {
        dd($arg);
        return $query->where('product_id', $arg);
    }
}
