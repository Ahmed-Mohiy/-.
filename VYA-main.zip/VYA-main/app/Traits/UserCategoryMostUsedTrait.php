<?php

namespace App\Traits;

use App\Models\Category;
use App\Models\User;

trait UserCategoryMostUsedTrait
{
    public function category(){
        return $this->belongsTo(Category::class, 'category_id');
    }
    public function user(){
        return $this->belongsTo(User::class, 'user_id');
    }
}
