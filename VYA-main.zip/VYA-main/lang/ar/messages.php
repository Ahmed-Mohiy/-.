<?php
 return[

     'No slap to show' => 'لا توجد مصفوفة للعرض',
     'Created Successfully' => 'تم إنشاؤه بنجاح',
     'Account created successfully' => 'تم إنشاء الحساب بنجاح',
     'Updated Successfully' => 'تم تعديله بنجاح',
     'Deleted Successfully' => 'تم حذفه بنجاح',
     'Product Removed Successfully' => 'تم إزالة المنتج بنجاح',
     'Product Added Successfully' => 'تم إضافة المنتج بنجاح',
     'Permission added successfully' => 'تم إضافة الصلاحية بنجاح',
     'Role added successfully' => 'تمت إضافة الدور بنجاح',
     'Permission assigned successfully' => 'تم تعيين الإذن بنجاح',
     'Permission synced successfully' => 'تمت مزامنة الإذن بنجاح',
     'Invalid request type' => 'نوع الطلب غير صالح',
     'User does not exist' => 'المستخدم غير موجود',
     'Undefined type please select Admins, vendors or buyers' => 'نوع غير محدد الرجاء تحديد المسؤولين أو البائعين أو المشترين',
     'Password must contain at least one lowercase letter, one uppercase letter and at least one digit' => 'يجب أن تحتوي كلمة المرور على حرف صغير واحد على الأقل وحرف كبير واحد ورقم واحد على الأقل',

 ];
