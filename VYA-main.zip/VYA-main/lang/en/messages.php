<?php
 return[

     'No slap to show' => 'No slap to show',
     'Created Successfully' => 'Created Successfully',
     'Account created successfully' => 'Account created successfully',
     'Updated Successfully' => 'Updated Successfully',
     'Deleted Successfully' => 'Deleted Successfully',
     'Product Removed Successfully' => 'Product Removed Successfully',
     'Product Added Successfully' => 'Product Added Successfully',
     'Permission added successfully' => 'Permission added successfully',
     'Role added successfully' => 'Role added successfully',
     'Permission assigned successfully' => 'Permission assigned successfully',
     'Permission synced successfully' => 'Permission synced successfully',
     'Invalid request type' => 'Invalid request type',
     'User does not exist' => 'User does not exist',
     'Undefined type please select Admins, vendors or buyers' => 'Undefined type please select Admins, vendors or buyers',
     'Password must contain at least one lowercase letter, one uppercase letter and at least one digit' => 'Password must contain at least one lowercase letter, one uppercase letter and at least one digit',

 ];
