@component('mail::message')
    # Dears,

    {{ $name }}, From {{ $company_name }} Sent to you a invitation to join VYA

    @component('mail::button', ['url' => $url])
        Accept Invitation
    @endcomponent

    Thanks,<br>
    {{ config('app.name') }}
@endcomponent
