@component('mail::message')
    # Dears,

    <strong>Name </strong>: {{ $details['name'] }},<br>

    <strong>Email</strong>: {{ $details['email'] }},<br>

    <strong>Subject</strong>: {{ $details['subject'] }},<br>

    <strong>Message type</strong>: {{ $details['type'] }},<br>

    <strong>Message</strong>:<br>

    {!! $details['message'] !!}


    Thanks,<br>
    {{ config('app.name') }}
@endcomponent
