<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Baz</title>
</head>
<body>
<script>
    AndroidFunction.goToVideoCall("eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiIsImN0eSI6InR3aWxpby1mcGE7dj0xIn0.eyJqdGkiOiJTSzdiMzE3YTRjOTc5MWE4OThjZDNhYmU5ODA4OGJhNjU0LTE2NzI5MTQwNzMiLCJpc3MiOiJTSzdiMzE3YTRjOTc5MWE4OThjZDNhYmU5ODA4OGJhNjU0Iiwic3ViIjoiQUNiZjUyZmY0N2JiNjRiZGE5MjhhNWU5M2RkN2RkYjc5MiIsImV4cCI6MTY3MjkxNzY3MywiZ3JhbnRzIjp7ImlkZW50aXR5IjoiQWwgQmF6eiIsInZpZGVvIjp7InJvb20iOiJSb29tIn19fQ.M37_rA5GMr-_PPgL0qE_zyo9BlT78pnGqig0OWq7x8g","Room");
</script>
</body>
</html>
