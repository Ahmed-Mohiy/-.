<table>
    <thead>
    <tr>
        <th>ID</th>
        <th>Shipment Number</th>
        <th>Buyer Name</th>
        <th>Seller Name</th>
        <th>Created at</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Status</th>
    </tr>
    </thead>
    <tbody>
    @foreach($shipments as $shipment)
        <tr>
            <td>{{ $shipment->id }}</td>
            <td>{{ $shipment->shipment_number }}</td>
            <td>{{ $shipment->buyer->name }}</td>
            <td>{{ $shipment->seller->name }}</td>
            <td>{{ $shipment->created_at }}</td>
            <td>{{ $shipment->quantity }}</td>
            <td>{{ $shipment->shipment_price }}</td>
            <td>{{ $shipment->status }}</td>
        </tr>
    @endforeach
    </tbody>
</table>
