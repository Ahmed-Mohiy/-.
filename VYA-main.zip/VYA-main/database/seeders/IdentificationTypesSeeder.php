<?php

namespace Database\Seeders;

use App\Models\IdentificationType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class IdentificationTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        IdentificationType::insert([[
            'en_type' => 'National ID',
            'ar_type' => 'الهوية الوطنية',
        ], [
            'en_type' => 'Passport ID',
            'ar_type' => 'جواز السفر',
        ], [
            'en_type' => 'Iqama ID',
            'ar_type' => 'رقم الإقامة',
        ]]);
    }
}
