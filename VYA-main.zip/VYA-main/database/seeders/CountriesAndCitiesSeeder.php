<?php

namespace Database\Seeders;

use App\Models\Country;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CountriesAndCitiesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $cities = json_decode($this->curl_get_file_contents(asset('cities.json')), true);

        $data = [];
        foreach ($cities as $city){
            $data[] = $city['city'];
        }
        $data = [
            'Saudi Arabia' => $data,
            'Egypt' => ['Cairo', 'Alexandria'],
            'China' => []
        ];

        foreach ($data as $country => $citis)
        {
            $id = Country::insert([
                'en_name' => $country,
                'ar_name' => $country
            ]);

            foreach ($citis as $city) {
                Country::insert([
                    'country_id' => $id,
                    'ar_name' => $city,
                    'en_name' => $city
                ]);
            }
        }
    }
    function curl_get_file_contents($URL)
    {
        $c = curl_init();
        curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($c, CURLOPT_URL, $URL);
        $contents = curl_exec($c);
        curl_close($c);

        if ($contents) return $contents;
        else return FALSE;
    }
}
