<?php

namespace Database\Seeders;

use App\Models\Social;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SocialsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Social::insert([
            'color_logo' => 'test',
            'white_logo' => 'test',
            'mobile' => 'test',
            'map' => 'test',
            'linkedin' => 'test',
            'facebook' => 'test',
            'twitter' => 'test',
            'youtube' => 'test',
        ]);
    }
}
