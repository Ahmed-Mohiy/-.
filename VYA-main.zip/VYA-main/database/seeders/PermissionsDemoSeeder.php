<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;


class PermissionsDemoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Reset cached roles and permissions
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        // create roles and assign existing permissions
        $buyer = Role::create(['name' => 'Buyer']);
        $buyer_logistics = Role::create(['name' => 'Buyer-logistics']);
        $buyer_finance = Role::create(['name' => 'Buyer-Finance']);
        $seller = Role::create(['name' => 'Seller']);
        //$seller_sales = Role::create(['name' => 'Seller-Sales']);
        $seller_finance = Role::create(['name' => 'Seller-Finance']);
        $seller_logistics = Role::create(['name' => 'Seller-Logistics']);
        $admin = Role::create(['name' => 'Admin']);
        $admin_customer_service = Role::create(['name' => 'Admin-Customer-Service']);
        //$admin_product_management = Role::create(['name' => 'Admin-Product-Management']);
        //$admin_logistics = Role::create(['name' => 'Admin-Logistics']);
        $admin_procurement = Role::create(['name' => 'Admin-Procurement']);
        $admin_finance = Role::create(['name' => 'Admin-Finance']);
        //create permissions
        //Generic
        Permission::create(['name' => 'view financial']);
        Permission::create(['name' => 'view deal']);
        Permission::create(['name' => 'chat']);
        Permission::create(['name' => 'manage order']);

        //Buyer Permissions
        Permission::create(['name' => 'join deal']);
        Permission::create(['name' => 'add address']);
        Permission::create(['name' => 'manage category']);
        Permission::create(['name' => 'view wallet']);
        Permission::create(['name' => 'recharge wallet']);

        //vendor Permissions
        Permission::create(['name' => 'can bid']);
        Permission::create(['name' => 'manage price-list']);
        Permission::create(['name' => 'manage product-list']);
        Permission::create(['name' => 'manage package-delivery']);

        //admin Permission
        Permission::create(['name' => 'dashboard']);
        Permission::create(['name' => 'manage account']);
        Permission::create(['name' => 'manage financial']);
        Permission::create(['name' => 'manage deal']);
        Permission::create(['name' => 'manage product']);
        Permission::create(['name' => 'manage shipment']);
        Permission::create(['name' => 'assign buyer seller']);

        /// Assign Permission to Role

        $buyer->givePermissionTo(['join deal', 'add address', 'manage category', 'view wallet', 'recharge wallet', 'view financial', 'view deal', 'manage account', 'manage package-delivery', 'chat']);
        $buyer_logistics->givePermissionTo(['manage package-delivery']);
        $buyer_finance->givePermissionTo(['recharge wallet', 'view wallet', 'view financial', 'view deal']);

        $seller->givePermissionTo(['can bid', 'manage price-list', 'manage product-list', 'view financial', 'manage account', 'view deal', 'manage package-delivery', 'chat']);
        //$seller_sales->givePermissionTo(['can bid', 'manage price-list', 'manage product-list', 'manage product-list', 'chat']);
        $seller_finance->givePermissionTo(['view financial', 'view deal']);
        $seller_logistics->givePermissionTo(['manage package-delivery']);

        $admin->givePermissionTo(['manage account', 'chat', 'manage deal', 'manage product', 'manage shipment', 'assign buyer seller', 'dashboard', 'manage financial']);
        $admin_customer_service->givePermissionTo(['manage account', 'chat', 'view deal']);
        //$admin_product_management->givePermissionTo(['manage product']);
        //$admin_logistics->givePermissionTo(['manage shipment']);
        $admin_procurement->givePermissionTo(['chat', 'manage deal', 'assign buyer seller', 'manage shipment']);
        $admin_finance->givePermissionTo(['manage financial', 'view deal', 'dashboard']);



        // gets all permissions via Gate::before rule; see AuthServiceProvider

  //       create demo users
        $user = \App\Models\User::factory()->create([
            'name' => 'Super Admin',
            'email' => 'admin@admin.com',
            'password' => Hash::make('12345678')
        ]);
        $user->assignRole($admin);

        $user1 = \App\Models\User::factory()->create([
            'name' => 'Customer Service',
            'email' => 'customer@admin.com',
            'password' => Hash::make('12345678')
        ]);
        $user1->assignRole($admin_customer_service);

        $user2 = \App\Models\User::factory()->create([
            'name' => 'Product Management',
            'email' => 'product@admin.com',
            'password' => Hash::make('12345678')
        ]);
        $user2->assignRole($admin_finance);

//        $user3 = \App\Models\User::factory()->create([
//            'name' => 'Logistics',
//            'email' => 'logistics@admin.com',
//            'password' => Hash::make('12345678')
//        ]);
//        $user3->assignRole($admin_logistics);

        $user4 = \App\Models\User::factory()->create([
            'name' => 'Procurements',
            'email' => 'procurement@admin.com',
            'password' => Hash::make('12345678')
        ]);
        $user4->assignRole($admin_procurement);
    }
}
