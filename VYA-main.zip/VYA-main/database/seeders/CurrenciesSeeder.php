<?php

namespace Database\Seeders;

use App\Models\Currency;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CurrenciesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Currency::insert([[
            'en_name' => 'Saudi riyal',
            'ar_name' => 'ريال سعودي',
            'symbolic' => 'SR',
        ],[
            'en_name' => 'Egyptian pound',
            'ar_name' => 'جنيه مصري',
            'symbolic' => 'LE',
        ]]);
    }
}
