<?php

namespace Database\Seeders;

use App\Models\TypeOfContact;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TypeOfContactsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TypeOfContact::insert([
            [
                'en_name' => 'Support',
                'ar_name' => 'دعم',
                'status' => true
            ],
            [
                'en_name' => 'Contact',
                'ar_name' => 'تواصل',
                'status' => true
            ],
        ]);
    }
}
