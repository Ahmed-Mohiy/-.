<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            'Clothing' => ['Woman Shoes', 'Men\'s Shirts'],
            'Tech' => ['Smartphones', 'Smartwatches'],
            'Dogs' => []
        ];

        foreach ($data as $category => $subCategories)
        {
            $id = Category::create([
                'en_name' => $category,
                'ar_name' => $category,
                'image' => 'categories/category.jpg',
                'status' => true
            ])->id;

            foreach ($subCategories as $subCategory) {
                Category::create([
                    'parent_id' => $id,
                    'ar_name' => $subCategory,
                    'en_name' => $subCategory,
                    'image' => 'categories/category.jpg',
                    'status' => true
                ]);
            }
        }
    }
}
