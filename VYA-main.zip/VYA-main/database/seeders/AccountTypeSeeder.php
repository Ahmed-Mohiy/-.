<?php

namespace Database\Seeders;

use App\Models\AccountType;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AccountTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        AccountType::insert([[
            'en_name' => 'Admin',
            'ar_name' => 'مسؤول',
        ], [
            'en_name' => 'Buyer',
            'ar_name' => 'بائع',
        ], [
            'en_name' => 'Seller',
            'ar_name' => 'مشتري',
        ]]);
    }
}
