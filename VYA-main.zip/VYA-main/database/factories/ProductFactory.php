<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\Product;
use Faker\Provider\ar_EG\Text;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Product>
 */
class ProductFactory extends Factory
{
    protected $model = Product::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $category = Category::inRandomOrder()->first();
        $specifications = serialize(['brand' => 'Total']);
        $faker = fake('ar_EG');
        return [
            'sku' =>  Str::random(20),
            'ar_name' => $faker->sentence(3),
            'en_name' => $this->faker->unique()->sentence(3),
            'ar_description' => $faker->sentence(500),
            'en_description' => $this->faker->sentence(500),
            'category_id' => $category->id,
            'deposit_amount' => rand(1, 3),
            'deposit_type' => 2,
            'shipment_type' => 2,
            'specifications' => $specifications,
            'status' => 1,
            'created_by' => 1,
        ];
    }
}
