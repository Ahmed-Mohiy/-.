<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('sku')->nullable();

            $table->unsignedBigInteger('category_id')->index();
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');

            $table->boolean('status')->default(true)->comment('True or False');

            $table->string('deposit_amount');
            $table->boolean('deposit_type')->default(true)->comment('1 = unit or 0 = total');

            $table->boolean('shipment_type')->default(true)->comment('1 = by vya or 0 = by vendor');

            $table->string('en_name', 255);
            $table->string('ar_name', 255);

            $table->text('en_description')->nullable();
            $table->text('ar_description')->nullable();

            $table->text('specifications')->nullable();

            $table->unsignedBigInteger('created_by')->index();
            $table->foreign('created_by')->references('id')->on('users')->onDelete('cascade');

            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
};
