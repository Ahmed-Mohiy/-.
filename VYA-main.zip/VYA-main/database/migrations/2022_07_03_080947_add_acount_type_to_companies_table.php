<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->unsignedBigInteger('account_type_id')->index();
            $table->foreign('account_type_id')->references('id')->on('account_types')->onDelete('cascade');

            $table->unsignedBigInteger('identification_type_id')->nullable()->index();
            $table->foreign('identification_type_id')->references('id')->on('identification_types')->onDelete('cascade');

            $table->string('identification_type_number', 255)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            //
        });
    }
};
