<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('works', function (Blueprint $table) {
            $table->id();
            $table->boolean('type')->default(true)->comment('True for Works and False for Sell');
            $table->string('sort')->default('0');
            $table->string('image', 255);
            $table->string('en_title', 255);
            $table->string('ar_title', 255);
            $table->longText('en_caption');
            $table->longText('ar_caption');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('works');
    }
};
