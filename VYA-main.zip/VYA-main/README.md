# VYA Backend
## Installation

First clone the project.

```bash
git clone https://github.com/catmobile2020/VYA.git
```

into to the project and run composer update

```
cd VYA
```
Here
```
composer update
```
Now you’ll create a MySQL database and set up environment variables to give the application access to the database.

Let’s copy ``env.example`` to ``.env`` and update the database related variables

```
cp .env.example .env
```

Then use **vya.sql** in ``/`` dir or run migrate

```
php artisan migrate --seed
```

Finally, execute the following command

```
php artisan storage:link
```

Now the project is ready, just run the server command if you are on local:
```
php artisan serve
```
Any Questions: Call Hamdiko ;)
