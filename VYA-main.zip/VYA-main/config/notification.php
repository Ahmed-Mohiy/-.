<?php

return [
    'FCM_SERVER_KEY' => env('FCM_SERVER_KEY', 'AAAAh-xMuTo:APA91bGWuLj4LTXaLEo3oUPXgoXMJbGfONp85K6BmKbR_9d1v_WN3RK7mQ2SKVe1Xh8pUjjox_S6UnqnO7TbQE3xGKypZJKw0m52tYaUMDjQDhn8ezuUyziDrR_GVqHls0vow-G0NzVT'),
    'FCM_URL' => env('FCM_URL', 'https://fcm.googleapis.com/fcm/send'),
];
