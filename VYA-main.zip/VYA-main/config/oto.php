<?php

return [


    /*
    |--------------------------------------------------------------------------
    | Merchant account authorization info
    |--------------------------------------------------------------------------
    |
    |
    */

    "refresh_token"  => env('OTO_REFRESH_TOKEN', 'AOEOulZ76Qv5hzKnJenD6SVH9_FyNTupE779uOXys-g6n9Jf7tXDDtK-bILhOtFYVoV89-OHvCsK333sFzKCGUD-F1J0p37WwPbXzD7xzCjSRnznmQtFL-AfwQJJO3X9tSaVc0cYWVIMX2ahGbFB8yCbVPP5CaTmWvnDo-U3FtepmyewD7RlSyB2MhtrON8E75D6IH3eAfbytCik9Es8d1Ka1nL2tDXcRg'),
    "access_token"   => "" ,

    /*
    |--------------------------------------------------------------------------
    | Oto Mode
    |--------------------------------------------------------------------------
    |
    | Mode only values: "test" or "live"
    |
    */

    "mode"     => "test",

    /*
    |--------------------------------------------------------------------------
    | Oto currency
    |--------------------------------------------------------------------------
    | EGP , SAR , USD, .. etc
    */

    "currency" => "SAR" ,

    /*
    |--------------------------------------------------------------------------
    | TEST Payment Request url
    |--------------------------------------------------------------------------
    */

    "test_urls" => [
            "refresh_token"         => "https://api.tryoto.com/rest/v2/refreshToken",
            "available_cities"      => "https://api.tryoto.com/rest/v2/availableCities",
            "check_oto_delivery_fee" => "https://api.tryoto.com/rest/v2/checkOTODeliveryFee",
            "create_order"          => "https://api.tryoto.com/rest/v2/createOrder",
            "cancel_order"          => "https://api.tryoto.com/rest/v2/cancelOrder",
            "order_status"          => "https://api.tryoto.com/rest/v2/orderStatus",
            "create_shipment"       => "https://api.tryoto.com/rest/v2/createShipment",
            "create_return_shipment"=> "https://api.tryoto.com/rest/v2/createReturnShipment",
            "create_pickup_location"=> "https://api.tryoto.com/rest/v2/createPickupLocation",
            "order_history"=> "https://api.tryoto.com/rest/v2/orderHistory",
            ],
    /*
    |--------------------------------------------------------------------------
    | LIVE Payment Request url
    |--------------------------------------------------------------------------
    */

    "live_urls" => [
            "refresh_token"         => "",
            "available_cities"      => "",
            "check_oto_delivery_fee"    => "",
            "create_order"          => "",
            "cancel_order"          => "",
            "order_status"          => "",
            "create_shipment"       => "",
            "create_return_shipment"=> "",
    ],



];
